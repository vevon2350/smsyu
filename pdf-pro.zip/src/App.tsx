/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import TrustBadges from './components/TrustBadges';
import Features from './components/Features';
import Footer from './components/Footer';
import PDFToolModal from './components/PDFToolModal';
import APIKeyMonitorModal from './components/APIKeyMonitorModal';
import AuthModal from './components/AuthModal';
import ResumeModal from './components/ResumeModal';
import PrivacyPolicyModal from './components/PrivacyPolicyModal';
import TermsOfServiceModal from './components/TermsOfServiceModal';
import HelpCenterModal from './components/HelpCenterModal';
import ContactModal from './components/ContactModal';

export default function App() {
  const [toolModal, setToolModal] = useState<{ tool: string; title: string } | null>(null);
  const [monitorOpen, setMonitorOpen] = useState<boolean>(false);
  const [authModal, setAuthModal] = useState<"signin" | "signup" | null>(null);
  const [userEmail, setUserEmail] = useState<string | null>(null);
  const [privacyOpen, setPrivacyOpen] = useState<boolean>(false);
  const [termsOpen, setTermsOpen] = useState<boolean>(false);
  const [helpOpen, setHelpOpen] = useState<boolean>(false);
  const [contactOpen, setContactOpen] = useState<boolean>(false);

  // Read initial session from localStorage
  useEffect(() => {
    const stored = localStorage.getItem("pdfpro_user");
    if (stored) {
      setUserEmail(stored);
    }
  }, []);

  const handleAuthSuccess = (email: string) => {
    setUserEmail(email);
    localStorage.setItem("pdfpro_user", email);
  };

  const handleLogout = () => {
    setUserEmail(null);
    localStorage.removeItem("pdfpro_user");
  };

  return (
    <div className="min-h-screen bg-white">
      <Navbar 
        onToolClick={(tool, title) => setToolModal({ tool, title })} 
        onAuthClick={(mode) => setAuthModal(mode)}
        userEmail={userEmail}
        onLogout={handleLogout}
      />
      <main>
        <Hero />
        <TrustBadges />
        <Features />
      </main>
      <Footer 
        onPrivacyClick={() => setPrivacyOpen(true)} 
        onTermsClick={() => setTermsOpen(true)} 
        onHelpClick={() => setHelpOpen(true)} 
        onContactClick={() => setContactOpen(true)} 
      />
      {toolModal && (toolModal.tool === 'resume' ? (
        <ResumeModal onClose={() => setToolModal(null)} />
      ) : (
        <PDFToolModal {...toolModal} onClose={() => setToolModal(null)} />
      ))}
      {privacyOpen && <PrivacyPolicyModal onClose={() => setPrivacyOpen(false)} />}
      {termsOpen && <TermsOfServiceModal onClose={() => setTermsOpen(false)} />}
      {helpOpen && <HelpCenterModal onClose={() => setHelpOpen(false)} />}
      {contactOpen && <ContactModal onClose={() => setContactOpen(false)} />}
      {monitorOpen && <APIKeyMonitorModal onClose={() => setMonitorOpen(false)} />}
      {authModal && (
        <AuthModal
          initialMode={authModal}
          onClose={() => setAuthModal(null)}
          onAuthSuccess={handleAuthSuccess}
        />
      )}
    </div>
  );
}
