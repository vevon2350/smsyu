import React from 'react';
import { Zap, Cloud, Folder, Shield } from 'lucide-react';
import PDFSplitter from './PDFSplitter';

export default function Features() {
  return (
    <section className="py-24 bg-gray-100">
      <div className="px-12 max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
          {/* PDF Splitter Bento Item */}
          <div className="md:col-span-8">
            <PDFSplitter />
          </div>
          {/* Bento Item 2 */}
          <div className="md:col-span-4 bg-indigo-700 p-8 rounded-xl flex flex-col justify-center items-center text-center text-white">
            <div className="mb-6 w-16 h-16 bg-white/20 rounded-full flex items-center justify-center">
              <Zap size={32} />
            </div>
            <h3 className="text-2xl font-bold mb-2">Blazing Fast</h3>
            <p className="text-sm opacity-90">Our cloud processing handles files up to 500MB in seconds.</p>
          </div>
          {/* Bento Item 3 */}
          <div className="md:col-span-4 bg-indigo-100 p-8 rounded-xl">
            <h3 className="text-sm font-bold text-indigo-900 uppercase mb-4">Integrations</h3>
            <div className="flex flex-wrap gap-3">
              <div className="px-4 py-2 bg-white rounded-full text-sm font-bold text-indigo-700 shadow-sm flex items-center gap-2">
                <Cloud size={16} /> Google Drive
              </div>
              <div className="px-4 py-2 bg-white rounded-full text-sm font-bold text-indigo-700 shadow-sm flex items-center gap-2">
                <Folder size={16} /> Dropbox
              </div>
            </div>
          </div>
          {/* Bento Item 4 */}
          <div className="md:col-span-8 bg-gray-200 p-8 rounded-xl flex items-center gap-8">
            <Shield size={64} className="text-gray-400" />
            <div>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">GDPR Compliant</h3>
              <p className="text-gray-600">We adhere to the strictest global data protection standards to keep your business records safe.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
