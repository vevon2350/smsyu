import React, { useState, useRef, useEffect } from 'react';
import { 
  X, Search, FileText, Check, Copy, Download, Share2, Scale, Lock, 
  HelpCircle, ChevronRight, Eye, Calendar, RefreshCcw, FileCheck, ExternalLink,
  BookOpen, Heart, Activity, Globe, ShieldAlert
} from 'lucide-react';

interface TermsOfServiceModalProps {
  onClose: () => void;
}

interface OutlineSection {
  id: string;
  title: string;
  sub: string;
}

const TERMS_OUTLINE: OutlineSection[] = [
  { id: 'sec-agreement', title: '1. Agreement of Terms', sub: 'Foundations of legal bind & usage scope' },
  { id: 'sec-license', title: '2. License & Resource Usage', sub: 'Permitted execution & file ownership' },
  { id: 'sec-acceptable', title: '3. Acceptable Use Guidelines', sub: 'Fair play, system limits & bandwidth' },
  { id: 'sec-prohibited', title: '4. Strictly Prohibited Content', sub: 'Sensitive files & security integrity' },
  { id: 'sec-warranties', title: '5. Warranties & Liability', sub: 'Service availability & hardware waivers' },
  { id: 'sec-termination', title: '6. Account & Draft Termination', sub: 'Session expirations & data self-destruct' }
];

export default function TermsOfServiceModal({ onClose }: TermsOfServiceModalProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeSection, setActiveSection] = useState('sec-agreement');
  const [copied, setCopied] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  // Auto detect active section on scroll
  useEffect(() => {
    const handleScroll = () => {
      if (!scrollContainerRef.current) return;
      
      const container = scrollContainerRef.current;
      const scrollPos = container.scrollTop + 120; // offset

      for (const sect of TERMS_OUTLINE) {
        const el = container.querySelector(`#${sect.id}`);
        if (el) {
          const top = (el as HTMLElement).offsetTop;
          const height = el.getBoundingClientRect().height;
          if (scrollPos >= top && scrollPos < top + height) {
            setActiveSection(sect.id);
            break;
          }
        }
      }
    };

    const container = scrollContainerRef.current;
    if (container) {
      container.addEventListener('scroll', handleScroll);
    }
    return () => {
      if (container) {
        container.removeEventListener('scroll', handleScroll);
      }
    };
  }, []);

  const scrollToSect = (id: string) => {
    setActiveSection(id);
    const el = scrollContainerRef.current?.querySelector(`#${id}`);
    if (el && scrollContainerRef.current) {
      scrollContainerRef.current.scrollTo({
        top: (el as HTMLElement).offsetTop - 15,
        behavior: 'smooth'
      });
    }
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(window.location.href + '#terms-of-service');
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    setDownloadSuccess(true);
    setTimeout(() => {
      setDownloadSuccess(false);
      // Trigger native browser print which formats automatically as page-perfect PDF
      window.print();
    }, 1000);
  };

  // Helper function to dynamically highlight query text inside raw texts
  const highlightText = (text: string) => {
    if (!searchQuery.trim()) return text;
    const regex = new RegExp(`(${searchQuery.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&')})`, 'gi');
    const parts = text.split(regex);
    return (
      <>
        {parts.map((part, i) => 
          regex.test(part) ? (
            <mark key={i} className="bg-blue-100 py-0.5 px-1 rounded-sm text-gray-900 border border-blue-350 select-all font-semibold">
              {part}
            </mark>
          ) : part
        )}
      </>
    );
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[110] flex items-center justify-center p-4 overflow-hidden animate-fadeIn text-left">
      <div className="bg-white rounded-2xl w-full max-w-[1250px] h-[92vh] flex flex-col shadow-2xl relative animate-slideUp">
        
        {/* Dropbox Paper Style Control Header */}
        <div className="border-b border-gray-150 px-6 py-4 flex items-center justify-between bg-white shrink-0">
          <div className="flex items-center gap-3">
            {/* Dropbox-styled file icon with active color */}
            <div className="bg-blue-600 text-white p-2.5 rounded-lg shadow-md hover:bg-blue-700 transition-colors">
              <Scale size={20} className="animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[11px] font-extrabold bg-blue-50 text-blue-800 uppercase px-2 py-0.5 rounded-md tracking-wider">
                  Paper Doc File (Read-Only)
                </span>
                <span className="text-xs text-gray-400 font-mono flex items-center gap-1">
                  <Activity size={12} className="text-blue-500" /> Auto-Synced to Legal Vault
                </span>
              </div>
              <h2 className="text-base font-extrabold text-gray-900 flex items-center gap-2 mt-0.5 font-sans">
                PDFPro_Terms_of_Service_Agreement_V4.pdf
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            {/* Interactive Keyword Search Filter */}
            <div className="relative hidden md:block">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={14} />
              <input 
                type="text" 
                placeholder="Search keywords (e.g. license, fair, prohibited, liability)..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9 pr-4 py-1.5 w-64 bg-slate-100 rounded-lg text-xs outline-none focus:bg-white border border-transparent focus:border-blue-400 transition-all font-medium text-gray-800"
              />
              {searchQuery && (
                <button 
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[10px] font-bold text-gray-400 hover:text-gray-600"
                >
                  Clear
                </button>
              )}
            </div>

            <div className="h-6 w-[1px] bg-gray-200 mx-1 hidden md:block"></div>

            <button 
              onClick={handleCopyLink}
              className={`px-3 py-1.5 rounded-lg border text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                copied 
                  ? 'bg-emerald-50 border-emerald-300 text-emerald-700' 
                  : 'border-gray-200 bg-white hover:bg-slate-50 text-gray-700'
              }`}
            >
              {copied ? <Check size={14} /> : <Copy size={13} />}
              {copied ? 'Link Copied!' : 'Copy Terms Link'}
            </button>

            <button 
              onClick={handleDownload}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold text-white flex items-center gap-1.5 transition-all cursor-pointer shadow-sm ${
                downloadSuccess
                  ? 'bg-emerald-600'
                  : 'bg-blue-600 hover:bg-blue-700'
              }`}
            >
              {downloadSuccess ? (
                <>
                  <Check size={14} /> Generating Perfect Page Print...
                </>
              ) : (
                <>
                  <Download size={13} /> Secure Draft PDF / Print
                </>
              )}
            </button>

            <button 
              onClick={onClose}
              className="p-1.5 bg-slate-100 hover:bg-rose-50 text-gray-500 hover:text-rose-600 rounded-lg transition-transform cursor-pointer ml-1"
              title="Close Terms Window"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Modal Secondary Context Banner */}
        <div className="bg-slate-50 border-b border-gray-150 px-6 py-2.5 flex justify-between items-center text-xs shrink-0 font-sans">
          <p className="text-gray-600 flex items-center gap-1.5 font-medium">
            <Lock size={12} className="text-indigo-600" />
            <span className="font-bold text-gray-800">Dynamic User Operations Limit:</span> By engaging our secure document processors, you freely accept these conditions.
          </p>
          <div className="flex gap-4 text-[11px] text-gray-500 font-mono font-medium">
            <span>LAST AMENDED: JUNE 06, 2026</span>
            <span>AUDIT COMPLIANT: SA-102581</span>
          </div>
        </div>

        {/* Dynamic Multi-Pane Layout */}
        <div className="flex-1 flex overflow-hidden min-h-0">
          
          {/* LOBBYISTS SIDEBAR: Document Outline navigation */}
          <div className="w-[28%] bg-slate-50 border-r border-gray-150 flex flex-col justify-between shrink-0">
            {/* Outline list */}
            <div className="p-4 overflow-y-auto space-y-1">
              <h4 className="text-[10px] font-extrabold text-slate-400 tracking-wider uppercase mb-3.5 px-2">
                Document Outline Tree
              </h4>
              <nav className="space-y-1">
                {TERMS_OUTLINE.map((sect) => (
                  <button
                    key={sect.id}
                    onClick={() => scrollToSect(sect.id)}
                    className={`w-full text-left p-3 rounded-xl transition-all flex flex-col cursor-pointer ${
                      activeSection === sect.id 
                        ? 'bg-white border border-gray-200/80 shadow-sm'
                        : 'hover:bg-slate-200/60'
                    }`}
                  >
                    <span className={`text-[11.5px] font-extrabold tracking-tight ${
                      activeSection === sect.id ? 'text-blue-700' : 'text-gray-700'
                    }`}>
                      {sect.title}
                    </span>
                    <span className="text-[10px] text-gray-450 mt-0.5 font-medium truncate w-[210px]">
                      {sect.sub}
                    </span>
                  </button>
                ))}
              </nav>

              {/* Extra Document Stats */}
              <div className="mt-8 border-t border-gray-200 pt-5 space-y-3 px-2">
                <h4 className="text-[10px] font-extrabold text-slate-400 tracking-wider uppercase">
                  Policy Metadata
                </h4>
                <div className="space-y-2 text-[11px] font-medium text-gray-650">
                  <div className="flex justify-between items-center">
                    <span className="flex items-center gap-1"><Calendar size={12} /> Document Version</span>
                    <span className="font-mono text-gray-900 font-bold">4.8.1</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="flex items-center gap-1"><RefreshCcw size={12} /> Maintenance</span>
                    <span>Annual Legal Cycle</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="flex items-center gap-1"><BookOpen size={12} /> Reading Duration</span>
                    <span>5 Minutes</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick trust seal at baseline */}
            <div className="p-4 border-t border-gray-200 bg-slate-100/60 space-y-2 text-center text-[10px] text-gray-500 font-medium">
              <div className="flex justify-center gap-1 text-blue-600 font-bold uppercase tracking-wider">
                <FileCheck size={13} /> System Integrity Secured
              </div>
              <p className="leading-relaxed px-2 text-gray-400">
                This legal document is compliant with international web service standards and sandbox policies.
              </p>
            </div>
          </div>

          {/* MAIN ARTICLE PREVIEWER: Beautiful high-fidelity Paper styled Canvas */}
          <div 
            ref={scrollContainerRef}
            className="flex-1 overflow-y-auto p-12 bg-white flex justify-center scroll-smooth outline-none select-text"
          >
            {/* Mimics a physical A4 document centered inside Dropbox viewer */}
            <article className="w-full max-w-[760px] pb-32 space-y-8 font-sans leading-relaxed text-gray-700 text-[13px]">
              
              {/* Document Banner */}
              <header className="border-b-4 border-double border-slate-900 pb-6 text-center">
                <div className="flex justify-center text-slate-900 mb-2">
                  <Scale size={36} className="text-blue-600 stroke-[1.5]" />
                </div>
                <h1 className="text-xl font-extrabold text-slate-900 uppercase tracking-widest font-sans">
                  System Architecture & Terms of Service
                </h1>
                <p className="text-[11px] font-bold text-gray-400 uppercase mt-1 tracking-wider">
                  PDFPro Application Suite • Global Conditions & Usage Scope
                </p>
                <div className="flex justify-center items-center gap-4 text-[10px] font-mono mt-4 text-slate-500 py-1 bg-slate-50 rounded-lg">
                  <span>SHA-256 Vault-ID: f9d23...8d12</span>
                  <span>|</span>
                  <span>Legal Project Framework: Node Isolated API</span>
                </div>
              </header>

              {/* Section Agreement */}
              <div id="sec-agreement" className="scroll-mt-12 space-y-3">
                <h2 className="text-sm font-extrabold text-slate-900 uppercase tracking-wider flex items-center gap-2 border-b pb-1">
                  <Scale size={14} className="text-blue-600" />
                  1. Agreement of Terms
                </h2>
                <p className="text-justify font-normal text-slate-700 leading-6">
                  {highlightText("Welcome to PDFPro. These Terms of Service ('Terms', 'Agreement') establish a legally binding framework between you ('User', 'Authorized Entity') and PDFPro Document Services. By visiting our application suite, downloading synthesized artifacts, rendering resumes, or initializing file operations (including Split PDF, Merge PDF, and Reduce Size Compress engines), you fully assent to compile with these standard terms. If any provision of this document contradicts your internal legal mandates, you must immediately terminate use of all services.")}
                </p>
                <p className="text-justify font-normal text-slate-700 leading-6">
                  {highlightText("We reserve the absolute authority to adjust, update, or revise sections of this agreement periodically. Users will receive notices of modification via version increments in the document header. Continued access of our application interface constitutes deliberate user assent to all modifications made.")}
                </p>
              </div>

              {/* Section License & Usage */}
              <div id="sec-license" className="scroll-mt-12 space-y-3">
                <h2 className="text-sm font-extrabold text-slate-900 uppercase tracking-wider flex items-center gap-2 border-b pb-1">
                  <BookOpen size={14} className="text-indigo-600" />
                  2. Intellectual Property License & Resource Usage
                </h2>
                <p className="text-justify font-normal text-slate-700 leading-6">
                  {highlightText("Subject to strict compliance with this Agreement, PDFPro grants you a worldwide, royalty-free, non-exclusive, non-transferable personal license to run, configure, and output document conversions within our sandbox. Under this license:")}
                </p>
                <ul className="list-disc list-inside pl-2 space-y-2 text-slate-600 font-medium">
                  <li>
                    <strong className="text-slate-800 font-bold">{highlightText("Absolute User File Ownership:")}</strong> {highlightText("We claim zero intellectual claim or rights over files uploaded to our servers, resume text inputs, or output split/merged products. You represent and warrant that you hold sufficient property authorization to process your uploads.")}
                  </li>
                  <li>
                    <strong className="text-slate-800 font-bold">{highlightText("Conversion Sandbox License:")}</strong> {highlightText("The software architecture, CSS design pairings, resume templates (including Slate, Serif, Tech, Creative presets), and custom graphic assets remain the exclusive patented property of PDFPro.")}
                  </li>
                  <li>
                    <strong className="text-slate-800 font-bold">{highlightText("Fair Personal Use:")}</strong> {highlightText("The resume builder permits unlimited manual updates, draft storage saves, and file system exports configuration.")}
                  </li>
                </ul>
              </div>

              {/* Section Acceptable use */}
              <div id="sec-acceptable" className="scroll-mt-12 space-y-3">
                <h2 className="text-sm font-extrabold text-slate-900 uppercase tracking-wider flex items-center gap-2 border-b pb-1">
                  <Activity size={14} className="text-emerald-600" />
                  3. Acceptable Use Guidelines
                </h2>
                <p className="text-justify font-normal text-slate-700 leading-6">
                  {highlightText("Our secure container deployment runs on high-speed scalable Cloud Run hosting. To ensure continuous access and smooth conversions for all developers, users must act in good faith and avoid placing heavy artificial loads on our infrastructure:")}
                </p>
                <ul className="list-disc list-inside pl-2 space-y-2 text-slate-600 leading-6">
                  <li>
                    <strong className="text-slate-800 font-bold">{highlightText("Infrastructure Integrity:")}</strong> {highlightText("You must not deploy automated curl scripts, browser scrapers, load generation engines, or automated REST clients to exploit our Split, Merge, or AI summary paths. Conversion flows are designed strictly for interactive client-side user experience.")}
                  </li>
                  <li>
                    <strong className="text-slate-800 font-bold">{highlightText("Volume Caps:")}</strong> {highlightText("We hold authority to limit single uploads to 100MB per file and cap repetitive API queries from identical IP addresses to safeguard server health.")}
                  </li>
                  <li>
                    <strong className="text-slate-800 font-bold">{highlightText("Malicious Vector Prevention:")}</strong> {highlightText("Uploaded document materials must be scanned to be free of trojans, script malware, shell commands, or active macro codes that attempt directory attacks on our isolated server container nodes.")}
                  </li>
                </ul>
              </div>

              {/* Section Prohibited Content */}
              <div id="sec-prohibited" className="scroll-mt-12 space-y-3">
                <h2 className="text-sm font-extrabold text-slate-900 uppercase tracking-wider flex items-center gap-2 border-b pb-1">
                  <ShieldAlert size={14} className="text-rose-600" />
                  4. Strictly Prohibited Content Categories
                </h2>
                <p className="text-justify font-normal text-slate-700 leading-6">
                  {highlightText("Users are strictly prohibited from utilizing dry-run server tools, loaders, or canvas vectors with any materials that violate international criminal guidelines, copyright structures, or user privacy regulations. Prohibited documents include:")}
                </p>
                <div className="grid grid-cols-2 gap-4 mt-3">
                  <div className="p-3 bg-rose-50/50 border border-rose-100 rounded-xl space-y-1">
                    <span className="font-extrabold text-rose-800 text-xs block">Infringing Protected Works:</span>
                    <span className="text-[11px] text-gray-600 block">Uploading copyrighted PDFs, pirated educational books, or proprietary software documentation without legal authorization is strictly banned.</span>
                  </div>
                  <div className="p-3 bg-red-50/50 border border-red-100 rounded-xl space-y-1">
                    <span className="font-extrabold text-red-800 text-xs block">Hazardous Storage Inputs:</span>
                    <span className="text-[11px] text-gray-600 block">Files compiling raw financial records, clear text password lists, credit card arrays, or high-risk military security specifications.</span>
                  </div>
                </div>
              </div>

              {/* Section Warranties */}
              <div id="sec-warranties" className="scroll-mt-12 space-y-3">
                <h2 className="text-sm font-extrabold text-slate-900 uppercase tracking-wider flex items-center gap-2 border-b pb-1">
                  <Lock size={14} className="text-blue-700" />
                  5. No-Warranties & Enterprise Liability Waivers
                </h2>
                <p className="text-justify font-normal text-slate-700 leading-6">
                  {highlightText("PDFPro services are provisioned strictly on an 'AS-IS' and 'AS-AVAILABLE' engineering basis. To the maximum scope permitted under common regulatory frameworks, PDFPro disclaims all warranties, express, implied, or standard. We make no guaranteed claims that:")}
                </p>
                <ul className="list-disc list-inside pl-2 space-y-2 text-slate-600 leading-6">
                  <li>
                    {highlightText("The document converters or AI generation summaries will map 100% accurate OCR translations without typo vectors.")}
                  </li>
                  <li>
                    {highlightText("Web connection tunnels or interactive resume previews will remain uninterrupted or immune to temporary network downtime.")}
                  </li>
                  <li>
                    {highlightText("Any local browser cache data (specifically typed resume drafting elements) will never expire or experience database sync failures.")}
                  </li>
                </ul>
              </div>

              {/* Section Termination */}
              <div id="sec-termination" className="scroll-mt-12 space-y-3">
                <h2 className="text-sm font-extrabold text-slate-900 uppercase tracking-wider flex items-center gap-2 border-b pb-1">
                  <Check size={14} className="text-amber-600" />
                  6. Session Expiration & Auto-Deletion Timers
                </h2>
                <p className="text-justify font-normal text-slate-700 leading-6">
                  {highlightText("In conformance with our security sandbox architecture, we enforce severe, non-negotiable data destruction timers to protect your privacy and reduce memory footprint:")}
                </p>
                <div className="border border-slate-150 rounded-xl overflow-hidden text-xs">
                  <div className="bg-slate-50 p-2.5 font-bold border-b text-slate-800 grid grid-cols-3">
                    <span>Operation Platform</span>
                    <span>Action Event</span>
                    <span>System Policy Constraint</span>
                  </div>
                  <div className="p-2.5 grid grid-cols-3 border-b text-gray-600 font-mono text-[11px]">
                    <span className="font-bold text-slate-800">Split & Merge Engine</span>
                    <span>Upload completion</span>
                    <span>Hard delete from disk after 60 mins</span>
                  </div>
                  <div className="p-2.5 grid grid-cols-3 text-gray-600 font-mono text-[11px]">
                    <span className="font-bold text-slate-800">Resume Creator Tool</span>
                    <span>Draft persistence</span>
                    <span>Persisted only on client's local storage</span>
                  </div>
                </div>
                <p className="text-[11.5px] italic text-slate-500 mt-2 text-center">
                  You hold full command over your sessions. Deleting cookies or clicking 'Logout' will systematically flush active identification states from the web container environment.
                </p>
              </div>

              {/* Secure Footer Acknowledgement */}
              <footer className="border-t pt-8 text-center space-y-2 mt-8 text-slate-450 text-[10px]">
                <p className="font-bold uppercase tracking-widest text-slate-700">Service Integrity Agreement</p>
                <div className="flex justify-center gap-3">
                  <span className="border px-2 py-0.5 rounded bg-slate-50 font-mono">SA-828689</span>
                  <span className="border px-2 py-0.5 rounded bg-slate-50 font-mono">CCPA Approved</span>
                  <span className="border px-2 py-0.5 rounded bg-slate-50 font-mono">HTTPS Secured</span>
                </div>
                <p className="max-w-[480px] mx-auto leading-relaxed mt-2 text-gray-400">
                  © 2026 PDFPro Document Vault Services LLC. All rights not explicitly granted herein are reserved. Your usage is monitored to ensure fair system resource allocation.
                </p>
              </footer>

            </article>
          </div>

          {/* INSPECTOR SIDEBAR: Right side beautiful metadata checklist */}
          <div className="w-[20%] bg-slate-50/50 border-l border-gray-150 p-5 hidden xl:flex flex-col justify-between shrink-0">
            <div className="space-y-6">
              <div>
                <h4 className="text-[10px] font-extrabold text-slate-400 tracking-wider uppercase mb-3">
                  Agreement Badges
                </h4>
                <div className="p-3 bg-white border border-gray-150 rounded-xl space-y-2.5">
                  <div className="flex items-center gap-2 text-xs font-bold text-gray-800">
                    <Check size={14} className="text-blue-600 bg-blue-100 p-0.5 rounded-full" />
                    <span>No Watermarks</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs font-bold text-gray-800">
                    <Check size={14} className="text-blue-600 bg-blue-100 p-0.5 rounded-full" />
                    <span>No Lock-Ins</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs font-bold text-gray-800">
                    <Check size={14} className="text-blue-600 bg-blue-100 p-0.5 rounded-full" />
                    <span>GDPR Compliant</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs font-bold text-gray-800">
                    <Check size={14} className="text-blue-600 bg-blue-100 p-0.5 rounded-full" />
                    <span>Fair-use Policy</span>
                  </div>
                </div>
              </div>

              <div>
                <h4 className="text-[10px] font-extrabold text-slate-400 tracking-wider uppercase mb-2.5">
                  Secure Access Link
                </h4>
                <p className="text-[10px] text-gray-500 leading-relaxed mb-3">
                  Share this public agreement directly with your internal legal compliance or operational auditing parameters.
                </p>
                <button 
                  onClick={handleCopyLink}
                  className="w-full py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-lg text-xs font-bold transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-sm"
                >
                  <Share2 size={12} /> Share Terms Doc
                </button>
              </div>

              <div className="border-t border-gray-100 pt-4 text-center">
                <p className="text-[10px] text-gray-400 font-mono">
                  File Size: 1.12 MB
                </p>
                <p className="text-[10px] text-gray-400 font-mono mt-0.5">
                  Document: Legal Contract
                </p>
              </div>
            </div>

            <div className="text-center">
              <span className="text-[11px] font-bold text-slate-700 bg-slate-200/50 px-2.5 py-1 rounded-full uppercase">
                ⚙️ Legal Sandbox
              </span>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
}
