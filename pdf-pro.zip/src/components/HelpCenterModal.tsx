import React, { useState, useRef, useEffect } from 'react';
import { 
  X, Search, HelpCircle, Check, Copy, Download, Share2, Scale, Lock, 
  ChevronRight, Eye, Calendar, RefreshCcw, FileCheck, ExternalLink,
  BookOpen, Heart, Activity, Globe, Info, MessageSquare, AlertCircle
} from 'lucide-react';

interface HelpCenterModalProps {
  onClose: () => void;
}

interface OutlineSection {
  id: string;
  title: string;
  sub: string;
}

const HELP_OUTLINE: OutlineSection[] = [
  { id: 'sec-getting-started', title: '1. Getting Started Guide', sub: 'Navigating PDFPro and core workflows' },
  { id: 'sec-splitter-merger', title: '2. PDF Splitter & Merger', sub: 'Page ranges, output modes & sizes' },
  { id: 'sec-compressor-kb', title: '3. Compression & Target KB Limits', sub: 'How to lock exactly 50KB or 100KB' },
  { id: 'sec-resume-creator', title: '4. CV Resume Customizer', sub: 'Formatting, drafts & JSON exports' },
  { id: 'sec-ai-summary', title: '5. AI Helper, Summaries & Trans', sub: 'Gemini security, quotas & guidelines' },
  { id: 'sec-trouble', title: '6. Common Troubleshooting FAQs', sub: 'Popup errors, corrupt files & download solutions' }
];

export default function HelpCenterModal({ onClose }: HelpCenterModalProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeSection, setActiveSection] = useState('sec-getting-started');
  const [copied, setCopied] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  // Auto detect active section on scroll
  useEffect(() => {
    const handleScroll = () => {
      if (!scrollContainerRef.current) return;
      
      const container = scrollContainerRef.current;
      const scrollPos = container.scrollTop + 120; // offset

      for (const sect of HELP_OUTLINE) {
        const el = container.querySelector(`#${sect.id}`);
        if (el) {
          const top = (el as HTMLElement).offsetTop;
          const height = el.getBoundingClientRect().height;
          if (scrollPos >= top && scrollPos < top + height) {
            setActiveSection(sect.id);
            break;
          }
        }
      }
    };

    const container = scrollContainerRef.current;
    if (container) {
      container.addEventListener('scroll', handleScroll);
    }
    return () => {
      if (container) {
        container.removeEventListener('scroll', handleScroll);
      }
    };
  }, []);

  const scrollToSect = (id: string) => {
    setActiveSection(id);
    const el = scrollContainerRef.current?.querySelector(`#${id}`);
    if (el && scrollContainerRef.current) {
      scrollContainerRef.current.scrollTo({
        top: (el as HTMLElement).offsetTop - 15,
        behavior: 'smooth'
      });
    }
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(window.location.href + '#help-center');
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    setDownloadSuccess(true);
    setTimeout(() => {
      setDownloadSuccess(false);
      // Trigger native browser print which formats automatically as page-perfect PDF
      window.print();
    }, 1000);
  };

  // Helper function to dynamically highlight query text inside raw texts
  const highlightText = (text: string) => {
    if (!searchQuery.trim()) return text;
    const regex = new RegExp(`(${searchQuery.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&')})`, 'gi');
    const parts = text.split(regex);
    return (
      <>
        {parts.map((part, i) => 
          regex.test(part) ? (
            <mark key={i} className="bg-amber-100 py-0.5 px-1 rounded-sm text-gray-900 border border-amber-300 select-all font-semibold">
              {part}
            </mark>
          ) : part
        )}
      </>
    );
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[110] flex items-center justify-center p-4 overflow-hidden animate-fadeIn text-left">
      <div className="bg-white rounded-2xl w-full max-w-[1250px] h-[92vh] flex flex-col shadow-2xl relative animate-slideUp">
        
        {/* Dropbox Paper Style Control Header */}
        <div className="border-b border-gray-150 px-6 py-4 flex items-center justify-between bg-white shrink-0">
          <div className="flex items-center gap-3">
            {/* Dropbox-styled file icon with active color */}
            <div className="bg-amber-600 text-white p-2.5 rounded-lg shadow-md hover:bg-amber-700 transition-colors">
              <HelpCircle size={20} className="animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[11px] font-extrabold bg-amber-100 text-amber-800 uppercase px-2 py-0.5 rounded-md tracking-wider">
                  Paper Doc File (Read-Only)
                </span>
                <span className="text-xs text-gray-400 font-mono flex items-center gap-1">
                  <Activity size={12} className="text-amber-500" /> Live Synchronized Knowledge Guide
                </span>
              </div>
              <h2 className="text-base font-extrabold text-gray-900 flex items-center gap-2 mt-0.5 font-sans">
                PDFPro_Knowledgebase_Help_Center_V4.pdf
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            {/* Interactive Keyword Search Filter */}
            <div className="relative hidden md:block">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={14} />
              <input 
                type="text" 
                placeholder="Search solutions keywords (e.g. split, resume, compress, limit)..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9 pr-4 py-1.5 w-64 bg-slate-100 rounded-lg text-xs outline-none focus:bg-white border border-transparent focus:border-amber-400 transition-all font-medium text-gray-800"
              />
              {searchQuery && (
                <button 
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[10px] font-bold text-gray-400 hover:text-gray-600"
                >
                  Clear
                </button>
              )}
            </div>

            <div className="h-6 w-[1px] bg-gray-200 mx-1 hidden md:block"></div>

            <button 
              onClick={handleCopyLink}
              className={`px-3 py-1.5 rounded-lg border text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                copied 
                  ? 'bg-emerald-50 border-emerald-300 text-emerald-700' 
                  : 'border-gray-200 bg-white hover:bg-slate-50 text-gray-700'
              }`}
            >
              {copied ? <Check size={14} /> : <Copy size={13} />}
              {copied ? 'Link Copied!' : 'Copy Help Link'}
            </button>

            <button 
              onClick={handleDownload}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold text-white flex items-center gap-1.5 transition-all cursor-pointer shadow-sm ${
                downloadSuccess
                  ? 'bg-emerald-600'
                  : 'bg-amber-600 hover:bg-amber-700'
              }`}
            >
              {downloadSuccess ? (
                <>
                  <Check size={14} /> Generating Perfect Page Print...
                </>
              ) : (
                <>
                  <Download size={13} /> Secure Draft PDF / Print
                </>
              )}
            </button>

            <button 
              onClick={onClose}
              className="p-1.5 bg-slate-100 hover:bg-rose-50 text-gray-500 hover:text-rose-600 rounded-lg transition-transform cursor-pointer ml-1"
              title="Close Help Window"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Modal Secondary Context Banner */}
        <div className="bg-slate-50 border-b border-gray-150 px-6 py-2.5 flex justify-between items-center text-xs shrink-0 font-sans">
          <p className="text-gray-600 flex items-center gap-1.5 font-medium">
            <Lock size={12} className="text-indigo-600" />
            <span className="font-bold text-gray-800">Dynamic User Help Desk:</span> Learn how to lock custom KB limits, manage multi-files, and export crisp resume blueprints.
          </p>
          <div className="flex gap-4 text-[11px] text-gray-500 font-mono font-medium">
            <span>LAST REVISED: JUNE 06, 2026</span>
            <span>ARTICLE CERTIFIED: KB-932840</span>
          </div>
        </div>

        {/* Dynamic Multi-Pane Layout */}
        <div className="flex-1 flex overflow-hidden min-h-0">
          
          {/* LOBBYISTS SIDEBAR: Document Outline navigation */}
          <div className="w-[28%] bg-slate-50 border-r border-gray-150 flex flex-col justify-between shrink-0">
            {/* Outline list */}
            <div className="p-4 overflow-y-auto space-y-1">
              <h4 className="text-[10px] font-extrabold text-slate-400 tracking-wider uppercase mb-3.5 px-2">
                Knowledgebase Index
              </h4>
              <nav className="space-y-1">
                {HELP_OUTLINE.map((sect) => (
                  <button
                    key={sect.id}
                    onClick={() => scrollToSect(sect.id)}
                    className={`w-full text-left p-3 rounded-xl transition-all flex flex-col cursor-pointer ${
                      activeSection === sect.id 
                        ? 'bg-white border border-gray-200/80 shadow-sm'
                        : 'hover:bg-slate-200/60'
                    }`}
                  >
                    <span className={`text-[11.5px] font-extrabold tracking-tight ${
                      activeSection === sect.id ? 'text-amber-700' : 'text-gray-700'
                    }`}>
                      {sect.title}
                    </span>
                    <span className="text-[10px] text-gray-450 mt-0.5 font-medium truncate w-[210px]">
                      {sect.sub}
                    </span>
                  </button>
                ))}
              </nav>

              {/* Extra Document Stats */}
              <div className="mt-8 border-t border-gray-200 pt-5 space-y-3 px-2">
                <h4 className="text-[10px] font-extrabold text-slate-400 tracking-wider uppercase">
                  Service Level Agreement
                </h4>
                <div className="space-y-2 text-[11px] font-medium text-gray-650">
                  <div className="flex justify-between items-center">
                    <span className="flex items-center gap-1"><Calendar size={12} /> Last Verified</span>
                    <span className="font-mono text-gray-900 font-bold">June 2026</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="flex items-center gap-1"><RefreshCcw size={12} /> Sync Interval</span>
                    <span>Real-time</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="flex items-center gap-1"><BookOpen size={12} /> Setup Effort</span>
                    <span>90 Seconds</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick trust seal at baseline */}
            <div className="p-4 border-t border-gray-205 bg-slate-100/60 space-y-2 text-center text-[10px] text-gray-500 font-medium">
              <div className="flex justify-center gap-1 text-amber-600 font-bold uppercase tracking-wider">
                <FileCheck size={13} /> Live System Support
              </div>
              <p className="leading-relaxed px-2 text-gray-400">
                Facing persistent errors? Read below or download the draft help PDF instantly.
              </p>
            </div>
          </div>

          {/* MAIN ARTICLE PREVIEWER: Beautiful high-fidelity Paper styled Canvas */}
          <div 
            ref={scrollContainerRef}
            className="flex-1 overflow-y-auto p-12 bg-white flex justify-center scroll-smooth outline-none select-text"
          >
            {/* Mimics a physical A4 document centered inside Dropbox viewer */}
            <article className="w-full max-w-[760px] pb-32 space-y-8 font-sans leading-relaxed text-gray-700 text-[13px]">
              
              {/* Document Banner */}
              <header className="border-b-4 border-double border-slate-900 pb-6 text-center">
                <div className="flex justify-center text-slate-900 mb-2">
                  <HelpCircle size={36} className="text-amber-600 stroke-[1.5]" />
                </div>
                <h1 className="text-xl font-extrabold text-slate-900 uppercase tracking-widest font-sans">
                  System Handbook & Solutions center
                </h1>
                <p className="text-[11px] font-bold text-gray-400 uppercase mt-1 tracking-wider">
                  PDFPro Application Manual • Comprehensive Answers & Setup Guidelines
                </p>
                <div className="flex justify-center items-center gap-4 text-[10px] font-mono mt-4 text-slate-500 py-1 bg-slate-50 rounded-lg">
                  <span>Author relative: Staff Support Desk</span>
                  <span>|</span>
                  <span>System Support Status: Online ●</span>
                </div>
              </header>

              {/* Section 1 */}
              <div id="sec-getting-started" className="scroll-mt-12 space-y-3">
                <h2 className="text-sm font-extrabold text-slate-900 uppercase tracking-wider flex items-center gap-2 border-b pb-1">
                  <Info size={14} className="text-amber-600" />
                  1. Getting Started Guide
                </h2>
                <p className="text-justify font-normal text-slate-700 leading-6">
                  {highlightText("Welcome to PDFPro Help Center. This manual is structured as an interactive Dropbox Document to help you master the execution of our server-side sandboxed PDF toolset. Our toolbox features immediate offline-first operations where security, high performance, and ease of use are guaranteed. To initiate tools, drag & drop your files in any active visual box, configure constraints, and tap the operation trigger.")}
                </p>
                <p className="text-justify font-normal text-slate-700 leading-6">
                  {highlightText("You do not require complex credit signups to leverage active features. To maximize performance, we recommend utilizing modern web browsers (Chrome, Edge, or Firefox) or opening the application outside preview containers if popup permissions are flagged.")}
                </p>
              </div>

              {/* Section 2 */}
              <div id="sec-splitter-merger" className="scroll-mt-12 space-y-3">
                <h2 className="text-sm font-extrabold text-slate-900 uppercase tracking-wider flex items-center gap-2 border-b pb-1">
                  <Scale size={14} className="text-indigo-600" />
                  2. PDF Splitter & Merger Operations
                </h2>
                <p className="text-justify font-normal text-slate-700 leading-6">
                  {highlightText("Our high-speed document compiler operates locally inside sandboxed memory container nodes. To perform division or concatenation vectors efficiently:")}
                </p>
                <ul className="list-disc list-inside pl-2 space-y-2 text-slate-600 font-medium">
                  <li>
                    <strong className="text-slate-800 font-bold">{highlightText("Splitting PDFs:")}</strong> {highlightText("You can extract specified pages (e.g. page 3-5), separate all pages individually, or write custom page groups. Simply insert your file, adjust structural boundaries, and retrieve the download.")}
                  </li>
                  <li>
                    <strong className="text-slate-800 font-bold">{highlightText("Merging Multiple PDFs:")}</strong> {highlightText("Upload several files concurrently. The visual controller allows you to drag to sort, change the compilation layout index, delete unwanted draft pages, and merge them back into a single document.")}
                  </li>
                  <li>
                    <strong className="text-slate-800 font-bold">{highlightText("Security Isolation:")}</strong> {highlightText("Uploaded files are automatically deleted after exactly 60 minutes. Your source materials are never readable by automated bots.")}
                  </li>
                </ul>
              </div>

              {/* Section 3 */}
              <div id="sec-compressor-kb" className="scroll-mt-12 space-y-3">
                <h2 className="text-sm font-extrabold text-slate-900 uppercase tracking-wider flex items-center gap-2 border-b pb-1">
                  <Lock size={14} className="text-blue-700" />
                  3. Compression & Target KB Limits
                </h2>
                <p className="text-justify font-normal text-slate-700 leading-6">
                  {highlightText("Many official portals (government, university, visa processing counters) require files to be under specific sizes (e.g., strictly below 50KB or 100KB). PDFPro includes specialized Byte Padding and Compression levels to solve this:")}
                </p>
                <ul className="list-disc list-inside pl-2 space-y-2 text-slate-600 leading-6">
                  <li>
                    <strong className="text-slate-800 font-bold">{highlightText("Recommended Compression:")}</strong> {highlightText("Optimizes structure and minimizes size while preserving perfect image and text crispness (Best quality-to-size ratio).")}
                  </li>
                  <li>
                    <strong className="text-slate-800 font-bold">{highlightText("Extreme Compression:")}</strong> {highlightText("Squeezes document metadata aggressively to standard minimum limits. Preferred when size requirements are extremely strict.")}
                  </li>
                  <li>
                    <strong className="text-slate-800 font-bold">{highlightText("Dynamic KB Lock Limit:")}</strong> {highlightText("Toggle 'Limit Target KB Size' and enter a specific target (e.g., 50). The compiler will adjust the downscaling quality and inject/shred internal metadata to align output size precisely within your constraints.")}
                  </li>
                </ul>
                <div className="bg-slate-50 border border-slate-200 p-3.5 rounded-xl text-[11px] font-mono leading-relaxed space-y-1">
                  <span className="text-slate-800 font-extrabold uppercase tracking-wider block">💡 Best Practice for Target KB limits:</span>
                  <span className="text-gray-500 block">If compressing highly detailed image files, use "Moderate compression" with "Custom target KB" activated to prevent visual distortion.</span>
                </div>
              </div>

              {/* Section 4 */}
              <div id="sec-resume-creator" className="scroll-mt-12 space-y-3">
                <h2 className="text-sm font-extrabold text-slate-900 uppercase tracking-wider flex items-center gap-2 border-b pb-1">
                  <BookOpen size={14} className="text-emerald-600" />
                  4. Professional CV Resume Creator
                </h2>
                <p className="text-justify font-normal text-slate-700 leading-6">
                  {highlightText("Build vectors and custom digital outputs via our pre-configured templates. You can formulate resume drafts in minutes without signing up for expensive premium accounts. Features include:")}
                </p>
                <ul className="list-disc list-inside pl-2 space-y-2 text-slate-600 leading-6">
                  <li>
                    <strong className="text-slate-800 font-bold">{highlightText("10,000+ Combinations Layout:")}</strong> {highlightText("Toggle among Minimalist Slate, Editorial Serif, Modern Tech, and Creative Pastel designs. Spacing ratios are calculated with Desktop precision.")}
                  </li>
                  <li>
                    <strong className="text-slate-800 font-bold">{highlightText("Local Draft Saves:")}</strong> {highlightText("Inputs copy instantly to localStorage. Closing your tab or browser doesn't discard typed entries.")}
                  </li>
                  <li>
                    <strong className="text-slate-800 font-bold">{highlightText("Backup Export (JSON):")}</strong> {highlightText("Save your details safely in a lightweight JSON backup. Reload it at any time to update your resume without manually retyping your data.")}
                  </li>
                </ul>
              </div>

              {/* Section 5 */}
              <div id="sec-ai-summary" className="scroll-mt-12 space-y-3">
                <h2 className="text-sm font-extrabold text-slate-900 uppercase tracking-wider flex items-center gap-2 border-b pb-1">
                  <Activity size={14} className="text-indigo-650" />
                  5. AI Helper, Summaries & Trans Handshakes
                </h2>
                <p className="text-justify font-normal text-slate-700 leading-6">
                  {highlightText("We proxy queries safely to global high-tier pipelines via secure Gemini handshakes. If you trigger Summarization or Translate tools, the parsed text is compiled into structured server requests:")}
                </p>
                <ul className="list-decimal list-inside pl-2 space-y-2 text-slate-600 leading-6">
                  <li>
                    <strong className="text-slate-800 font-bold">{highlightText("Quotas & Response Times:")}</strong> {highlightText("Most summaries render in under 4 seconds. Heavy publications (over 200 pages) may trigger API processing timeouts.")}
                  </li>
                  <li>
                    <strong className="text-slate-800 font-bold">{highlightText("Exempt from System Training:")}</strong> {highlightText("Under our partner agreements, inputs provided in your sessions are never cached or leveraged to construct public LLM models.")}
                  </li>
                </ul>
              </div>

              {/* Section 6 */}
              <div id="sec-trouble" className="scroll-mt-12 space-y-3">
                <h2 className="text-sm font-extrabold text-slate-900 uppercase tracking-wider flex items-center gap-2 border-b pb-1">
                  <AlertCircle size={14} className="text-rose-600" />
                  6. Common Troubleshooting FAQs
                </h2>
                <p className="text-justify font-normal text-slate-700 leading-6">
                  {highlightText("Review this diagnostic report list to resolve issues instantly without waiting for customer engineers:")}
                </p>
                <div className="space-y-4">
                  <div className="border border-slate-150 p-4 rounded-xl bg-slate-50/50">
                    <span className="font-extrabold text-slate-900 block text-xs">Q: PDF Download doesn't launch when I click download?</span>
                    <p className="text-[11.5px] text-gray-650 mt-1">
                      A: Double-check if secure popups are blocked by your browser extensions (e.g., ad blockers). Allow popups on our domain, or click 'Open in New Tab' to bypass iframe rendering constraints.
                    </p>
                  </div>
                  <div className="border border-slate-150 p-4 rounded-xl bg-slate-50/50">
                    <span className="font-extrabold text-slate-900 block text-xs">Q: What happens if I clear my cookies? Is my resume deleted?</span>
                    <p className="text-[11.5px] text-gray-650 mt-1">
                      A: Yes, clearing browser cookies and localStorage database wipes typed resume drafts. Make sure to download a "Save Backup (JSON)" file to keep a permanent copy of your content.
                    </p>
                  </div>
                  <div className="border border-slate-150 p-4 rounded-xl bg-slate-50/50">
                    <span className="font-extrabold text-slate-900 block text-xs">Q: I see a 'Server Payload limits' error during file upload?</span>
                    <p className="text-[11.5px] text-gray-650 mt-1">
                      A: Maximum file size upload is limited to 100MB per file to maintain continuous execution health on Cloud Run container nodes.
                    </p>
                  </div>
                </div>
              </div>

              {/* Secure Footer Acknowledgement */}
              <footer className="border-t pt-8 text-center space-y-2 mt-8 text-slate-450 text-[10px]">
                <p className="font-bold uppercase tracking-widest text-slate-700">Service Help Handbook</p>
                <div className="flex justify-center gap-3">
                  <span className="border px-2 py-0.5 rounded bg-slate-50 font-mono">CCPA Compliant</span>
                  <span className="border px-2 py-0.5 rounded bg-slate-50 font-mono">SSL Secure 2048</span>
                  <span className="border px-2 py-0.5 rounded bg-slate-50 font-mono">Sandbox Approved</span>
                </div>
                <p className="max-w-[480px] mx-auto leading-relaxed mt-2 text-gray-400">
                  © 2026 PDFPro Document Vault Services LLC. If you continue to experience technical concerns, open an issue report via our standard support endpoints.
                </p>
              </footer>

            </article>
          </div>

          {/* INSPECTOR SIDEBAR: Right side beautiful metadata checklist */}
          <div className="w-[20%] bg-slate-50/50 border-l border-gray-150 p-5 hidden xl:flex flex-col justify-between shrink-0">
            <div className="space-y-6">
              <div>
                <h4 className="text-[10px] font-extrabold text-slate-400 tracking-wider uppercase mb-3">
                  System Verifications
                </h4>
                <div className="p-3 bg-white border border-gray-150 rounded-xl space-y-2.5">
                  <div className="flex items-center gap-2 text-xs font-bold text-gray-800">
                    <Check size={14} className="text-amber-600 bg-amber-100 p-0.5 rounded-full" />
                    <span>Dynamic Layouts</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs font-bold text-gray-800">
                    <Check size={14} className="text-amber-600 bg-amber-100 p-0.5 rounded-full" />
                    <span>No Watermark CV</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs font-bold text-gray-800">
                    <Check size={14} className="text-amber-600 bg-amber-100 p-0.5 rounded-full" />
                    <span>Sandbox Safe</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs font-bold text-gray-800">
                    <Check size={14} className="text-amber-600 bg-amber-100 p-0.5 rounded-full" />
                    <span>JSON Backups</span>
                  </div>
                </div>
              </div>

              <div>
                <h4 className="text-[10px] font-extrabold text-slate-400 tracking-wider uppercase mb-2.5">
                  Secure Sharing Link
                </h4>
                <p className="text-[10px] text-gray-500 leading-relaxed mb-3">
                  Share this public handbook guide directly with team members or users experiencing performance roadblocks.
                </p>
                <button 
                  onClick={handleCopyLink}
                  className="w-full py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-lg text-xs font-bold transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-sm"
                >
                  <Share2 size={12} /> Share Manual Doc
                </button>
              </div>

              <div className="border-t border-gray-100 pt-4 text-center">
                <p className="text-[10px] text-gray-450 font-mono">
                  File Size: 984 KB
                </p>
                <p className="text-[10px] text-gray-450 font-mono mt-0.5">
                  Document: Help Article
                </p>
              </div>
            </div>

            <div className="text-center">
              <span className="text-[11px] font-bold text-slate-700 bg-slate-200/50 px-2.5 py-1 rounded-full uppercase">
                📖 Public Guide
              </span>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
}
