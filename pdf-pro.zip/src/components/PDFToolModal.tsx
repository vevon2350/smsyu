import React, { useState, useRef } from 'react';
import { X, Upload, FileText, Trash2, Settings, ArrowUp, ArrowDown, Sparkles, Download, Loader2, CheckCircle, Minimize2 } from 'lucide-react';

interface ToolProps {
  tool: string;
  title: string;
  onClose: () => void;
}

export default function PDFToolModal({ tool, title, onClose }: ToolProps) {
  const [files, setFiles] = useState<File[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [options, setOptions] = useState('');
  const [pageRanges, setPageRanges] = useState('');
  const [successMsg, setSuccessMsg] = useState(false);
  const [downloadUrl, setDownloadUrl] = useState<string | null>(null);
  const [downloadFilename, setDownloadFilename] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  // States for Compress (Reduce Size) tool customization
  const [compressMode, setCompressMode] = useState<'decrease' | 'increase'>('decrease');
  const [compressLevel, setCompressLevel] = useState('recommended');
  const [targetSizeOn, setTargetSizeOn] = useState(false);
  const [targetKB, setTargetKB] = useState('50');
  const [customTargetKB, setCustomTargetKB] = useState('');
  const [resizePageOn, setResizePageOn] = useState(false);
  const [resizeWidth, setResizeWidth] = useState('800');
  const [resizeHeight, setResizeHeight] = useState('1100');
  const [resizeUnit, setResizeUnit] = useState<'px' | 'cm'>('px');

  const getAcceptedTypes = (toolId: string) => {
    if (toolId === 'jpg-to-pdf') return '.jpg,.jpeg,.png';
    if (toolId === 'png-to-pdf') return '.png';
    if (toolId === 'word-to-pdf') return '.doc,.docx';
    if (toolId === 'ppt-to-pdf') return '.ppt,.pptx';
    if (toolId === 'excel-to-pdf') return '.xls,.xlsx';
    if (toolId === 'html-to-pdf') return '.html,.htm';
    if (toolId === 'txt-to-pdf') return '.txt';
    return '.pdf';
  };

  const validateFile = (file: File): Promise<{ valid: boolean; message?: string }> => {
    // Check size
    if (file.size === 0) {
      return Promise.resolve({ 
        valid: false, 
        message: `The file "${file.name}" is empty (0 bytes). Please upload a valid document.\n(Kripya sahi document upload karein, yeh khali file hai.)` 
      });
    }
    
    // Check PDF header physically if it is a pdf format
    if (file.name.toLowerCase().endsWith('.pdf')) {
      return new Promise((resolve) => {
        const reader = new FileReader();
        reader.onloadend = (e) => {
          const arr = new Uint8Array(e.target?.result as ArrayBuffer);
          if (arr.length < 4) {
            resolve({ 
              valid: false, 
              message: `The file "${file.name}" is corrupted or too small to be a PDF.\n(Kripya valid PDF document hi upload karein.)` 
            });
            return;
          }
          const header = String.fromCharCode(arr[0], arr[1], arr[2], arr[3]);
          if (header !== '%PDF') {
            resolve({ 
              valid: false, 
              message: `The file "${file.name}" does not have a valid PDF header structure. It may be corrupted or not a real PDF document.\n(Aapne jo file upload ki hai woh ek valid PDF nahi hai. Kripya valid PDF document hi upload karein.)` 
            });
          } else {
            resolve({ valid: true });
          }
        };
        reader.onerror = () => resolve({ 
          valid: false, 
          message: `Could not read file "${file.name}".\n(Kripya sahi file chunein.)` 
        });
        reader.readAsArrayBuffer(file.slice(0, 5));
      });
    }
    
    return Promise.resolve({ valid: true });
  };

  const handleFiles = async (newFiles: FileList | null) => {
    if (newFiles) {
      const array = Array.from(newFiles);
      const acceptedTypes = getAcceptedTypes(tool);
      const allowedExtensions = acceptedTypes.split(',').map(ext => ext.trim().toLowerCase());
      const invalidFiles = array.filter(file => {
        const ext = '.' + file.name.split('.').pop()?.toLowerCase();
        return !allowedExtensions.includes(ext);
      });

      if (invalidFiles.length > 0) {
        alert(`Invalid file selected! Please upload files with these formats: ${acceptedTypes}\n(Kripya sahi format ki file upload karein: ${acceptedTypes})`);
        return;
      }

      // Physical content verification
      const validatedFiles: File[] = [];
      for (const file of array) {
        const check = await validateFile(file);
        if (!check.valid) {
          alert(check.message);
          return;
        }
        validatedFiles.push(file);
      }

      setFiles(prev => [...prev, ...validatedFiles]);
    }
  };

  const removeFile = (index: number) => {
    setFiles(prev => prev.filter((_, i) => i !== index));
  };

  const moveFileUp = (index: number) => {
    if (index === 0) return;
    setFiles(prev => {
      const copy = [...prev];
      const temp = copy[index];
      copy[index] = copy[index - 1];
      copy[index - 1] = temp;
      return copy;
    });
  };

  const moveFileDown = (index: number) => {
    if (index === files.length - 1) return;
    setFiles(prev => {
      const copy = [...prev];
      const temp = copy[index];
      copy[index] = copy[index + 1];
      copy[index + 1] = temp;
      return copy;
    });
  };

  const generateSamplePDF = async () => {
    try {
      const { PDFDocument } = await import('pdf-lib');
      const pdfDoc = await PDFDocument.create();
      const page = pdfDoc.addPage([595, 842]);
      
      const num = Math.floor(Math.random() * 90) + 10;
      page.drawText('PDFPro Online System', { x: 50, y: 780, size: 24 });
      page.drawText('DURABLE SECURE VERIFIABLE DEMO PDF SHEET', { x: 50, y: 745, size: 10 });
      page.drawText(`File Reference Token: PDFPRO-SAMPLE-${num}`, { x: 50, y: 720, size: 11 });
      page.drawText(`Generated on Local Client: ${new Date().toLocaleString()}`, { x: 50, y: 700, size: 10 });
      
      page.drawText('Welcome to your professional high-fidelity PDF editing dashboard.', { x: 50, y: 640, size: 12 });
      page.drawText('This document contains custom structured paragraphs and metadata schemas.', { x: 50, y: 615, size: 11 });
      page.drawText('You can merge multiple of these files, split page ranges, redact rows,', { x: 50, y: 590, size: 11 });
      page.drawText('rotate layout cards, or compress binary structures successfully!', { x: 50, y: 565, size: 11 });
      
      page.drawRectangle({
        x: 45,
        y: 150,
        width: 505,
        height: 380,
        borderWidth: 1,
        opacity: 0.1,
      });
      
      page.drawText('This document is certified compliant for standard PDF/A secure workflows.', { x: 65, y: 490, size: 10 });
      
      const pdfBytes = await pdfDoc.save();
      const blob = new Blob([pdfBytes], { type: 'application/pdf' });
      // Avoid calling the "new File" constructor completely to prevent "Illegal constructor" in sandboxed environments.
      const customFile = blob as any;
      customFile.name = `sample_work_file_${num}.pdf`;
      customFile.lastModified = Date.now();
      const file = customFile as File;
      
      const multipleActions = ['merge', 'jpg-to-pdf'];
      if (multipleActions.includes(tool)) {
        setFiles(prev => [...prev, file]);
      } else {
        setFiles([file]);
      }
    } catch (err: any) {
      console.error(err);
      alert('Error generating dynamic sample document: ' + err.message);
    }
  };

  const handleProcess = async () => {
    if (files.length === 0) return;
    setIsProcessing(true);
    setSuccessMsg(false);
    setDownloadUrl(null);
    setDownloadFilename('');

    // Serialize compress tool configurations to JSON
    let finalOptions = options;
    if (tool === 'compress') {
      const configObj = {
        mode: compressMode,
        compressLevel: compressLevel,
        targetSizeOn: targetSizeOn,
        targetKB: targetSizeOn ? (targetKB === 'custom' ? parseFloat(customTargetKB) || 50 : parseFloat(targetKB)) : 0,
        resizePageOn: resizePageOn,
        resizeWidth: parseFloat(resizeWidth) || 0,
        resizeHeight: parseFloat(resizeHeight) || 0,
        resizeUnit: resizeUnit
      };
      finalOptions = JSON.stringify(configObj);
    }

    const formData = new FormData();
    files.forEach(file => formData.append('files', file, file.name));
    formData.append('tool', tool);
    formData.append('options', finalOptions);
    formData.append('pageRanges', pageRanges);

    try {
      const response = await fetch('/api/process-pdf', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        const errorJson = await response.json().catch(() => ({}));
        throw new Error(errorJson.error || 'Processing failed');
      }

      const contentType = response.headers.get('content-type') || '';
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      setDownloadUrl(url);
      
      let extension = 'pdf';
      if (contentType.includes('application/zip')) {
        extension = 'zip';
      } else if (contentType.includes('image/png')) {
        extension = 'png';
      } else if (contentType.includes('image/jpeg')) {
        extension = 'jpg';
      } else if (contentType.includes('application/vnd.openxmlformats-officedocument.wordprocessingml.document')) {
        extension = 'docx';
      } else if (contentType.includes('application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')) {
        extension = 'xlsx';
      } else if (contentType.includes('application/vnd.openxmlformats-officedocument.presentationml.presentation')) {
        extension = 'pptx';
      } else if (contentType.includes('text/html')) {
        extension = 'html';
      } else if (contentType.includes('text/plain')) {
        extension = 'txt';
      } else {
        // Fallback to tool-based mapping
        if (tool === 'pdf-to-jpg') extension = 'jpg';
        else if (tool === 'pdf-to-png') extension = 'png';
        else if (tool === 'pdf-to-word') extension = 'docx';
        else if (tool === 'pdf-to-ppt') extension = 'pptx';
        else if (tool === 'pdf-to-excel') extension = 'xlsx';
        else if (tool === 'pdf-to-html') extension = 'html';
        else if (tool === 'pdf-to-txt') extension = 'txt';
      }

      const filename = `${title.replace(/\s+/g, '_').toLowerCase()}_result.${extension}`;
      setDownloadFilename(filename);
      setSuccessMsg(true);

      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      a.click();
    } catch (error: any) {
      console.error(error);
      alert(`Error processing PDF: ${error.message}`);
    } finally {
      setIsProcessing(false);
    }
  };

  const renderExtraOptions = () => {
    switch (tool) {
      case 'split':
      case 'extract':
        return (
          <div className="mt-4">
            <label className="block text-sm font-semibold text-gray-700 mb-1">Page Ranges</label>
            <input 
              type="text" 
              placeholder="e.g. 1-2, 4 (default: first half)" 
              value={pageRanges}
              onChange={(e) => setPageRanges(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-indigo-500 font-mono text-sm"
            />
          </div>
        );
      case 'remove':
        return (
          <div className="mt-4">
            <label className="block text-sm font-semibold text-gray-700 mb-1">Pages to Remove</label>
            <input 
              type="text" 
              placeholder="e.g. 2, 4-5 (default: last page)" 
              value={pageRanges}
              onChange={(e) => setPageRanges(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-indigo-500 font-mono text-sm"
            />
          </div>
        );
      case 'organize':
        return (
          <div className="mt-4">
            <label className="block text-sm font-semibold text-gray-700 mb-1">Desired Page Order</label>
            <input 
              type="text" 
              placeholder="e.g. 3,1,2 (default: reverses page order)" 
              value={options}
              onChange={(e) => setOptions(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-indigo-500 font-mono text-sm"
            />
          </div>
        );
      case 'rotate':
        return (
          <div className="mt-4">
            <label className="block text-sm font-semibold text-gray-700 mb-1">Rotation Angle</label>
            <select 
              value={options} 
              onChange={(e) => setOptions(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-indigo-500 text-sm"
            >
              <option value="">Select Rotation</option>
              <option value="90">90° Clockwise</option>
              <option value="180">180° Flip</option>
              <option value="270">270° Counter-Clockwise</option>
            </select>
          </div>
        );
      case 'add-pages':
        return (
          <div className="mt-4">
            <label className="block text-sm font-semibold text-gray-700 mb-1">Blank Pages to Add</label>
            <input 
              type="number" 
              min="1" 
              max="10" 
              value={options} 
              placeholder="1"
              onChange={(e) => setOptions(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-indigo-500 text-sm font-mono"
            />
          </div>
        );
      case 'watermark':
        return (
          <div className="mt-4">
            <label className="block text-sm font-semibold text-gray-700 mb-1">Watermark Text</label>
            <input 
              type="text" 
              placeholder="e.g. CONFIDENTIAL, COPY" 
              value={options} 
              onChange={(e) => setOptions(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-indigo-500 text-sm"
            />
          </div>
        );
      case 'protect':
        return (
          <div className="mt-4">
            <label className="block text-sm font-semibold text-gray-700 mb-1">Protection Password / Key</label>
            <input 
              type="password" 
              placeholder="Enter strong key" 
              value={options} 
              onChange={(e) => setOptions(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-indigo-500 text-sm font-mono"
            />
          </div>
        );
      case 'sign':
        return (
          <div className="mt-4">
            <label className="block text-sm font-semibold text-gray-700 mb-1">Digital Signature Name</label>
            <input 
              type="text" 
              placeholder="e.g. Dr. John Watson" 
              value={options} 
              onChange={(e) => setOptions(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-indigo-500 text-sm"
            />
          </div>
        );
      case 'translate':
        return (
          <div className="mt-4">
            <label className="block text-sm font-semibold text-gray-700 mb-1">Target Language</label>
            <select 
              value={options} 
              onChange={(e) => setOptions(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-indigo-500 text-sm"
            >
              <option value="">Select Target Language</option>
              <option value="Hindi">Hindi / हिन्दी</option>
              <option value="Spanish">Spanish / Español</option>
              <option value="French">French / Français</option>
              <option value="German">German / Deutsch</option>
              <option value="Japanese">Japanese / 日本語</option>
            </select>
          </div>
        );
      case 'compress':
        return (
          <div className="mt-4 border-t border-gray-100 pt-4 text-left space-y-5">
            <h4 className="text-xs font-bold text-gray-800 uppercase tracking-wider flex items-center gap-1.5 border-b pb-1.5">
              <Minimize2 size={14} className="text-indigo-600" />
              Sizing Controls
            </h4>

            {/* Mode Select */}
            <div>
              <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1.5">
                Mode Selector
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setCompressMode('decrease')}
                  className={`py-2 px-3 rounded-lg border text-xs font-bold transition-all text-center ${
                    compressMode === 'decrease'
                      ? 'bg-indigo-50 border-indigo-500 text-indigo-700 shadow-sm'
                      : 'bg-white border-gray-200 text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  📉 Decrease Size
                </button>
                <button
                  type="button"
                  onClick={() => setCompressMode('increase')}
                  className={`py-2 px-3 rounded-lg border text-xs font-bold transition-all text-center ${
                    compressMode === 'increase'
                      ? 'bg-indigo-50 border-indigo-500 text-indigo-700 shadow-sm'
                      : 'bg-white border-gray-200 text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  📈 Increase Size
                </button>
              </div>
            </div>

            {/* Presets */}
            {compressMode === 'decrease' && (
              <div>
                <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1">
                  Compression Level
                </label>
                <select
                  value={compressLevel}
                  onChange={(e) => setCompressLevel(e.target.value)}
                  className="w-full p-2 border border-gray-300 rounded-md text-xs bg-white font-medium outline-none"
                >
                  <option value="recommended">Recommended / Standard (Best balance)</option>
                  <option value="extreme">Extreme Compression (Smallest size)</option>
                  <option value="low">Low Compression (Best quality)</option>
                </select>
              </div>
            )}

            {/* Target KB Limits */}
            <div className="bg-gray-50 p-3 rounded-lg border border-gray-100">
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-[11px] font-bold text-gray-750 flex items-center gap-1.5 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={targetSizeOn}
                    onChange={(e) => setTargetSizeOn(e.target.checked)}
                    className="rounded text-indigo-600 focus:ring-indigo-500 h-3.5 w-3.5"
                  />
                  <span>Limit Target KB Size</span>
                </label>
              </div>

              {targetSizeOn && (
                <div className="space-y-2 pt-1 animate-fadeIn">
                  <div className="flex flex-wrap gap-1.5">
                    {['10', '50', '100', '200', '500', 'custom'].map((val) => (
                      <button
                        type="button"
                        key={val}
                        onClick={() => setTargetKB(val)}
                        className={`px-2.5 py-1 rounded border text-[10px] font-bold transition-all ${
                          targetKB === val
                            ? 'bg-indigo-600 border-indigo-600 text-white shadow-sm'
                            : 'bg-white border-gray-200 text-gray-650 hover:bg-gray-50'
                        }`}
                      >
                        {val === 'custom' ? 'Custom' : `${val} KB`}
                      </button>
                    ))}
                  </div>

                  {targetKB === 'custom' && (
                    <div className="animate-slideDown">
                      <input
                        type="number"
                        placeholder="Target (KB)"
                        value={customTargetKB}
                        onChange={(e) => setCustomTargetKB(e.target.value)}
                        className="p-1.5 border border-gray-300 rounded w-28 outline-none text-xs font-mono"
                      />
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Page Resize Dimensions */}
            <div className="bg-gray-50 p-3 rounded-lg border border-gray-100">
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-[11px] font-bold text-gray-750 flex items-center gap-1.5 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={resizePageOn}
                    onChange={(e) => setResizePageOn(e.target.checked)}
                    className="rounded text-indigo-600 focus:ring-indigo-500 h-3.5 w-3.5"
                  />
                  <span>Manual Photo / Page Size</span>
                </label>
              </div>

              {resizePageOn && (
                <div className="space-y-3 pt-1 animate-fadeIn">
                  {/* Unit Selector */}
                  <div className="flex gap-3 items-center">
                    <span className="text-[10px] text-gray-450 font-bold uppercase">Unit:</span>
                    <label className="flex items-center gap-1 text-[11px] text-gray-700 cursor-pointer">
                      <input
                        type="radio"
                        checked={resizeUnit === 'px'}
                        onChange={() => setResizeUnit('px')}
                        className="text-indigo-600 focus:ring-indigo-500 h-3 w-3"
                      />
                      px
                    </label>
                    <label className="flex items-center gap-1 text-[11px] text-gray-700 cursor-pointer">
                      <input
                        type="radio"
                        checked={resizeUnit === 'cm'}
                        onChange={() => setResizeUnit('cm')}
                        className="text-indigo-600 focus:ring-indigo-500 h-3 w-3"
                      />
                      cm
                    </label>
                  </div>

                  {/* Width & Height Inputs */}
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-[10px] font-bold text-gray-500 mb-0.5">
                        Width ({resizeUnit === 'px' ? 'px' : 'cm'}):
                      </label>
                      <input
                        type="number"
                        step="any"
                        value={resizeWidth}
                        onChange={(e) => setResizeWidth(e.target.value)}
                        className="w-full p-1.5 border border-gray-300 rounded outline-none text-xs font-mono"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-gray-500 mb-0.5">
                        Height ({resizeUnit === 'px' ? 'px' : 'cm'}):
                      </label>
                      <input
                        type="number"
                        step="any"
                        value={resizeHeight}
                        onChange={(e) => setResizeHeight(e.target.value)}
                        className="w-full p-1.5 border border-gray-300 rounded outline-none text-xs font-mono"
                      />
                    </div>
                  </div>

                  {/* Presets Grid */}
                  <div className="flex flex-wrap gap-1">
                    <button
                      type="button"
                      onClick={() => {
                        if (resizeUnit === 'px') {
                          setResizeWidth('595');
                          setResizeHeight('842');
                        } else {
                          setResizeWidth('21');
                          setResizeHeight('29.7');
                        }
                      }}
                      className="text-[9px] bg-white border px-1.5 py-0.5 rounded text-gray-600 hover:bg-gray-55"
                    >
                      A4
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        if (resizeUnit === 'px') {
                          setResizeWidth('150');
                          setResizeHeight('150');
                        } else {
                          setResizeWidth('3.5');
                          setResizeHeight('4.5');
                        }
                      }}
                      className="text-[9px] bg-white border px-1.5 py-0.5 rounded text-gray-600 hover:bg-gray-55"
                    >
                      Passport ID Card
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  const renderPythonDeveloperCard = () => {
    return null;
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-[100] flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-xl w-full max-w-lg p-6 relative max-h-[92vh] overflow-y-auto">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold flex items-center gap-2"><Settings className="text-indigo-700" /> {title}</h2>
          <button onClick={onClose} className="p-1 hover:bg-gray-100 rounded transition"><X /></button>
        </div>
        
        {isProcessing && (
          <div className="my-8 text-center space-y-3 py-6">
            <Loader2 size={40} className="animate-spin text-indigo-700 mx-auto" />
            <p className="font-bold text-gray-800 text-sm">Processing Document: {title}...</p>
            <p className="text-xs text-gray-500">Processing file securely. Please wait a few seconds...</p>
          </div>
        )}

        {successMsg && downloadUrl && (
          <div className="my-8 text-center space-y-4 py-4 bg-emerald-50 border border-emerald-200 rounded-xl p-5">
            <div className="w-12 h-12 bg-emerald-100 rounded-full flex items-center justify-center mx-auto text-emerald-700">
              <CheckCircle size={24} />
            </div>
            <div>
              <h4 className="text-md font-bold text-gray-900">Successfully Processed!</h4>
              <p className="text-xs text-emerald-700 font-medium mt-1">Your file is ready for download!</p>
              <p className="text-xs text-gray-500 mt-2 truncate max-w-xs mx-auto font-mono bg-white px-2 py-1.5 rounded border border-gray-150">
                📄 {downloadFilename}
              </p>
            </div>

            <div className="flex flex-col gap-2 pt-2">
              <a 
                href={downloadUrl}
                download={downloadFilename}
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white py-2.5 rounded-lg font-bold text-sm shadow transition shadow-sm flex items-center justify-center gap-2"
              >
                <Download size={16} />
                Download File
              </a>
              
              <div className="flex gap-2 justify-center mt-2">
                <button 
                  type="button"
                  onClick={() => {
                    setFiles([]);
                    setSuccessMsg(false);
                    setDownloadUrl(null);
                    setDownloadFilename('');
                  }}
                  className="text-xs text-indigo-700 hover:underline font-semibold px-2 py-1"
                >
                  Process Another
                </button>
                <span className="text-gray-300">|</span>
                <button 
                  type="button"
                  onClick={onClose}
                  className="text-xs text-gray-500 hover:underline font-semibold px-2 py-1"
                >
                  Close Window
                </button>
              </div>
            </div>
          </div>
        )}

        {!isProcessing && !successMsg && (
          <>
            <div 
              className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center cursor-pointer hover:bg-gray-50 transition-colors flex flex-col items-center justify-center p-6"
              onClick={() => fileInputRef.current?.click()}
            >
              <Upload className="mx-auto text-gray-400 mb-2" />
              <p className="text-sm text-gray-600">Click or drag & drop files here</p>
              <p className="text-xs text-gray-400 mt-1 mb-3">Accepted: {getAcceptedTypes(tool)}</p>
              
              <div className="flex flex-col sm:flex-row gap-2" onClick={(e) => e.stopPropagation()}>
                <button 
                  type="button" 
                  onClick={() => fileInputRef.current?.click()}
                  className="bg-white border border-gray-300 text-gray-800 px-4 py-1.5 rounded-lg font-bold text-xs hover:bg-gray-100 transition-all shadow-sm"
                >
                  Select Files
                </button>
                <button 
                  type="button"
                  onClick={generateSamplePDF}
                  className="bg-indigo-50 border border-indigo-200 text-indigo-700 hover:bg-indigo-100 px-4 py-1.5 rounded-lg font-bold text-xs transition-all flex items-center gap-1 shadow-sm"
                >
                  <Sparkles size={12} className="text-indigo-600 shrink-0" />
                  Create Demo PDF
                </button>
              </div>
              
              <input 
                type="file" 
                ref={fileInputRef} 
                className="hidden" 
                multiple={tool === 'merge' || tool === 'jpg-to-pdf'} 
                accept={getAcceptedTypes(tool)}
                onChange={(e) => handleFiles(e.target.files)} 
              />
            </div>

            <div className="mt-4 space-y-2 max-h-40 overflow-y-auto pr-1">
              {files.map((file, i) => (
                <div key={i} className="flex justify-between items-center p-2.5 bg-gray-50 border border-gray-100 rounded-lg text-sm gap-2">
                  <span className="truncate flex-1 flex items-center gap-2 font-medium text-gray-700">
                    <FileText size={16} className="text-indigo-600 shrink-0" /> 
                    {file.name}
                  </span>
                  <div className="flex items-center gap-1.5 shrink-0">
                    {files.length > 1 && (
                      <>
                        <button 
                          onClick={() => moveFileUp(i)} 
                          disabled={i === 0}
                          className="p-1 rounded text-gray-500 hover:text-indigo-600 hover:bg-gray-200/50 disabled:opacity-20 disabled:hover:bg-transparent disabled:hover:text-gray-500"
                          title="Move Up"
                        >
                          <ArrowUp size={15} />
                        </button>
                        <button 
                          onClick={() => moveFileDown(i)} 
                          disabled={i === files.length - 1}
                          className="p-1 rounded text-gray-500 hover:text-indigo-600 hover:bg-gray-200/50 disabled:opacity-20 disabled:hover:bg-transparent disabled:hover:text-gray-500"
                          title="Move Down"
                        >
                          <ArrowDown size={15} />
                        </button>
                      </>
                    )}
                    <button 
                      onClick={() => removeFile(i)} 
                      className="p-1.5 rounded hover:bg-red-50 text-gray-400 hover:text-red-600"
                      title="Remove file"
                    >
                      <Trash2 size={15} />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {renderExtraOptions()}

            <button 
              onClick={handleProcess}
              disabled={files.length === 0}
              className="w-full mt-6 bg-indigo-700 text-white py-3 rounded-lg font-bold disabled:opacity-50 hover:bg-indigo-800 transition-colors shadow-sm cursor-pointer"
            >
              Apply {title}
            </button>
          </>
        )}
      </div>
    </div>
  );
}

