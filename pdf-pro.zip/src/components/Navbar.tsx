import { Merge, Scissors, Trash2, FileOutput, LayoutGrid, Minimize2, Wrench, ScanText, FileImage, FileText, Presentation, Table, Code, Image, RotateCw, Plus, Type, Crop, Pencil, Unlock, Lock, Signature, Eraser } from 'lucide-react';

interface NavbarProps {
  onToolClick: (tool: string, title: string) => void;
  onAuthClick: (mode: 'signin' | 'signup') => void;
  userEmail: string | null;
  onLogout: () => void;
}

export default function Navbar({ onToolClick, onAuthClick, userEmail, onLogout }: NavbarProps) {
  return (
    <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
      <nav className="flex justify-between items-center w-full px-12 h-16 max-w-7xl mx-auto">
        <div className="flex items-center gap-8">
          <a href="#" className="text-2xl font-bold text-indigo-700 tracking-tight">PDFPro</a>
          <div className="hidden md:flex items-center gap-6 text-sm font-medium">
            <button onClick={() => onToolClick('compress', 'Reduce Size')} className="text-gray-600 hover:text-indigo-700 transition-colors text-xs font-semibold uppercase tracking-wider">REDUCE SIZE</button>
            <button onClick={() => onToolClick('split', 'Split PDF')} className="text-gray-600 hover:text-indigo-700 transition-colors text-xs font-semibold uppercase tracking-wider">SPLIT PDF</button>
            <button onClick={() => onToolClick('merge', 'Merge PDF')} className="text-gray-600 hover:text-indigo-700 transition-colors text-xs font-semibold uppercase tracking-wider">MERGE PDF</button>
            <button onClick={() => onToolClick('resume', 'Resume / CV')} className="text-gray-600 hover:text-indigo-700 transition-colors text-xs font-semibold uppercase tracking-wider" id="header-resume-cv-btn">RESUME / CV</button>
            <div className="relative group">
              <span className="text-gray-600 hover:text-indigo-700 transition-colors cursor-pointer text-xs font-semibold uppercase tracking-wider">
                TOOLS
              </span>
              <div className="absolute top-full -left-72 mt-2 bg-white border border-gray-100 rounded-lg shadow-xl p-6 min-w-[1200px] opacity-0 group-hover:opacity-100 invisible group-hover:visible transition-all z-50">
                <div className="grid grid-cols-7 gap-4">
                  <div>
                    <h4 className="text-[10px] font-bold text-gray-400 uppercase mb-3">Organize</h4>
                    <button onClick={() => onToolClick('merge', 'Merge PDF')} className="flex items-center gap-2 py-1 text-xs hover:text-indigo-700 w-full text-left"><Merge size={14} /> Merge PDF</button>
                    <button onClick={() => onToolClick('split', 'Split PDF')} className="flex items-center gap-2 py-1 text-xs hover:text-indigo-700 w-full text-left"><Scissors size={14} /> Split PDF</button>
                    <button onClick={() => onToolClick('remove', 'Remove pages')} className="flex items-center gap-2 py-1 text-xs hover:text-indigo-700 w-full text-left"><Trash2 size={14} /> Remove pages</button>
                    <button onClick={() => onToolClick('extract', 'Extract pages')} className="flex items-center gap-2 py-1 text-xs hover:text-indigo-700 w-full text-left"><FileOutput size={14} /> Extract pages</button>
                    <button onClick={() => onToolClick('organize', 'Organize PDF')} className="flex items-center gap-2 py-1 text-xs hover:text-indigo-700 w-full text-left"><LayoutGrid size={14} /> Organize PDF</button>
                  </div>
                  <div>
                    <h4 className="text-[10px] font-bold text-gray-400 uppercase mb-3">Optimize</h4>
                    <button onClick={() => onToolClick('compress', 'Reduce Size')} className="flex items-center gap-2 py-1 text-xs hover:text-indigo-700 w-full text-left"><Minimize2 size={14} /> Reduce Size</button>
                    <button onClick={() => onToolClick('repair', 'Repair PDF')} className="flex items-center gap-2 py-1 text-xs hover:text-indigo-700 w-full text-left"><Wrench size={14} /> Repair PDF</button>
                    <button onClick={() => onToolClick('ocr', 'OCR PDF')} className="flex items-center gap-2 py-1 text-xs hover:text-indigo-700 w-full text-left"><ScanText size={14} /> OCR PDF</button>
                  </div>
                  <div>
                    <h4 className="text-[10px] font-bold text-gray-400 uppercase mb-3">Convert to PDF</h4>
                    <button onClick={() => onToolClick('jpg-to-pdf', 'JPG to PDF')} className="flex items-center gap-2 py-1 text-xs hover:text-indigo-700 w-full text-left"><FileImage size={14} /> JPG to PDF</button>
                    <button onClick={() => onToolClick('png-to-pdf', 'PNG to PDF')} className="flex items-center gap-2 py-1 text-xs hover:text-indigo-700 w-full text-left"><Image size={14} /> PNG to PDF</button>
                    <button onClick={() => onToolClick('word-to-pdf', 'WORD to PDF')} className="flex items-center gap-2 py-1 text-xs hover:text-indigo-700 w-full text-left"><FileText size={14} /> WORD to PDF</button>
                    <button onClick={() => onToolClick('ppt-to-pdf', 'PPT to PDF')} className="flex items-center gap-2 py-1 text-xs hover:text-indigo-700 w-full text-left"><Presentation size={14} /> PPT to PDF</button>
                    <button onClick={() => onToolClick('excel-to-pdf', 'EXCEL to PDF')} className="flex items-center gap-2 py-1 text-xs hover:text-indigo-700 w-full text-left"><Table size={14} /> EXCEL to PDF</button>
                    <button onClick={() => onToolClick('html-to-pdf', 'HTML to PDF')} className="flex items-center gap-2 py-1 text-xs hover:text-indigo-700 w-full text-left"><Code size={14} /> HTML to PDF</button>
                    <button onClick={() => onToolClick('txt-to-pdf', 'TXT to PDF')} className="flex items-center gap-2 py-1 text-xs hover:text-indigo-700 w-full text-left"><FileText size={14} /> TXT to PDF</button>
                  </div>
                  <div>
                    <h4 className="text-[10px] font-bold text-gray-400 uppercase mb-3">Convert from PDF</h4>
                    <button onClick={() => onToolClick('pdf-to-jpg', 'PDF to JPG')} className="flex items-center gap-2 py-1 text-xs hover:text-indigo-700 w-full text-left"><Image size={14} /> PDF to JPG</button>
                    <button onClick={() => onToolClick('pdf-to-png', 'PDF to PNG')} className="flex items-center gap-2 py-1 text-xs hover:text-indigo-700 w-full text-left"><FileImage size={14} /> PDF to PNG</button>
                    <button onClick={() => onToolClick('pdf-to-word', 'PDF to WORD')} className="flex items-center gap-2 py-1 text-xs hover:text-indigo-700 w-full text-left"><FileText size={14} /> PDF to WORD</button>
                    <button onClick={() => onToolClick('pdf-to-ppt', 'PDF to PPT')} className="flex items-center gap-2 py-1 text-xs hover:text-indigo-700 w-full text-left"><Presentation size={14} /> PDF to PPT</button>
                    <button onClick={() => onToolClick('pdf-to-excel', 'PDF to EXCEL')} className="flex items-center gap-2 py-1 text-xs hover:text-indigo-700 w-full text-left"><Table size={14} /> PDF to EXCEL</button>
                    <button onClick={() => onToolClick('pdf-to-html', 'PDF to HTML')} className="flex items-center gap-2 py-1 text-xs hover:text-indigo-700 w-full text-left"><Code size={14} /> PDF to HTML</button>
                    <button onClick={() => onToolClick('pdf-to-txt', 'PDF to TXT')} className="flex items-center gap-2 py-1 text-xs hover:text-indigo-700 w-full text-left"><FileText size={14} /> PDF to TXT</button>
                  </div>
                  <div>
                    <h4 className="text-[10px] font-bold text-gray-400 uppercase mb-3">Edit</h4>
                    <button onClick={() => onToolClick('rotate', 'Rotate PDF')} className="flex items-center gap-2 py-1 text-xs hover:text-indigo-700 w-full text-left"><RotateCw size={14} /> Rotate PDF</button>
                    <button onClick={() => onToolClick('add-pages', 'Add pages')} className="flex items-center gap-2 py-1 text-xs hover:text-indigo-700 w-full text-left"><Plus size={14} /> Add pages</button>
                    <button onClick={() => onToolClick('watermark', 'Watermark')} className="flex items-center gap-2 py-1 text-xs hover:text-indigo-700 w-full text-left"><Type size={14} /> Watermark</button>
                    <button onClick={() => onToolClick('crop', 'Crop')} className="flex items-center gap-2 py-1 text-xs hover:text-indigo-700 w-full text-left"><Crop size={14} /> Crop</button>
                    <button onClick={() => onToolClick('edit-pdf', 'Edit')} className="flex items-center gap-2 py-1 text-xs hover:text-indigo-700 w-full text-left"><Pencil size={14} /> Edit</button>
                  </div>
                  <div>
                    <h4 className="text-[10px] font-bold text-gray-400 uppercase mb-3">Security</h4>
                    <button onClick={() => onToolClick('unlock', 'Unlock')} className="flex items-center gap-2 py-1 text-xs hover:text-indigo-700 w-full text-left"><Unlock size={14} /> Unlock</button>
                    <button onClick={() => onToolClick('protect', 'Protect')} className="flex items-center gap-2 py-1 text-xs hover:text-indigo-700 w-full text-left"><Lock size={14} /> Protect</button>
                    <button onClick={() => onToolClick('sign', 'Sign')} className="flex items-center gap-2 py-1 text-xs hover:text-indigo-700 w-full text-left"><Signature size={14} /> Sign</button>
                    <button onClick={() => onToolClick('redact', 'Redact')} className="flex items-center gap-2 py-1 text-xs hover:text-indigo-700 w-full text-left"><Eraser size={14} /> Redact</button>
                  </div>
                  <div>
                    <h4 className="text-[10px] font-bold text-gray-400 uppercase mb-3">Intelligence</h4>
                    <button onClick={() => onToolClick('summarizer', 'Summarizer')} className="block py-1 text-xs hover:text-indigo-700 w-full text-left">Summarizer</button>
                    <button onClick={() => onToolClick('translate', 'Translate')} className="block py-1 text-xs hover:text-indigo-700 w-full text-left">Translate</button>
                    <button onClick={() => onToolClick('resume', 'Resume / CV')} className="block py-1 text-xs hover:text-amber-700 w-full text-left font-bold text-amber-600">✨ Resume / CV Builder</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-4 animate-fade-in">
          {userEmail ? (
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-indigo-50 border border-indigo-150 text-indigo-700 font-semibold text-xs shadow-sm">
                <span className="w-5 h-5 rounded-full bg-indigo-600 text-white flex items-center justify-center font-bold text-[10px] shrink-0">
                  {userEmail.substring(0, 2).toUpperCase()}
                </span>
                <span className="max-w-[120px] truncate" title={userEmail}>
                  {userEmail}
                </span>
              </div>
              <button
                onClick={onLogout}
                className="text-gray-500 hover:text-rose-600 text-xs font-semibold uppercase tracking-wider transition-colors px-3 py-1.5 border border-transparent hover:border-rose-200 hover:bg-rose-50/50 rounded-lg cursor-pointer"
                id="navbar-logout-btn"
              >
                Sign Out
              </button>
            </div>
          ) : (
            <>
              <button 
                onClick={() => onAuthClick('signin')} 
                className="text-indigo-700 font-bold hover:opacity-80 px-4 py-2 text-xs uppercase tracking-wider cursor-pointer"
                id="navbar-signin-btn"
              >
                Sign In
              </button>
              <button 
                onClick={() => onAuthClick('signup')} 
                className="bg-indigo-700 text-white px-6 py-2 rounded-lg font-extrabold hover:opacity-90 shadow-sm text-xs uppercase tracking-wider cursor-pointer"
                id="navbar-signup-btn"
              >
                Sign Up
              </button>
            </>
          )}
        </div>
      </nav>
    </header>
  );
}
