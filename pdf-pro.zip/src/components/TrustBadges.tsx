import React from 'react';
import { Lock, Trash2, ShieldCheck } from 'lucide-react';

export default function TrustBadges() {
  const badges = [
    { icon: Lock, title: "Secure Transfer", desc: "Your files are encrypted using 256-bit SSL technology." },
    { icon: Trash2, title: "Auto Deletion", desc: "Files are permanently deleted from our servers after 2 hours." },
    { icon: ShieldCheck, title: "Privacy First", desc: "We never look at or share your documents with third parties." },
  ];

  return (
    <section className="pb-24 px-4 md:px-12 max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-8">
      {badges.map((badge, idx) => (
        <div key={idx} className="flex items-start gap-4 p-6 bg-gray-50 rounded-lg">
          <div className="p-2 bg-white rounded-lg shadow-sm">
            <badge.icon size={24} className="text-indigo-700" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-gray-900 uppercase tracking-wider mb-1">{badge.title}</h4>
            <p className="text-sm text-gray-600">{badge.desc}</p>
          </div>
        </div>
      ))}
    </section>
  );
}
