import { useState, useEffect } from "react";
import { X, Key, RotateCw, CheckCircle2, AlertCircle, Clock, RefreshCw, BarChart2, ShieldCheck, Zap } from "lucide-react";

interface KeyStatus {
  index: number;
  publicKey: string;
  status: "working" | "rate-limited" | "error" | "untested";
  successCount: number;
  failCount: number;
  rateLimitCount: number;
  consecutiveFailures: number;
  lastUsed: string | null;
  lastError: string | null;
  rateLimitResetAt: number | null;
}

interface APIKeyMonitorModalProps {
  onClose: () => void;
}

export default function APIKeyMonitorModal({ onClose }: APIKeyMonitorModalProps) {
  const [keys, setKeys] = useState<KeyStatus[]>([]);
  const [currentKeyIndex, setCurrentKeyIndex] = useState<number>(0);
  const [loading, setLoading] = useState<boolean>(true);
  const [refreshing, setRefreshing] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const fetchStatus = async (showRefreshIndicator = false) => {
    if (showRefreshIndicator) setRefreshing(true);
    try {
      const res = await fetch("/api/ilovepdf-keys/status");
      if (!res.ok) throw new Error("Failed to fetch API key statuses");
      const data = await res.json();
      setKeys(data.keys || []);
      setCurrentKeyIndex(data.currentKeyIndex ?? 0);
      setError(null);
    } catch (err: any) {
      setError(err.message || "An error occurred while loading key states.");
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const resetTracker = async () => {
    if (!confirm("Are you sure you want to reset all tracking metrics & restore rate-limited keys?")) return;
    setRefreshing(true);
    try {
      const res = await fetch("/api/ilovepdf-keys/reset", { method: "POST" });
      if (!res.ok) throw new Error("Failed to reset tracker");
      await fetchStatus();
    } catch (err: any) {
      alert("Reset failed: " + (err.message || err));
    } finally {
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchStatus();
    // Poll the status every 4 seconds to show real-time rotation state during processing
    const interval = setInterval(() => {
      fetchStatus(false);
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  const formatTime = (isoString: string | null) => {
    if (!isoString) return "Never";
    const date = new Date(isoString);
    return date.toLocaleTimeString() + " (" + date.toLocaleDateString() + ")";
  };

  const getStatusBadge = (status: KeyStatus["status"]) => {
    switch (status) {
      case "working":
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
            <CheckCircle2 size={12} className="text-emerald-500" />
            Working
          </span>
        );
      case "rate-limited":
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-50 text-amber-700 border border-amber-200 animate-pulse">
            <Clock size={12} className="text-amber-500" />
            Rate Limited
          </span>
        );
      case "error":
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-rose-50 text-rose-700 border border-rose-200">
            <AlertCircle size={12} className="text-rose-500" />
            Temporary Error
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-slate-50 text-slate-600 border border-slate-200">
            <Clock size={12} className="text-slate-400" />
            Untested
          </span>
        );
    }
  };

  return (
    <div className="fixed inset-0 z-[100] overflow-y-auto" id="api-key-monitor-overlay">
      {/* Backdrop */}
      <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm transition-opacity" onClick={onClose} id="api-key-monitor-backdrop"></div>

      <div className="flex min-h-full items-end justify-center p-4 text-center sm:items-center sm:p-0">
        <div 
          className="relative transform overflow-hidden rounded-2xl bg-white text-left shadow-2xl transition-all sm:my-8 sm:w-full sm:max-w-4xl p-8"
          id="api-key-monitor-modal-card"
        >
          {/* Header */}
          <div className="flex justify-between items-start mb-6">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-indigo-50 text-indigo-700 rounded-xl">
                <Key size={24} />
              </div>
              <div>
                <h3 className="text-xl font-bold text-slate-900 tracking-tight">
                  iLovePDF API Rotation Registry
                </h3>
                <p className="text-xs text-slate-500 font-medium">
                  Dynamic slot allocation, automatic rotation, and fault tolerance monitoring
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="text-slate-400 hover:text-slate-600 p-2 hover:bg-slate-50 rounded-lg transition-colors"
              id="close-monitor-modal-btn"
            >
              <X size={20} />
            </button>
          </div>

          {/* Explanation Info */}
          <div className="bg-indigo-50/50 border border-indigo-100 rounded-xl p-4 mb-6 flex gap-3 text-indigo-900 text-xs leading-relaxed">
            <Zap size={18} className="text-indigo-600 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold">Rate Limit Handshake Protocol</span>: Each incoming request routes to the current active key. If a key returns a rate-limit error (Status <code className="bg-indigo-100 text-indigo-800 px-1 rounded">429</code>, or quota exhausted signals), the system flags it as <span className="font-semibold text-amber-700">Rate Limited</span>, schedules a reset window, rotates to the next available working key, and processes the job instantly. This avoids user facing timeouts!
            </div>
          </div>

          {error && (
            <div className="bg-rose-50 border border-rose-200 text-rose-700 p-4 rounded-xl text-xs mb-6 flex gap-2 items-center" id="monitor-error-alert">
              <AlertCircle size={16} />
              <span>{error}</span>
            </div>
          )}

          {/* Key Tracker Content */}
          {loading ? (
            <div className="flex flex-col items-center justify-center py-12 gap-3" id="monitor-loading-state">
              <RefreshCw className="animate-spin text-indigo-600" size={32} />
              <p className="text-sm font-medium text-slate-500">Loading registry state...</p>
            </div>
          ) : (
            <div className="space-y-6" id="monitor-content">
              {/* Keys Grid */}
              <div className="overflow-hidden border border-slate-200 rounded-xl bg-white">
                <table className="min-w-full divide-y divide-slate-200">
                  <thead className="bg-slate-50">
                    <tr>
                      <th className="px-4 py-3 text-left text-xs font-bold text-slate-500 uppercase tracking-wider w-16">Index</th>
                      <th className="px-4 py-3 text-left text-xs font-bold text-slate-500 uppercase tracking-wider">Public Secret Key ID</th>
                      <th className="px-4 py-3 text-left text-xs font-bold text-slate-500 uppercase tracking-wider w-36">Status</th>
                      <th className="px-4 py-3 text-center text-xs font-bold text-slate-500 uppercase tracking-wider w-24">Success</th>
                      <th className="px-4 py-3 text-center text-xs font-bold text-slate-500 uppercase tracking-wider w-24">Failure</th>
                      <th className="px-4 py-3 text-center text-xs font-bold text-slate-500 uppercase tracking-wider w-28">Rate Limit</th>
                      <th className="px-4 py-3 text-right text-xs font-bold text-slate-500 uppercase tracking-wider">Last Sync</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-xs">
                    {keys.map((key) => {
                      const isActive = key.index === currentKeyIndex;
                      return (
                        <tr 
                          key={key.index} 
                          className={`hover:bg-slate-50/50 transition-colors ${isActive ? "bg-indigo-50/20" : ""}`}
                          id={`key-row-${key.index}`}
                        >
                          <td className="px-4 py-4 whitespace-nowrap">
                            <div className="flex items-center gap-1.5 font-bold text-slate-600">
                              {isActive && (
                                <span className="w-2.5 h-2.5 rounded-full bg-indigo-600 animate-ping inline-block" title="Current Active Cursor" />
                              )}
                              <span>#{key.index}</span>
                            </div>
                          </td>
                          <td className="px-4 py-4 whitespace-nowrap font-mono text-slate-700">
                            <span className="font-semibold block">{key.publicKey}</span>
                            {key.lastError && (
                              <span className="text-[10px] text-rose-600 block mt-1 max-w-sm truncate" title={key.lastError}>
                                Error: {key.lastError}
                              </span>
                            )}
                          </td>
                          <td className="px-4 py-4 whitespace-nowrap">
                            {getStatusBadge(key.status)}
                          </td>
                          <td className="px-4 py-4 whitespace-nowrap text-center font-semibold text-emerald-600">
                            {key.successCount}
                          </td>
                          <td className="px-4 py-4 whitespace-nowrap text-center font-semibold text-rose-500">
                            {key.failCount}
                          </td>
                          <td className="px-4 py-4 whitespace-nowrap text-center font-semibold text-amber-600">
                            {key.rateLimitCount}
                          </td>
                          <td className="px-4 py-4 whitespace-nowrap text-right text-slate-500 font-mono">
                            {formatTime(key.lastUsed)}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              {/* Status footer with action buttons */}
              <div className="flex justify-between items-center bg-slate-50 p-4 border border-slate-200 rounded-xl" id="monitor-footer-actions">
                <div className="flex items-center gap-2 text-xs font-semibold text-slate-600">
                  <BarChart2 className="text-slate-400" size={16} />
                  <span>Total keys registered: <strong className="text-slate-900">{keys.length}</strong></span>
                  <span className="text-slate-300">|</span>
                  <span>Active Cursor Slot: <strong className="text-indigo-600">#{currentKeyIndex}</strong></span>
                </div>
                
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => fetchStatus(true)}
                    disabled={refreshing}
                    className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-700 border border-slate-200 hover:border-slate-300 rounded-lg bg-white disabled:opacity-50 transition-all shadow-sm"
                    id="refresh-monitor-keys-btn"
                  >
                    <RotateCw size={14} className={refreshing ? "animate-spin" : ""} />
                    <span>Refresh Logs</span>
                  </button>

                  <button
                    onClick={resetTracker}
                    disabled={refreshing}
                    className="flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-indigo-700 border border-indigo-200 hover:bg-indigo-50/50 rounded-lg bg-indigo-50/30 transition-all shadow-sm"
                    id="reset-monitor-keys-btn"
                  >
                    <RefreshCw size={14} />
                    <span>Purge Reset Stats & Blocks</span>
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
