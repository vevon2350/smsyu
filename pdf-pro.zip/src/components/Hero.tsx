import React, { useState, useRef, useEffect } from 'react';
import { 
  Merge, Scissors, Trash2, FileOutput, LayoutGrid, Minimize2, Wrench, 
  ScanText, FileImage, FileText, Presentation, Table, Code, Image, 
  RotateCw, Plus, Type, Crop, Pencil, Unlock, Lock, Signature, Eraser,
  Upload, FileUp, Loader2, CheckCircle, RefreshCw, ArrowUp, ArrowDown, Sparkles, Download
} from 'lucide-react';

const TOOLS = [
  { 
    id: 'merge', 
    title: 'Merge PDF', 
    desc: 'Combine multiple PDF files into one integrated PDF document in your chosen order.', 
    icon: Merge, 
    category: 'Organize', 
    accept: '.pdf', 
    multiple: true,
    actionLabel: 'Merge PDF'
  },
  { 
    id: 'split', 
    title: 'Split PDF', 
    desc: 'Extract specific page ranges or turn each page into independent PDF documents.', 
    icon: Scissors, 
    category: 'Organize', 
    accept: '.pdf', 
    multiple: false,
    actionLabel: 'Split PDF'
  },
  { 
    id: 'remove', 
    title: 'Remove pages', 
    desc: 'Delete unwanted pages from your document before downloading a clean copy.', 
    icon: Trash2, 
    category: 'Organize', 
    accept: '.pdf', 
    multiple: false,
    actionLabel: 'Remove Selected Pages'
  },
  { 
    id: 'extract', 
    title: 'Extract pages', 
    desc: 'Select specific pages to extract into a separate high-resolution PDF.', 
    icon: FileOutput, 
    category: 'Organize', 
    accept: '.pdf', 
    multiple: false,
    actionLabel: 'Extract Pages'
  },
  { 
    id: 'organize', 
    title: 'Organize PDF', 
    desc: 'Rearrange, reverse, or customize page sequences to structured book formats.', 
    icon: LayoutGrid, 
    category: 'Organize', 
    accept: '.pdf', 
    multiple: false,
    actionLabel: 'Reorder & Save'
  },
  { 
    id: 'compress', 
    title: 'Reduce Size', 
    desc: 'Reduce file size optimized for email and chat without losing text clarity.', 
    icon: Minimize2, 
    category: 'Optimize', 
    accept: '.pdf', 
    multiple: false,
    actionLabel: 'Reduce Size'
  },
  { 
    id: 'repair', 
    title: 'Repair PDF', 
    desc: 'Recover corrupted binary sequences and structural details in damaged PDFs.', 
    icon: Wrench, 
    category: 'Optimize', 
    accept: '.pdf', 
    multiple: false,
    actionLabel: 'Repair & Salvage'
  },
  { 
    id: 'ocr', 
    title: 'OCR PDF', 
    desc: 'Perform Optical Character Recognition on image files to make PDF text fully searchable.', 
    icon: ScanText, 
    category: 'Optimize', 
    accept: '.pdf', 
    multiple: false,
    actionLabel: 'Apply Smart OCR'
  },
  { 
    id: 'jpg-to-pdf', 
    title: 'JPG to PDF', 
    desc: 'Convert JPG, JPEG, and PNG images into custom aligned PDF sheets instantly.', 
    icon: FileImage, 
    category: 'Convert to PDF', 
    accept: '.jpg,.jpeg,.png', 
    multiple: true,
    actionLabel: 'Convert Images to PDF'
  },
  { 
    id: 'png-to-pdf', 
    title: 'PNG to PDF', 
    desc: 'Convert single or multiple PNG images into aligned high-resolution PDF pages.', 
    icon: Image, 
    category: 'Convert to PDF', 
    accept: '.png', 
    multiple: true,
    actionLabel: 'Convert PNGs to PDF'
  },
  { 
    id: 'word-to-pdf', 
    title: 'WORD to PDF', 
    desc: 'Keep original fonts and formats perfectly aligned in conversion from Word to PDF.', 
    icon: FileText, 
    category: 'Convert to PDF', 
    accept: '.doc,.docx', 
    multiple: false,
    actionLabel: 'Convert Word'
  },
  { 
    id: 'ppt-to-pdf', 
    title: 'PPT to PDF', 
    desc: 'Direct layout conversion from PowerPoint presentations to stable PDF slides.', 
    icon: Presentation, 
    category: 'Convert to PDF', 
    accept: '.ppt,.pptx', 
    multiple: false,
    actionLabel: 'Convert Powerpoint'
  },
  { 
    id: 'excel-to-pdf', 
    title: 'EXCEL to PDF', 
    desc: 'Translate rows, columns, and grid data to clean formatted PDF tables.', 
    icon: Table, 
    category: 'Convert to PDF', 
    accept: '.xls,.xlsx', 
    multiple: false,
    actionLabel: 'Convert Excel Grid'
  },
  { 
    id: 'html-to-pdf', 
    title: 'HTML to PDF', 
    desc: 'Generate perfect responsive layouts from HTML source code or pages directly.', 
    icon: Code, 
    category: 'Convert to PDF', 
    accept: '.html,.htm', 
    multiple: false,
    actionLabel: 'Generate PDF from HTML'
  },
  { 
    id: 'txt-to-pdf', 
    title: 'TXT to PDF', 
    desc: 'Convert plain text files (.txt) into custom-formatted, standard clear PDF pages.', 
    icon: FileText, 
    category: 'Convert to PDF', 
    accept: '.txt', 
    multiple: false,
    actionLabel: 'Convert TXT to PDF'
  },
  { 
    id: 'pdf-to-jpg', 
    title: 'PDF to JPG', 
    desc: 'Turn pages into standalone, pixel-perfect digital JPG graphic designs.', 
    icon: Image, 
    category: 'Convert from PDF', 
    accept: '.pdf', 
    multiple: false,
    actionLabel: 'Convert PDF to JPG'
  },
  { 
    id: 'pdf-to-png', 
    title: 'PDF to PNG', 
    desc: 'Export high-speed crisp PNG raster images from your PDF documents.', 
    icon: FileImage, 
    category: 'Convert from PDF', 
    accept: '.pdf', 
    multiple: false,
    actionLabel: 'Convert PDF to PNG'
  },
  { 
    id: 'pdf-to-word', 
    title: 'PDF to WORD', 
    desc: 'Extract texts and charts to customizable Microsoft Word documents.', 
    icon: FileText, 
    category: 'Convert from PDF', 
    accept: '.pdf', 
    multiple: false,
    actionLabel: 'Convert to Docx'
  },
  { 
    id: 'pdf-to-ppt', 
    title: 'PDF to PPT', 
    desc: 'Re-analyze vector structures and convert elements back to editable PowerPoint slides.', 
    icon: Presentation, 
    category: 'Convert from PDF', 
    accept: '.pdf', 
    multiple: false,
    actionLabel: 'Convert PDF to PPT'
  },
  { 
    id: 'pdf-to-excel', 
    title: 'PDF to EXCEL', 
    desc: 'Extract tables, rows, grids, and numeric database spreadsheets to Microsoft Excel sheets.', 
    icon: Table, 
    category: 'Convert from PDF', 
    accept: '.pdf', 
    multiple: false,
    actionLabel: 'Convert PDF to Excel'
  },
  { 
    id: 'pdf-to-html', 
    title: 'PDF to HTML', 
    desc: 'Build web-embeddable HTML modules with inline formatting extracted from PDFs.', 
    icon: Code, 
    category: 'Convert from PDF', 
    accept: '.pdf', 
    multiple: false,
    actionLabel: 'Convert PDF to HTML'
  },
  { 
    id: 'pdf-to-txt', 
    title: 'PDF to TXT', 
    desc: 'Extract pure searchable text layers from documents onto simple flat text files.', 
    icon: FileText, 
    category: 'Convert from PDF', 
    accept: '.pdf', 
    multiple: false,
    actionLabel: 'Convert PDF to TXT'
  },
  { 
    id: 'rotate', 
    title: 'Rotate PDF', 
    desc: 'Adjust specific page rotations or turn them to 90°, 180°, or landscape angles.', 
    icon: RotateCw, 
    category: 'Edit', 
    accept: '.pdf', 
    multiple: false,
    actionLabel: 'Rotate PDF'
  },
  { 
    id: 'add-pages', 
    title: 'Add pages', 
    desc: 'Append multiple clean blank pages to extend your active worksheets.', 
    icon: Plus, 
    category: 'Edit', 
    accept: '.pdf', 
    multiple: false,
    actionLabel: 'Add Blank Pages'
  },
  { 
    id: 'watermark', 
    title: 'Watermark', 
    desc: 'Incorporate corporate slogans, logo templates, or draft warnings effortlessly.', 
    icon: Type, 
    category: 'Edit', 
    accept: '.pdf', 
    multiple: false,
    actionLabel: 'Apply Watermark'
  },
  { 
    id: 'crop', 
    title: 'Crop', 
    desc: 'Trim visible page size borders to highlight specific diagram content panels.', 
    icon: Crop, 
    category: 'Edit', 
    accept: '.pdf', 
    multiple: false,
    actionLabel: 'Crop PDF Area'
  },
  { 
    id: 'edit-pdf', 
    title: 'Edit PDF', 
    desc: 'Draw digital marks, text descriptions, and notations to existing templates.', 
    icon: Pencil, 
    category: 'Edit', 
    accept: '.pdf', 
    multiple: false,
    actionLabel: 'Apply Custom Edits'
  },
  { 
    id: 'unlock', 
    title: 'Unlock', 
    desc: 'Strip copy blocks and permissions protections from secure files.', 
    icon: Unlock, 
    category: 'Security', 
    accept: '.pdf', 
    multiple: false,
    actionLabel: 'Remove Restrictions'
  },
  { 
    id: 'protect', 
    title: 'Protect', 
    desc: 'Encrypt sensitive company reports with passwords and authorization locks.', 
    icon: Lock, 
    category: 'Security', 
    accept: '.pdf', 
    multiple: false,
    actionLabel: 'Lock Document'
  },
  { 
    id: 'sign', 
    title: 'Sign', 
    desc: 'Apply digitally formatted signatures and timestamps to contracts.', 
    icon: Signature, 
    category: 'Security', 
    accept: '.pdf', 
    multiple: false,
    actionLabel: 'Certify Signature'
  },
  { 
    id: 'redact', 
    title: 'Redact', 
    desc: 'Overlay black-out lines on private credentials, numbers, or records.', 
    icon: Eraser, 
    category: 'Security', 
    accept: '.pdf', 
    multiple: false,
    actionLabel: 'Redact Data Areas'
  },
  { 
    id: 'summarizer', 
    title: 'Summarizer', 
    desc: 'Use advanced scanning algorithms to summarize the uploaded documents.', 
    icon: ScanText, 
    category: 'Intelligence', 
    accept: '.pdf', 
    multiple: false,
    actionLabel: 'Generate AI Summary'
  },
  { 
    id: 'translate', 
    title: 'Translate', 
    desc: 'Render original PDF copy templates in dynamic multilingual target systems.', 
    icon: RefreshCw, 
    category: 'Intelligence', 
    accept: '.pdf', 
    multiple: false,
    actionLabel: 'Translate & Clean'
  }
];

export default function Hero() {
  const [activeToolId, setActiveToolId] = useState('compress');
  const [files, setFiles] = useState<File[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [options, setOptions] = useState('');
  const [pageRanges, setPageRanges] = useState('');
  const [successMsg, setSuccessMsg] = useState(false);
  const [downloadUrl, setDownloadUrl] = useState<string | null>(null);
  const [downloadFilename, setDownloadFilename] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const workspaceRef = useRef<HTMLDivElement>(null);

  // States for Compress (Reduce Size) tool customization
  const [compressMode, setCompressMode] = useState<'decrease' | 'increase'>('decrease');
  const [compressLevel, setCompressLevel] = useState('recommended');
  const [targetSizeOn, setTargetSizeOn] = useState(false);
  const [targetKB, setTargetKB] = useState('50');
  const [customTargetKB, setCustomTargetKB] = useState('');
  const [resizePageOn, setResizePageOn] = useState(false);
  const [resizeWidth, setResizeWidth] = useState('800');
  const [resizeHeight, setResizeHeight] = useState('1100');
  const [resizeUnit, setResizeUnit] = useState<'px' | 'cm'>('px');

  const currentTool = TOOLS.find(t => t.id === activeToolId) || TOOLS[0];

  // Reset inputs when tool changes
  useEffect(() => {
    setFiles([]);
    setOptions('');
    setPageRanges('');
    setSuccessMsg(false);
    setDownloadUrl(null);
    setDownloadFilename('');
  }, [activeToolId]);

  const validateFile = (file: File): Promise<{ valid: boolean; message?: string }> => {
    // Check size
    if (file.size === 0) {
      return Promise.resolve({ 
        valid: false, 
        message: `The file "${file.name}" is empty (0 bytes). Please upload a valid document.\n(Kripya sahi document upload karein, yeh khali file hai.)` 
      });
    }
    
    // Check PDF header physically if it is a pdf format
    if (file.name.toLowerCase().endsWith('.pdf')) {
      return new Promise((resolve) => {
        const reader = new FileReader();
        reader.onloadend = (e) => {
          const arr = new Uint8Array(e.target?.result as ArrayBuffer);
          if (arr.length < 4) {
            resolve({ 
              valid: false, 
              message: `The file "${file.name}" is corrupted or too small to be a PDF.\n(Kripya valid PDF document hi upload karein.)` 
            });
            return;
          }
          const header = String.fromCharCode(arr[0], arr[1], arr[2], arr[3]);
          if (header !== '%PDF') {
            resolve({ 
              valid: false, 
              message: `The file "${file.name}" does not have a valid PDF header structure. It may be corrupted or not a real PDF document.\n(Aapne jo file upload ki hai woh ek valid PDF nahi hai. Kripya valid PDF document hi upload karein.)` 
            });
          } else {
            resolve({ valid: true });
          }
        };
        reader.onerror = () => resolve({ 
          valid: false, 
          message: `Could not read file "${file.name}".\n(Kripya sahi file chunein.)` 
        });
        reader.readAsArrayBuffer(file.slice(0, 5));
      });
    }
    
    return Promise.resolve({ valid: true });
  };

  const handleFiles = async (newFiles: FileList | null) => {
    if (newFiles) {
      const array = Array.from(newFiles);
      if (currentTool.accept) {
        const allowedExtensions = currentTool.accept.split(',').map(ext => ext.trim().toLowerCase());
        const invalidFiles = array.filter(file => {
          const ext = '.' + file.name.split('.').pop()?.toLowerCase();
          return !allowedExtensions.includes(ext);
        });

        if (invalidFiles.length > 0) {
          alert(`Invalid file selected! Please upload files with these formats: ${currentTool.accept}\n(Kripya sahi format ki file upload karein: ${currentTool.accept})`);
          return;
        }
      }

      // Physical content verification
      const validatedFiles: File[] = [];
      for (const file of array) {
        const check = await validateFile(file);
        if (!check.valid) {
          alert(check.message);
          return;
        }
        validatedFiles.push(file);
      }

      if (currentTool.multiple) {
        setFiles(prev => [...prev, ...validatedFiles]);
      } else {
        setFiles([validatedFiles[0]]);
      }
      setSuccessMsg(false);
    }
  };

  const removeFile = (index: number) => {
    setFiles(prev => prev.filter((_, i) => i !== index));
  };

  const moveFileUp = (index: number) => {
    if (index === 0) return;
    setFiles(prev => {
      const copy = [...prev];
      const temp = copy[index];
      copy[index] = copy[index - 1];
      copy[index - 1] = temp;
      return copy;
    });
  };

  const moveFileDown = (index: number) => {
    if (index === files.length - 1) return;
    setFiles(prev => {
      const copy = [...prev];
      const temp = copy[index];
      copy[index] = copy[index + 1];
      copy[index + 1] = temp;
      return copy;
    });
  };

  const generateSamplePDF = async () => {
    try {
      const { PDFDocument } = await import('pdf-lib');
      const pdfDoc = await PDFDocument.create();
      const page = pdfDoc.addPage([595, 842]);
      
      const num = Math.floor(Math.random() * 90) + 10;
      page.drawText('PDFPro Online System', { x: 50, y: 780, size: 24 });
      page.drawText('DURABLE SECURE VERIFIABLE DEMO PDF SHEET', { x: 50, y: 745, size: 10 });
      page.drawText(`File Reference Token: PDFPRO-SAMPLE-${num}`, { x: 50, y: 720, size: 11 });
      page.drawText(`Generated on Local Client: ${new Date().toLocaleString()}`, { x: 50, y: 700, size: 10 });
      
      page.drawText('Welcome to your professional high-fidelity PDF editing dashboard.', { x: 50, y: 640, size: 12 });
      page.drawText('This document contains custom structured paragraphs and metadata schemas.', { x: 50, y: 615, size: 11 });
      page.drawText('You can merge multiple of these files, split page ranges, redact rows,', { x: 50, y: 590, size: 11 });
      page.drawText('rotate layout cards, or compress binary structures successfully!', { x: 50, y: 565, size: 11 });
      
      page.drawRectangle({
        x: 45,
        y: 150,
        width: 505,
        height: 380,
        borderWidth: 1,
        opacity: 0.1,
      });
      
      page.drawText('This document is certified compliant for standard PDF/A secure workflows.', { x: 65, y: 490, size: 10 });
      
      const pdfBytes = await pdfDoc.save();
      const blob = new Blob([pdfBytes], { type: 'application/pdf' });
      // Avoid calling the "new File" constructor completely to prevent "Illegal constructor" in sandboxed environments.
      const customFile = blob as any;
      customFile.name = `sample_work_file_${num}.pdf`;
      customFile.lastModified = Date.now();
      const file = customFile as File;
      
      if (currentTool.multiple) {
        setFiles(prev => [...prev, file]);
      } else {
        setFiles([file]);
      }
      setSuccessMsg(false);
    } catch (err: any) {
      console.error(err);
      alert('Error generating dynamic sample document: ' + err.message);
    }
  };

  const selectTool = (toolId: string) => {
    setActiveToolId(toolId);
    if (workspaceRef.current) {
      workspaceRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const handleProcess = async () => {
    if (files.length === 0) return;
    setIsProcessing(true);
    setSuccessMsg(false);
    setDownloadUrl(null);
    setDownloadFilename('');

    // Serialize compress tool configurations to JSON
    let finalOptions = options;
    if (currentTool.id === 'compress') {
      const configObj = {
        mode: compressMode,
        compressLevel: compressLevel,
        targetSizeOn: targetSizeOn,
        targetKB: targetSizeOn ? (targetKB === 'custom' ? parseFloat(customTargetKB) || 50 : parseFloat(targetKB)) : 0,
        resizePageOn: resizePageOn,
        resizeWidth: parseFloat(resizeWidth) || 0,
        resizeHeight: parseFloat(resizeHeight) || 0,
        resizeUnit: resizeUnit
      };
      finalOptions = JSON.stringify(configObj);
    }

    const formData = new FormData();
    files.forEach(file => formData.append('files', file, file.name));
    formData.append('tool', currentTool.id);
    formData.append('options', finalOptions);
    formData.append('pageRanges', pageRanges);

    try {
      const response = await fetch('/api/process-pdf', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        const errorJson = await response.json().catch(() => ({}));
        throw new Error(errorJson.error || 'Processing failed');
      }

      const contentType = response.headers.get('content-type') || '';
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      setDownloadUrl(url);
      
      let extension = 'pdf';
      if (contentType.includes('application/zip')) {
        extension = 'zip';
      } else if (contentType.includes('image/png')) {
        extension = 'png';
      } else if (contentType.includes('image/jpeg')) {
        extension = 'jpg';
      } else if (contentType.includes('application/vnd.openxmlformats-officedocument.wordprocessingml.document')) {
        extension = 'docx';
      } else if (contentType.includes('application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')) {
        extension = 'xlsx';
      } else if (contentType.includes('application/vnd.openxmlformats-officedocument.presentationml.presentation')) {
        extension = 'pptx';
      } else if (contentType.includes('text/html')) {
        extension = 'html';
      } else if (contentType.includes('text/plain')) {
        extension = 'txt';
      } else {
        // Fallback to tool-based mapping
        if (currentTool.id === 'pdf-to-jpg') extension = 'jpg';
        else if (currentTool.id === 'pdf-to-png') extension = 'png';
        else if (currentTool.id === 'pdf-to-word') extension = 'docx';
        else if (currentTool.id === 'pdf-to-ppt') extension = 'pptx';
        else if (currentTool.id === 'pdf-to-excel') extension = 'xlsx';
        else if (currentTool.id === 'pdf-to-html') extension = 'html';
        else if (currentTool.id === 'pdf-to-txt') extension = 'txt';
      }

      const filename = `${currentTool.title.replace(/\s+/g, '_').toLowerCase()}_result.${extension}`;
      setDownloadFilename(filename);
      setSuccessMsg(true);

      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      a.click();
    } catch (error: any) {
      console.error(error);
      alert(`Error processing file: ${error.message}`);
    } finally {
      setIsProcessing(false);
    }
  };

  const renderExtraOptions = () => {
    switch (currentTool.id) {
      case 'split':
      case 'extract':
        return (
          <div className="mt-4 text-left">
            <label className="block text-sm font-semibold text-gray-700 mb-1">Page Ranges</label>
            <input 
              type="text" 
              placeholder="e.g. 1-2, 4 (default: first half)" 
              value={pageRanges}
              onChange={(e) => setPageRanges(e.target.value)}
              className="w-full p-2.5 border border-gray-300 rounded-md focus:ring-2 focus:ring-indigo-500 font-mono text-sm outline-none"
            />
            <p className="text-xs text-gray-500 mt-1">Specify ranges separated by commas to extract corresponding pages.</p>
          </div>
        );
      case 'remove':
        return (
          <div className="mt-4 text-left">
            <label className="block text-sm font-semibold text-gray-700 mb-1">Pages to Remove</label>
            <input 
              type="text" 
              placeholder="e.g. 2, 4-5 (default: deletes last page)" 
              value={pageRanges}
              onChange={(e) => setPageRanges(e.target.value)}
              className="w-full p-2.5 border border-gray-300 rounded-md focus:ring-2 focus:ring-indigo-500 font-mono text-sm outline-none"
            />
            <p className="text-xs text-gray-500 mt-1">Enter specific page numbers to remove from your output file.</p>
          </div>
        );
      case 'organize':
        return (
          <div className="mt-4 text-left">
            <label className="block text-sm font-semibold text-gray-700 mb-1">Desired Page Order</label>
            <input 
              type="text" 
              placeholder="e.g. 3,1,2 (default: reverses page order)" 
              value={options}
              onChange={(e) => setOptions(e.target.value)}
              className="w-full p-2.5 border border-gray-300 rounded-md focus:ring-2 focus:ring-indigo-500 font-mono text-sm outline-none"
            />
          </div>
        );
      case 'rotate':
        return (
          <div className="mt-4 text-left">
            <label className="block text-sm font-semibold text-gray-700 mb-1">Rotation Angle</label>
            <select 
              value={options} 
              onChange={(e) => setOptions(e.target.value)}
              className="w-full p-2.5 border border-gray-300 rounded-md focus:ring-2 focus:ring-indigo-500 text-sm outline-none"
            >
              <option value="90">90° Clockwise</option>
              <option value="180">180° Flip</option>
              <option value="270">270° Counter-Clockwise</option>
            </select>
          </div>
        );
      case 'add-pages':
        return (
          <div className="mt-4 text-left">
            <label className="block text-sm font-semibold text-gray-700 mb-1">Blank Pages to Add</label>
            <input 
              type="number" 
              min="1" 
              max="10" 
              value={options} 
              placeholder="1"
              onChange={(e) => setOptions(e.target.value)}
              className="w-full p-2.5 border border-gray-300 rounded-md focus:ring-2 focus:ring-indigo-500 text-sm font-mono outline-none"
            />
          </div>
        );
      case 'watermark':
        return (
          <div className="mt-4 text-left">
            <label className="block text-sm font-semibold text-gray-700 mb-1">Watermark Text</label>
            <input 
              type="text" 
              placeholder="e.g. CONFIDENTIAL, DRAW, PRIVATE" 
              value={options} 
              onChange={(e) => setOptions(e.target.value)}
              className="w-full p-2.5 border border-gray-300 rounded-md focus:ring-2 focus:ring-indigo-500 text-sm outline-none"
            />
          </div>
        );
      case 'protect':
        return (
          <div className="mt-4 text-left">
            <label className="block text-sm font-semibold text-gray-700 mb-1">Password Key</label>
            <input 
              type="password" 
              placeholder="Set encryption password" 
              value={options} 
              onChange={(e) => setOptions(e.target.value)}
              className="w-full p-2.5 border border-gray-300 rounded-md focus:ring-2 focus:ring-indigo-500 text-sm font-mono outline-none"
            />
          </div>
        );
      case 'sign':
        return (
          <div className="mt-4 text-left">
            <label className="block text-sm font-semibold text-gray-700 mb-1">Digital Signature Name</label>
            <input 
              type="text" 
              placeholder="e.g. John Watson, Authorized Officer" 
              value={options} 
              onChange={(e) => setOptions(e.target.value)}
              className="w-full p-2.5 border border-gray-300 rounded-md focus:ring-2 focus:ring-indigo-500 text-sm outline-none"
            />
          </div>
        );
      case 'translate':
        return (
          <div className="mt-4 text-left">
            <label className="block text-sm font-semibold text-gray-700 mb-1">Target Language</label>
            <select 
              value={options} 
              onChange={(e) => setOptions(e.target.value)}
              className="w-full p-2.5 border border-gray-300 rounded-md focus:ring-2 focus:ring-indigo-500 text-sm outline-none"
            >
              <option value="">Select Language</option>
              <option value="Hindi">Hindi / हिन्दी</option>
              <option value="Spanish">Spanish / Español</option>
              <option value="French">French / Français</option>
              <option value="German">German / Deutsch</option>
              <option value="Japanese">Japanese / 日本語</option>
            </select>
          </div>
        );
      case 'compress':
        return (
          <div className="mt-6 border-t border-gray-100 pt-5 text-left space-y-6">
            <h4 className="text-sm font-bold text-gray-800 uppercase tracking-wider border-b pb-2 flex items-center gap-2">
              <Minimize2 size={16} className="text-indigo-600" />
              Size Options & Conversions
            </h4>

            {/* Mode Select: Decrease or Increase */}
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">
                1. Mode Selector
              </label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setCompressMode('decrease')}
                  className={`py-2.5 px-4 rounded-xl border text-xs font-bold transition-all text-center ${
                    compressMode === 'decrease'
                      ? 'bg-indigo-50 border-indigo-500 text-indigo-700 shadow-sm'
                      : 'bg-white border-gray-200 text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  📉 Decrease Size (Compress)
                </button>
                <button
                  type="button"
                  onClick={() => setCompressMode('increase')}
                  className={`py-2.5 px-4 rounded-xl border text-xs font-bold transition-all text-center ${
                    compressMode === 'increase'
                      ? 'bg-indigo-50 border-indigo-500 text-indigo-700 shadow-sm'
                      : 'bg-white border-gray-200 text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  📈 Increase Size (Bytes Padding)
                </button>
              </div>
            </div>

            {/* Decrease Mode Presets */}
            {compressMode === 'decrease' && (
              <div>
                <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">
                  Compression Intensity
                </label>
                <select
                  value={compressLevel}
                  onChange={(e) => setCompressLevel(e.target.value)}
                  className="w-full p-2.5 border border-gray-300 rounded-lg text-xs outline-none bg-white font-medium"
                >
                  <option value="recommended">Recommended Compression (Best quality + size)</option>
                  <option value="extreme">Extreme Compression (Minimum quality, smallest size)</option>
                  <option value="low">Low Compression (High quality, standard size)</option>
                </select>
              </div>
            )}

            {/* Target KB Boundary Selector */}
            <div className="bg-gray-50 p-4 rounded-xl border border-gray-200">
              <div className="flex items-center justify-between mb-2">
                <label className="text-xs font-bold text-gray-700 uppercase tracking-wider flex items-center gap-1.5 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={targetSizeOn}
                    onChange={(e) => setTargetSizeOn(e.target.checked)}
                    className="rounded text-indigo-600 focus:ring-indigo-500 h-4 w-4"
                  />
                  <span>Limit Target KB Size</span>
                </label>
                <span className="text-[10px] font-bold bg-indigo-100 text-indigo-800 px-2 py-0.5 rounded-full uppercase">
                  Custom KB Lock
                </span>
              </div>
              <p className="text-[11px] text-gray-500 mb-3">
                Force output file size as close as possible to a manually defined KB count e.g. 10KB, 50KB.
              </p>

              {targetSizeOn && (
                <div className="space-y-3 pt-1 animate-fadeIn">
                  <div className="flex flex-wrap gap-2">
                    {['10', '50', '100', '200', '500', 'custom'].map((val) => (
                      <button
                        type="button"
                        key={val}
                        onClick={() => setTargetKB(val)}
                        className={`px-3 py-1.5 rounded-lg border text-xs font-semibold transition-all ${
                          targetKB === val
                            ? 'bg-indigo-600 border-indigo-600 text-white shadow-sm'
                            : 'bg-white border-gray-200 text-gray-700 hover:bg-gray-50'
                        }`}
                      >
                        {val === 'custom' ? 'Custom KB' : `${val} KB`}
                      </button>
                    ))}
                  </div>

                  {targetKB === 'custom' && (
                    <div className="animate-slideDown">
                      <label className="block text-[11px] font-bold text-gray-600 mb-1">Enter Custom Size (in KB):</label>
                      <input
                        type="number"
                        placeholder="e.g. 35"
                        value={customTargetKB}
                        onChange={(e) => setCustomTargetKB(e.target.value)}
                        className="p-2 border border-gray-300 rounded-md w-32 outline-none text-xs font-mono"
                      />
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Photo Size Dimension Adjustments */}
            <div className="bg-gray-50 p-4 rounded-xl border border-gray-200">
              <div className="flex items-center justify-between mb-2">
                <label className="text-xs font-bold text-gray-700 uppercase tracking-wider flex items-center gap-1.5 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={resizePageOn}
                    onChange={(e) => setResizePageOn(e.target.checked)}
                    className="rounded text-indigo-600 focus:ring-indigo-500 h-4 w-4"
                  />
                  <span>Adjust Page / Photo Dimensions (Pixels or CM)</span>
                </label>
                <span className="text-[10px] font-bold bg-amber-100 text-amber-800 px-2 py-0.5 rounded-full uppercase">
                  Resizer tools
                </span>
              </div>
              <p className="text-[11px] text-gray-500 mb-3">
                Manually configure width & height in Pixels or CM to resize layout photos or forms inside the PDF.
              </p>

              {resizePageOn && (
                <div className="space-y-4 pt-1 animate-fadeIn">
                  {/* Unit Selector */}
                  <div className="flex gap-4 items-center">
                    <span className="text-xs font-semibold text-gray-650 font-medium font-sans">Unit:</span>
                    <label className="flex items-center gap-1.5 text-xs text-gray-700 font-medium cursor-pointer">
                      <input
                        type="radio"
                        checked={resizeUnit === 'px'}
                        onChange={() => setResizeUnit('px')}
                        className="text-indigo-600 focus:ring-indigo-500 h-3.5 w-3.5"
                      />
                      Pixels (px)
                    </label>
                    <label className="flex items-center gap-1.5 text-xs text-gray-700 font-medium cursor-pointer">
                      <input
                        type="radio"
                        checked={resizeUnit === 'cm'}
                        onChange={() => setResizeUnit('cm')}
                        className="text-indigo-600 focus:ring-indigo-500 h-3.5 w-3.5"
                      />
                      Centimeters (cm)
                    </label>
                  </div>

                  {/* Width & Height Inputs */}
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[11px] font-bold text-gray-600 mb-1">
                        Width ({resizeUnit === 'px' ? 'px' : 'cm'}):
                      </label>
                      <input
                        type="number"
                        step="any"
                        value={resizeWidth}
                        onChange={(e) => setResizeWidth(e.target.value)}
                        className="w-full p-2 border border-gray-300 rounded-md outline-none text-xs font-mono"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-bold text-gray-600 mb-1">
                        Height ({resizeUnit === 'px' ? 'px' : 'cm'}):
                      </label>
                      <input
                        type="number"
                        step="any"
                        value={resizeHeight}
                        onChange={(e) => setResizeHeight(e.target.value)}
                        className="w-full p-2 border border-gray-300 rounded-md outline-none text-xs font-mono"
                      />
                    </div>
                  </div>

                  {/* Presets Grid */}
                  <div>
                    <span className="block text-[10px] font-bold text-gray-400 uppercase mb-1.5 font-sans">Quick Presets:</span>
                    <div className="flex flex-wrap gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          if (resizeUnit === 'px') {
                            setResizeWidth('595');
                            setResizeHeight('842');
                          } else {
                            setResizeWidth('21');
                            setResizeHeight('29.7');
                          }
                        }}
                        className="text-[10px] bg-white border px-2 py-1 rounded text-gray-600 hover:bg-gray-100 font-medium"
                      >
                        📄 A4 Sheet ({resizeUnit === 'px' ? '595x842 px' : '21x29.7 cm'})
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          if (resizeUnit === 'px') {
                            setResizeWidth('612');
                            setResizeHeight('792');
                          } else {
                            setResizeWidth('21.59');
                            setResizeHeight('27.94');
                          }
                        }}
                        className="text-[10px] bg-white border px-2 py-1 rounded text-gray-600 hover:bg-gray-100 font-medium"
                      >
                        📄 Letter Size
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          if (resizeUnit === 'px') {
                            setResizeWidth('150');
                            setResizeHeight('150');
                          } else {
                            setResizeWidth('3.5');
                            setResizeHeight('4.5');
                          }
                        }}
                        className="text-[10px] bg-white border px-2 py-1 rounded text-gray-600 hover:bg-gray-100 font-medium"
                      >
                        👤 Photo ID Passport ({resizeUnit === 'px' ? '150x150 px' : '3.5x4.5 cm'})
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        );
      default:
        return null;
    }
  };



  return (
    <section className="pt-12 pb-16 px-4 md:px-12 max-w-7xl mx-auto" ref={workspaceRef}>
      
      {/* Top Banner Tagline */}
      <div className="text-center mb-6">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-indigo-50 text-indigo-700 font-semibold text-sm">
          <currentTool.icon size={16} />
          <span>Active Workspace: {currentTool.title}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Dynamic Workspace Container */}
        <div className="lg:col-span-8 bg-white border border-gray-200 rounded-2xl p-6 md:p-8 shadow-sm">
          <div className="mb-4">
            <h1 className="text-3xl font-extrabold text-gray-900 tracking-tight flex items-center gap-3">
              <currentTool.icon className="text-indigo-700" size={32} />
              {currentTool.title}
            </h1>
            <p className="text-gray-600 mt-2 text-sm md:text-base">
              {currentTool.desc}
            </p>
          </div>

          {/* Staging Drop Zone */}
          <div 
            className="mt-6 bg-gray-50 border-2 border-dashed border-gray-300 rounded-xl p-8 md:p-12 flex flex-col items-center justify-center text-center cursor-pointer hover:border-indigo-600 transition-colors group"
            onClick={() => fileInputRef.current?.click()}
          >
            <div className="w-16 h-16 bg-white rounded-full shadow-sm flex items-center justify-center mb-4 group-hover:scale-105 transition-transform">
              <FileUp size={28} className="text-indigo-700" />
            </div>
            <h3 className="text-lg font-bold text-gray-900 mb-1">Click or drag & drop files here</h3>
            <p className="text-sm text-gray-500 max-w-sm mb-4">
              Accepted formats: <span className="font-mono bg-white px-2 py-0.5 rounded text-indigo-700 border border-gray-100">{currentTool.accept}</span>
            </p>
            <div className="flex flex-col sm:flex-row gap-3 mt-2" onClick={(e) => e.stopPropagation()}>
              <button 
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="bg-white border border-gray-300 text-gray-800 px-6 py-2.5 rounded-lg font-bold text-sm hover:bg-gray-105 transition-all flex items-center justify-center gap-2 shadow-sm"
              >
                <Plus size={16} className="text-indigo-700" strokeWidth={3} />
                Select Files
              </button>
              
              <button 
                type="button"
                onClick={generateSamplePDF}
                className="bg-indigo-50 border border-indigo-200 text-indigo-700 hover:bg-indigo-100 hover:text-indigo-800 px-5 py-2.5 rounded-lg font-bold text-sm transition-all flex items-center justify-center gap-2 shadow-sm"
                title="Create a high-quality valid PDF instantly to test"
              >
                <Sparkles size={16} className="text-indigo-600 shrink-0" />
                Create Demo PDF
              </button>
            </div>
            <input 
              type="file" 
              ref={fileInputRef} 
              accept={currentTool.accept}
              multiple={currentTool.multiple} 
              className="hidden" 
              onChange={(e) => handleFiles(e.target.files)} 
            />
          </div>

          {/* Files List Panel */}
          {files.length > 0 && (
            <div className="mt-6 border border-gray-200 rounded-xl p-4 bg-white text-left">
              <h4 className="text-sm font-bold text-gray-800 mb-3 flex items-center justify-between">
                <span>Uploaded Files ({files.length})</span>
                <button 
                  onClick={() => setFiles([])} 
                  className="text-xs text-red-500 hover:underline font-semibold"
                >
                  Clear All
                </button>
              </h4>
              <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                {files.map((file, idx) => (
                  <div key={idx} className="flex justify-between items-center p-2.5 bg-gray-50 hover:bg-gray-100 rounded-lg text-sm border border-gray-100 transition-colors gap-2">
                    <span className="truncate flex-1 flex items-center gap-2 font-medium text-gray-700">
                      <FileText size={16} className="text-indigo-600 shrink-0" />
                      {file.name}
                    </span>
                    <div className="flex items-center gap-1.5 shrink-0">
                      <span className="text-xs text-gray-400 font-mono mr-2">{(file.size / 1024).toFixed(1)} KB</span>
                      {files.length > 1 && (
                        <>
                          <button 
                            type="button"
                            onClick={(e) => { e.stopPropagation(); moveFileUp(idx); }} 
                            disabled={idx === 0}
                            className="p-1 rounded text-gray-500 hover:text-indigo-600 hover:bg-gray-200/50 disabled:opacity-20 disabled:hover:bg-transparent disabled:hover:text-gray-500"
                            title="Move Up"
                          >
                            <ArrowUp size={15} />
                          </button>
                          <button 
                            type="button"
                            onClick={(e) => { e.stopPropagation(); moveFileDown(idx); }} 
                            disabled={idx === files.length - 1}
                            className="p-1 rounded text-gray-500 hover:text-indigo-600 hover:bg-gray-200/50 disabled:opacity-20 disabled:hover:bg-transparent disabled:hover:text-gray-500"
                            title="Move Down"
                          >
                            <ArrowDown size={15} />
                          </button>
                        </>
                      )}
                      <button 
                        type="button"
                        onClick={(e) => { e.stopPropagation(); removeFile(idx); }}
                        className="p-1.5 rounded hover:bg-red-50 text-gray-400 hover:text-red-600 transition"
                        title="Remove file"
                      >
                        <Trash2 size={15} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Dynamic Extra Custom Fields */}
          {files.length > 0 && !successMsg && renderExtraOptions()}

          {/* Loading Animation States */}
          {isProcessing && (
            <div className="mt-6 p-6 bg-indigo-50/50 border border-indigo-100 rounded-xl text-center space-y-3 animate-pulse">
              <Loader2 size={32} className="animate-spin mx-auto text-indigo-700" />
              <p className="font-bold text-gray-800 text-sm">Uploading and Processing PDF: {currentTool.title}...</p>
              <p className="text-xs text-gray-500">Processing file securely. Please wait a few seconds...</p>
            </div>
          )}

          {/* Prominent Success View with Manual Download Button */}
          {successMsg && downloadUrl && (
            <div className="mt-6 p-6 bg-emerald-50 border-2 border-emerald-200 rounded-xl text-center space-y-4 shadow-sm">
              <div className="w-12 h-12 bg-emerald-100 rounded-full flex items-center justify-center mx-auto text-emerald-700">
                <CheckCircle size={24} />
              </div>
              <div>
                <h4 className="text-md font-bold text-gray-900">PDF Processed Successfully!</h4>
                <p className="text-xs text-emerald-700 font-medium mt-1">Your file is ready for download!</p>
                <p className="text-xs text-gray-500 mt-2 truncate max-w-xs mx-auto font-mono bg-white px-2.5 py-1.5 rounded-md border border-gray-100 text-center">
                  📄 {downloadFilename}
                </p>
              </div>

              <div className="flex flex-col gap-2.5">
                <a 
                  href={downloadUrl}
                  download={downloadFilename}
                  className="w-full bg-emerald-600 hover:bg-emerald-700 text-white py-3 rounded-lg font-bold text-sm shadow transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-[0.99]"
                >
                  <Download size={18} />
                  Download Processed File
                </a>
                
                <button 
                  type="button"
                  onClick={() => {
                    setFiles([]);
                    setSuccessMsg(false);
                    setDownloadUrl(null);
                    setDownloadFilename('');
                  }}
                  className="text-xs text-indigo-600 hover:text-indigo-800 font-bold hover:underline py-1.5"
                >
                  Process another document
                </button>
              </div>
            </div>
          )}

          {/* Perform Active Workspace Action Button */}
          {!isProcessing && !successMsg && (
            <div className="mt-8">
              <button 
                onClick={handleProcess}
                disabled={files.length === 0}
                className="w-full bg-indigo-700 text-white py-3.5 rounded-xl font-bold disabled:opacity-50 hover:bg-indigo-800 active:scale-[0.99] transition-all flex items-center justify-center gap-2 shadow-md hover:shadow-lg"
              >
                <Upload size={18} />
                <span>{currentTool.actionLabel}</span>
              </button>
            </div>
          )}
        </div>

        {/* Sidebar Tool switcher */}
        <div className="lg:col-span-4 bg-gray-50 border border-gray-200 rounded-2xl p-6">
          <h4 className="text-xs font-extrabold text-gray-400 uppercase tracking-widest mb-4">Quick Shortcuts</h4>
          <div className="space-y-2">
            {TOOLS.filter(t => ['merge', 'split', 'compress', 'jpg-to-pdf', 'watermark', 'protect', 'summarizer'].includes(t.id)).map((toolItem) => {
              const IsSelected = toolItem.id === activeToolId;
              const IconComp = toolItem.icon;
              return (
                <button
                  key={toolItem.id}
                  onClick={() => selectTool(toolItem.id)}
                  className={`w-full flex items-center justify-between p-3 rounded-xl text-left border transition-all text-sm ${
                    IsSelected 
                      ? 'bg-indigo-700 text-white border-indigo-700 shadow-md font-bold' 
                      : 'bg-white hover:bg-gray-100 border-gray-100 text-gray-700 hover:border-gray-200'
                  }`}
                >
                  <span className="flex items-center gap-3">
                    <IconComp size={18} className={IsSelected ? 'text-white' : 'text-indigo-600'} />
                    {toolItem.title}
                  </span>
                  <span className={`text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full ${
                    IsSelected ? 'bg-white/25 text-white' : 'bg-indigo-50 text-indigo-700'
                  }`}>
                    {toolItem.category}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

      </div>

      {/* Grid of All Fully Functional Category Tools */}
      <div className="mt-20 border-t border-gray-200 pt-16">
        <div className="text-center mb-10">
          <h2 className="text-3xl font-extrabold text-gray-900 tracking-tight">Categorized Dashboard Suite</h2>
          <p className="text-gray-600 mt-2 max-w-xl mx-auto text-sm leading-relaxed">
            Click on any function below to load it directly in the active workspace. Every tool works with server-side document calculations flawlessly.
          </p>
        </div>

        {/* Categories Grid wrapper */}
        {['Organize', 'Optimize', 'Convert to PDF', 'Convert from PDF', 'Edit', 'Security', 'Intelligence'].map((cat) => (
          <div key={cat} className="mb-12">
            <h3 className="text-xs font-extrabold text-gray-400 uppercase tracking-widest mb-4 pl-1 border-l-4 border-indigo-600 h-4 flex items-center">
              {cat}
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-4 md:grid-cols-5 gap-4">
              {TOOLS.filter(t => t.category === cat).map((toolCard) => {
                const CardIcon = toolCard.icon;
                const IsActive = toolCard.id === activeToolId;
                return (
                  <div
                    key={toolCard.id}
                    onClick={() => selectTool(toolCard.id)}
                    className={`p-4 rounded-xl border cursor-pointer hover:scale-[1.02] active:scale-[0.98] transition-all flex flex-col justify-between group h-32 ${
                      IsActive 
                        ? 'bg-indigo-50 border-indigo-500 shadow-inner' 
                        : 'bg-white border-gray-200 hover:border-indigo-300'
                    }`}
                  >
                    <div className="w-10 h-10 bg-indigo-50 rounded-lg flex items-center justify-center mb-3 group-hover:bg-indigo-600 group-hover:text-white transition-all text-indigo-700">
                      <CardIcon size={20} />
                    </div>
                    <div>
                      <h4 className={`text-xs font-bold leading-tight ${IsActive ? 'text-indigo-900' : 'text-gray-900 group-hover:text-indigo-700'}`}>
                        {toolCard.title}
                      </h4>
                      <p className="text-[10px] text-gray-400 truncate mt-1">{toolCard.desc}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ))}

      </div>

    </section>
  );
}
