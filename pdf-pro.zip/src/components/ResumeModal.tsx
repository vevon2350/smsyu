import React, { useState, useEffect, useRef } from 'react';
import { 
  X, Briefcase, GraduationCap, Code2, Globe, Heart, Plus, Trash2, 
  Download, FileUp, FileDown, RotateCcw, Sparkles, Check, ChevronDown, 
  ChevronUp, Layout, Phone, Mail, MapPin, Link as LinkIcon, Layers
} from 'lucide-react';

interface ResumeModalProps {
  onClose: () => void;
}

interface WorkExperience {
  id: string;
  company: string;
  role: string;
  startDate: string;
  endDate: string;
  description: string;
}

interface Education {
  id: string;
  institution: string;
  degree: string;
  startDate: string;
  endDate: string;
  gpa: string;
}

interface Project {
  id: string;
  name: string;
  techStack: string;
  link: string;
  description: string;
}

interface ResumeData {
  fullName: string;
  title: string;
  email: string;
  phone: string;
  location: string;
  website: string;
  summary: string;
  skills: string[];
  experience: WorkExperience[];
  education: Education[];
  projects: Project[];
  languages: string[];
}

const DEFAULT_RESUME_DATA: ResumeData = {
  fullName: "Alexander Wright",
  title: "Principal Frontend Engineer",
  email: "alexander.wright@email.com",
  phone: "+1 (555) 019-2834",
  location: "San Francisco, CA",
  website: "https://alexwright.dev",
  summary: "Driven frontend architect with 6+ years of experience designing high-performance React architectures and web applications. Passionate about user-centric product designs, code usability, state modularity, and high-quality graphics engines. Proven legacy of leading developers to ship modular APIs and responsive interfaces.",
  skills: [
    "TypeScript", "React 19 & Next.js", "Tailwind CSS", "State Managers (Zustand, Redux)", 
    "Web Performance Tuning", "GraphQL & REST APIs", "Systems Architecture", "CI/CD & Docker"
  ],
  experience: [
    {
      id: "exp-1",
      company: "Innovate Tech Corp",
      role: "Lead UI Developer",
      startDate: "2023-01",
      endDate: "Present",
      description: "Engineered a low-latency analytics playground with complex interactive charts driving a 34% increase in user retention. Standardized custom React component guidelines, cutting development cycle time by 2.5 days per sprint. Mentored 4 junior engineers on semantic markup."
    },
    {
      id: "exp-2",
      company: "DataSync Solutions",
      role: "Frontend Engineer",
      startDate: "2021-03",
      endDate: "2022-12",
      description: "Implemented cloud server integration dashboards resolving over 3.2M operations daily. Reduced mobile browser payload size by 45% via bundle splitting, route lazy loading, and SVG replacement optimization."
    }
  ],
  education: [
    {
      id: "edu-1",
      institution: "Stanford University",
      degree: "B.S. in Computer Science",
      startDate: "2017-09",
      endDate: "2021-05",
      gpa: "3.8/4.0"
    }
  ],
  projects: [
    {
      id: "proj-1",
      name: "VectorDraw Engine",
      techStack: "React, WebGL, Canvas API",
      link: "https://vector-playground.io",
      description: "Full-fleged interactive web vector sketchpad with layering, live color-quantization vectors, and SVG extraction pipeline exported to local storage."
    },
    {
      id: "proj-2",
      name: "Modular State Proxy",
      techStack: "TypeScript, Proxy API",
      link: "https://npmjs.org/package/state-proxy",
      description: "Lightweight 900-byte state engine monitoring React hooks dynamically using native ES6 proxies. Over 40,000 active monthly downloads."
    }
  ],
  languages: ["English (Native)", "Spanish (Professional)"]
};

type TemplateId = 'modern' | 'serif' | 'tech' | 'executive' | 'creative';

interface TemplateOption {
  id: TemplateId;
  name: string;
  palette: string;
  desc: string;
}

const TEMPLATES: TemplateOption[] = [
  { 
    id: 'modern', 
    name: 'Modern Slate', 
    palette: 'bg-indigo-600', 
    desc: 'Contemporary dual-column design with subtle blue titles, clean Inter fonts and high structural clarity.' 
  },
  { 
    id: 'serif', 
    name: 'Elegant Serif', 
    palette: 'bg-amber-800', 
    desc: 'Editorial classic style with Georgia fonts, centered alignment, and premium traditional aesthetic.' 
  },
  { 
    id: 'tech', 
    name: 'Minimal Tech', 
    palette: 'bg-neutral-800', 
    desc: 'Sleek developer-centric monospaced styling showing tagged boxes, crisp lines, and precise grids.' 
  },
  { 
    id: 'executive', 
    name: 'Executive Classic', 
    palette: 'bg-blue-900', 
    desc: 'Formal corporate layout with header banner, bold dividers, traditional layout, and high text density.' 
  },
  { 
    id: 'creative', 
    name: 'Creative Pastel', 
    palette: 'bg-rose-500', 
    desc: 'Playful artistic profile utilizing warmth accents, curved avatars, and modern layout balance.' 
  }
];

export default function ResumeModal({ onClose }: ResumeModalProps) {
  const [data, setData] = useState<ResumeData>(() => {
    const saved = localStorage.getItem('pdfpro_resume_draft');
    return saved ? JSON.parse(saved) : DEFAULT_RESUME_DATA;
  });

  const [activeTemplate, setActiveTemplate] = useState<TemplateId>('modern');
  const [activeSection, setActiveSection] = useState<string>('personal');
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Auto save draft to local storage
  useEffect(() => {
    localStorage.setItem('pdfpro_resume_draft', JSON.stringify(data));
  }, [data]);

  const handleReset = () => {
    if (window.confirm("Are you sure you want to restore default template details? This will replace your current edit draft.")) {
      setData(DEFAULT_RESUME_DATA);
    }
  };

  const handleFieldChange = (field: keyof ResumeData, value: any) => {
    setData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleArrayChange = (field: 'skills' | 'languages', index: number, value: string) => {
    const newArr = [...data[field]];
    newArr[index] = value;
    handleFieldChange(field, newArr);
  };

  const addArrayValue = (field: 'skills' | 'languages') => {
    handleFieldChange(field, [...data[field], '']);
  };

  const removeArrayValue = (field: 'skills' | 'languages', index: number) => {
    handleFieldChange(field, data[field].filter((_, i) => i !== index));
  };

  // Experience Handlers
  const handleExperienceChange = (id: string, field: keyof WorkExperience, value: string) => {
    const updated = data.experience.map(item => {
      if (item.id === id) {
        return { ...item, [field]: value };
      }
      return item;
    });
    handleFieldChange('experience', updated);
  };

  const addExperience = () => {
    const newExp: WorkExperience = {
      id: `exp-${Date.now()}`,
      company: 'New Corporation',
      role: 'Software Developer',
      startDate: '2024-01',
      endDate: 'Present',
      description: 'Describe details, tasks accomplished, technology stack, and milestones achieved.'
    };
    handleFieldChange('experience', [...data.experience, newExp]);
  };

  const removeExperience = (id: string) => {
    handleFieldChange('experience', data.experience.filter(item => item.id !== id));
  };

  // Education Handlers
  const handleEducationChange = (id: string, field: keyof Education, value: string) => {
    const updated = data.education.map(item => {
      if (item.id === id) {
        return { ...item, [field]: value };
      }
      return item;
    });
    handleFieldChange('education', updated);
  };

  const addEducation = () => {
    const newEdu: Education = {
      id: `edu-${Date.now()}`,
      institution: 'State University',
      degree: 'Degree of Engineering',
      startDate: '2019',
      endDate: '2023',
      gpa: '3.6/4.0'
    };
    handleFieldChange('education', [...data.education, newEdu]);
  };

  const removeEducation = (id: string) => {
    handleFieldChange('education', data.education.filter(item => item.id !== id));
  };

  // Projects Handlers
  const handleProjectChange = (id: string, field: keyof Project, value: string) => {
    const updated = data.projects.map(item => {
      if (item.id === id) {
        return { ...item, [field]: value };
      }
      return item;
    });
    handleFieldChange('projects', updated);
  };

  const addProject = () => {
    const newProj: Project = {
      id: `proj-${Date.now()}`,
      name: 'My Open Source Project',
      techStack: 'React, Node, Tailwind',
      link: 'https://github.com/myusername',
      description: 'Integrated complete dashboard logic and built interactive visualizer hooks.'
    };
    handleFieldChange('projects', [...data.projects, newProj]);
  };

  const removeProject = (id: string) => {
    handleFieldChange('projects', data.projects.filter(item => item.id !== id));
  };

  // Export Data
  const exportResumeJSON = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(data, null, 2));
    const dlAnchorElem = document.createElement('a');
    dlAnchorElem.setAttribute("href", dataStr);
    dlAnchorElem.setAttribute("download", `${data.fullName.replace(/\s+/g, '_')}_Resume_Backup.json`);
    dlAnchorElem.click();
  };

  // Import Data
  const importResumeJSON = (e: React.ChangeEvent<HTMLInputElement>) => {
    const fileReader = new FileReader();
    if (e.target.files && e.target.files[0]) {
      fileReader.readAsText(e.target.files[0], "UTF-8");
      fileReader.onload = (event) => {
        try {
          const parsed = JSON.parse(event.target?.result as string);
          if (parsed && typeof parsed === 'object' && parsed.fullName) {
            setData(parsed);
          } else {
            alert("Invalid draft file architecture! Please make sure it's a valid backup JSON format.");
          }
        } catch (err) {
          alert("Error parsing file structure. Verify if the file is a clean JSON backup.");
        }
      };
    }
  };

  // Print & Generate PDF Stream
  const triggerPdfPrint = () => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      alert("Popup blocked! Please allow popups for this tool to download the generated Resume PDF.");
      return;
    }

    // Compose custom styles for each template type
    let cssStyles = "";
    if (activeTemplate === 'modern') {
      cssStyles = `
        body { font-family: 'Inter', system-ui, sans-serif; color: #1f2937; margin: 0; padding: 25px; line-height: 1.5; background: #fff; }
        .header { border-bottom: 2px solid #4f46e5; padding-bottom: 15px; margin-bottom: 15px; }
        .name { font-size: 26px; font-weight: 800; color: #4f46e5; margin: 0 0 4px 0; }
        .title { font-size: 15px; font-weight: 600; color: #4b5563; margin: 4px 0; text-transform: uppercase; letter-spacing: 0.05em; }
        .contact { font-size: 11px; color: #4b5563; display: flex; flex-wrap: wrap; gap: 15px; margin-top: 8px; }
        .contact-item { display: flex; align-items: center; gap: 4px; }
        .grid { display: grid; grid-template-columns: 2fr 1fr; gap: 20px; margin-top: 15px; }
        .section-title { font-size: 12px; font-weight: 700; color: #4f46e5; text-transform: uppercase; border-bottom: 1px solid #e5e7eb; padding-bottom: 4px; margin: 15px 0 10px 0; letter-spacing: 0.05em; }
        .item-header { display: flex; justify-content: space-between; font-weight: 700; font-size: 12px; color: #111827; }
        .item-sub { display: flex; justify-content: space-between; font-size: 11px; color: #4b5563; margin-top: 2px; margin-bottom: 5px; font-weight: 500; }
        .item-desc { font-size: 11px; color: #374151; margin-bottom: 12px; text-align: justify; }
        .tag-container { display: flex; flex-wrap: wrap; gap: 5px; }
        .tag { background: #f3f4f6; color: #111827; font-size: 10px; font-weight: 600; padding: 3px 8px; border-radius: 4px; border: 1px solid #e5e7eb; }
        .summary { font-size: 11px; color: #374151; margin-bottom: 15px; text-align: justify; }
      `;
    } else if (activeTemplate === 'serif') {
      cssStyles = `
        body { font-family: 'Playfair Display', 'Georgia', serif; color: #111827; margin: 0; padding: 35px; line-height: 1.6; background: #fff; }
        .header { text-align: center; border-bottom: 1px solid #b45309; padding-bottom: 18px; margin-bottom: 20px; }
        .name { font-size: 28px; font-weight: 400; color: #b45309; margin: 0 0 5px 0; letter-spacing: 0.02em; }
        .title { font-size: 14px; font-style: italic; color: #4b5563; margin: 4px 0; }
        .contact { font-size: 11px; color: #4b5563; display: flex; justify-content: center; flex-wrap: wrap; gap: 18px; margin-top: 10px; }
        .grid { display: grid; grid-template-columns: 1fr; gap: 15px; margin-top: 15px; }
        .section-title { font-size: 13px; font-weight: 700; color: #b45309; text-transform: uppercase; border-bottom: 1px solid #f59e0b; padding-bottom: 3px; margin: 20px 0 12px 0; letter-spacing: 0.1em; text-align: center; }
        .item-header { display: flex; justify-content: space-between; font-weight: 700; font-size: 12px; }
        .item-sub { display: flex; justify-content: space-between; font-style: italic; font-size: 11px; color: #4b5563; margin-top: 1px; margin-bottom: 5px; }
        .item-desc { font-size: 11px; color: #1f2937; margin-bottom: 12px; text-align: justify; }
        .tag-container { display: flex; flex-wrap: wrap; gap: 6px; justify-content: center; }
        .tag { background: transparent; border: 1px solid #f59e0b; color: #b45309; font-size: 10px; padding: 2px 7px; border-radius: 2px; font-family: sans-serif; font-weight: 600; }
        .summary { font-size: 11px; font-style: italic; text-align: center; margin-bottom: 15px; color: #374151; max-width: 90%; margin-left: auto; margin-right: auto; }
      `;
    } else if (activeTemplate === 'tech') {
      cssStyles = `
        body { font-family: 'JetBrains Mono', 'Courier New', monospace; color: #000; margin: 0; padding: 20px; line-height: 1.4; background: #fff; }
        .header { border: 2px solid #000; padding: 15px; margin-bottom: 15px; }
        .name { font-size: 22px; font-weight: 700; color: #000; margin: 0 0 2px 0; }
        .title { font-size: 12px; font-weight: 750; color: #000; margin: 4px 0; text-transform: uppercase; }
        .contact { font-size: 10px; color: #000; display: flex; flex-wrap: wrap; gap: 12px; margin-top: 8px; }
        .grid { display: grid; grid-template-columns: 2fr 1fr; gap: 15px; margin-top: 15px; }
        .section-title { font-size: 11px; font-weight: 700; color: #fff; background: #000; text-transform: uppercase; padding: 3px 6px; margin: 15px 0 8px 0; letter-spacing: 0.05em; display: inline-block; }
        .item-header { display: flex; justify-content: space-between; font-weight: 750; font-size: 11px; }
        .item-sub { display: flex; justify-content: space-between; font-size: 10px; color: #000; margin-top: 1px; margin-bottom: 4px; font-weight: 600; }
        .item-desc { font-size: 10px; color: #333; margin-bottom: 10px; }
        .tag-container { display: flex; flex-wrap: wrap; gap: 4px; }
        .tag { border: 1px solid #000; background: #fff; color: #000; font-size: 9px; padding: 1px 5px; font-weight: bold; }
        .summary { font-size: 10px; color: #333; margin-bottom: 10px; border-bottom: 1px dashed #000; padding-bottom: 10px; }
      `;
    } else if (activeTemplate === 'executive') {
      cssStyles = `
        body { font-family: 'Inter', sans-serif; color: #1e293b; margin: 0; padding: 30px; line-height: 1.45; background: #fff; }
        .header { background: #0f172a; color: #fff; padding: 25px; margin: -30px -30px 20px -30px; }
        .name { font-size: 25px; font-weight: 800; color: #fff; margin: 0 0 2px 0; }
        .title { font-size: 13px; font-weight: 600; color: #94a3b8; margin: 4px 0; text-transform: uppercase; letter-spacing: 0.1em; }
        .contact { font-size: 10px; color: #cbd5e1; display: flex; flex-wrap: wrap; gap: 15px; margin-top: 10px; }
        .grid { display: grid; grid-template-columns: 1fr; gap: 15px; margin-top: 15px; }
        .section-title { font-size: 12px; font-weight: 800; color: #0f172a; text-transform: uppercase; border-bottom: 2px solid #0f172a; padding-bottom: 3px; margin: 18px 0 10px 0; letter-spacing: 0.05em; }
        .item-header { display: flex; justify-content: space-between; font-weight: 700; font-size: 11.5px; }
        .item-sub { display: flex; justify-content: space-between; font-size: 10.5px; color: #475569; margin-top: 1px; margin-bottom: 4px; }
        .item-desc { font-size: 11px; color: #334155; margin-bottom: 12px; text-align: justify; }
        .tag-container { display: flex; flex-wrap: wrap; gap: 5px; }
        .tag { background: #f8fafc; color: #0f172a; font-size: 10px; font-weight: 600; padding: 2px 6px; border: 1px solid #cbd5e1; }
        .summary { font-size: 11px; color: #334155; margin-bottom: 15px; text-align: justify; border-left: 3px solid #0f172a; padding-left: 10px; }
      `;
    } else { // creative
      cssStyles = `
        body { font-family: 'Inter', system-ui, sans-serif; color: #374151; margin: 0; padding: 25px; line-height: 1.5; background: #fff; }
        .header { display: flex; justify-content: space-between; align-items: center; border-bottom: 3px solid #f43f5e; padding-bottom: 12px; margin-bottom: 15px; }
        .name { font-size: 24px; font-weight: 850; color: #111827; margin: 0; }
        .title { font-size: 13px; font-weight: 700; color: #f43f5e; margin: 2px 0; text-transform: uppercase; }
        .contact { font-size: 10px; color: #6b7280; display: flex; flex-direction: column; gap: 3px; text-align: right; }
        .grid { display: grid; grid-template-columns: 2fr 1fr; gap: 20px; margin-top: 15px; }
        .section-title { font-size: 11px; font-weight: 800; color: #f43f5e; text-transform: uppercase; background: #ffe4e6; padding: 4px 10px; border-radius: 20px; display: inline-block; margin: 15px 0 10px 0; }
        .item-header { display: flex; justify-content: space-between; font-weight: 700; font-size: 11.5px; color: #111827; }
        .item-sub { display: flex; justify-content: space-between; font-size: 10.5px; color: #e11d48; margin-top: 1px; margin-bottom: 3px; font-weight: 600; }
        .item-desc { font-size: 11px; color: #4b5563; margin-bottom: 10px; text-align: justify; }
        .tag-container { display: flex; flex-wrap: wrap; gap: 5px; }
        .tag { background: #fff1f2; color: #be123c; font-size: 10px; font-weight: bold; padding: 2px 8px; border-radius: 9999px; }
        .summary { font-size: 11px; color: #4b5563; margin-bottom: 15px; background: #fafafa; padding: 12px; border-radius: 8px; border: 1px dashed #fda4af; }
      `;
    }

    const experienceHtml = data.experience.map(exp => `
      <div style="margin-bottom: 10px;">
        <div class="item-header">
          <span>${exp.role}</span>
          <span>${exp.startDate} - ${exp.endDate}</span>
        </div>
        <div class="item-sub">
          <span>${exp.company}</span>
        </div>
        <div class="item-desc">${exp.description}</div>
      </div>
    `).join('');

    const educationHtml = data.education.map(edu => `
      <div style="margin-bottom: 8px;">
        <div class="item-header">
          <span>${edu.degree}</span>
          <span>${edu.startDate} - ${edu.endDate}</span>
        </div>
        <div class="item-sub">
          <span>${edu.institution}</span>
          <span>GPA: ${edu.gpa}</span>
        </div>
      </div>
    `).join('');

    const projectsHtml = data.projects.map(proj => `
      <div style="margin-bottom: 10px;">
        <div class="item-header">
          <span>${proj.name}</span>
          <span><a href="${proj.link}" target="_blank" style="color: inherit; text-decoration: none;">${proj.link ? '🔗 Link' : ''}</a></span>
        </div>
        <div class="item-sub">
          <span style="font-size: 9.5px; font-weight: bold;">[${proj.techStack}]</span>
        </div>
        <div class="item-desc">${proj.description}</div>
      </div>
    `).join('');

    const skillsHtml = data.skills.map(s => `<span class="tag">${s}</span>`).join('');
    const languagesHtml = data.languages.map(l => `<span class="tag">${l}</span>`).join('');

    const documentContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>${data.fullName} - Resume</title>
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;700&family=Playfair+Display:ital,wght@0,400;0,750;1,400&display=swap" rel="stylesheet">
        <style>
          ${cssStyles}
          @media print {
            body { padding: 0 !important; margin: 0 !important; }
            button { display: none !important; }
          }
        </style>
      </head>
      <body>
        <div class="header">
          <div>
            <h1 class="name">${data.fullName}</h1>
            <h2 class="title">${data.title}</h2>
          </div>
          <div class="contact">
            ${data.email ? `<span class="contact-item">✉ ${data.email}</span>` : ''}
            ${data.phone ? `<span class="contact-item">☎ ${data.phone}</span>` : ''}
            ${data.location ? `<span class="contact-item">📍 ${data.location}</span>` : ''}
            ${data.website ? `<span class="contact-item">🔗 ${data.website}</span>` : ''}
          </div>
        </div>

        ${data.summary ? `
          <div class="section-title">Summary</div>
          <div class="summary">${data.summary}</div>
        ` : ''}

        <div class="grid">
          <div>
            ${data.experience.length > 0 ? `
              <div class="section-title">Professional Experience</div>
              ${experienceHtml}
            ` : ''}

            ${data.projects.length > 0 ? `
              <div class="section-title">Projects</div>
              ${projectsHtml}
            ` : ''}
          </div>

          <div>
            ${data.skills.length > 0 ? `
              <div class="section-title">Technical Skills</div>
              <div class="tag-container" style="margin-bottom: 12px;">${skillsHtml}</div>
            ` : ''}

            ${data.education.length > 0 ? `
              <div class="section-title">Education</div>
              ${educationHtml}
            ` : ''}

            ${data.languages.length > 0 ? `
              <div class="section-title">Languages</div>
              <div class="tag-container">${languagesHtml}</div>
            ` : ''}
          </div>
        </div>

        <script>
          window.onload = function() {
            setTimeout(function() {
              window.print();
            }, 600);
          }
        </script>
      </body>
      </html>
    `;

    printWindow.document.open();
    printWindow.document.write(documentContent);
    printWindow.document.close();
  };

  const activeTempInfo = TEMPLATES.find(t => t.id === activeTemplate) || TEMPLATES[0];

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4 overflow-hidden animate-fadeIn">
      <div className="bg-white rounded-2xl w-full max-w-[1300px] h-[92vh] flex flex-col shadow-2xl relative animate-slideUp">
        
        {/* Header bar controls */}
        <div className="border-b border-gray-100 px-6 py-4 flex items-center justify-between bg-slate-50 rounded-t-2xl shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="bg-gradient-to-tr from-amber-500 to-indigo-600 text-white p-2 rounded-lg shadow-sm">
              <Sparkles size={18} />
            </div>
            <div>
              <h2 className="text-base font-bold text-gray-900 flex items-center gap-2">
                Resume / CV Professional Builder
                <span className="bg-indigo-100 text-indigo-800 text-[10px] font-extrabold px-2 py-0.5 rounded-full uppercase">
                  10,000+ Design Limits
                </span>
              </h2>
              <p className="text-xs text-gray-500 font-medium font-sans">
                Manually fill details to build crisp responsive vector resumes. No watermarks!
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button 
              onClick={exportResumeJSON}
              title="Save backup file to your computer"
              className="px-3 py-1.5 rounded-lg border border-gray-200 hover:border-gray-300 bg-white text-xs font-semibold text-gray-750 flex items-center gap-1.5 hover:bg-slate-50 transition-all cursor-pointer"
            >
              <FileDown size={14} className="text-indigo-600" />
              Save Backup (JSON)
            </button>

            <button 
              onClick={() => fileInputRef.current?.click()}
              title="Load saved resume details from backup"
              className="px-3 py-1.5 rounded-lg border border-gray-200 hover:border-gray-300 bg-white text-xs font-semibold text-gray-750 flex items-center gap-1.5 hover:bg-slate-50 transition-all cursor-pointer"
            >
              <FileUp size={14} className="text-emerald-600" />
              Load Backup
            </button>
            <input 
              type="file" 
              ref={fileInputRef} 
              onChange={importResumeJSON} 
              accept=".json" 
              className="hidden" 
            />

            <button 
              onClick={handleReset}
              className="p-1.5 text-gray-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-transform cursor-pointer"
              title="Reset values with defaults"
            >
              <RotateCcw size={16} />
            </button>

            <div className="h-6 w-[1px] bg-gray-200 mx-1"></div>

            <button 
              onClick={onClose}
              className="p-1.5 hover:bg-rose-50 text-gray-400 hover:text-rose-600 rounded-lg transition-transform cursor-pointer"
            >
              <X size={20} />
            </button>
          </div>
        </div>

        {/* Templates Selector Carousel */}
        <div className="bg-slate-50/50 border-b border-gray-100 p-3 flex flex-wrap items-center gap-2.5 shrink-0 px-6">
          <span className="text-[11px] font-bold text-gray-400 uppercase tracking-wider flex items-center gap-1 shrink-0">
            <Layout size={12} /> Templates Layout:
          </span>
          <div className="flex items-center gap-2 overflow-x-auto py-1">
            {TEMPLATES.map((tpl) => (
              <button
                key={tpl.id}
                onClick={() => setActiveTemplate(tpl.id)}
                className={`px-3 py-1.5 rounded-xl border text-xs font-bold transition-all shrink-0 flex items-center gap-2 ${
                  activeTemplate === tpl.id
                    ? 'bg-indigo-600 border-indigo-600 text-white shadow-sm scale-102'
                    : 'bg-white border-gray-200 text-gray-700 hover:bg-gray-50'
                }`}
              >
                <span className={`w-2.5 h-2.5 rounded-full ${tpl.palette}`}></span>
                {tpl.name}
              </button>
            ))}
          </div>
          <span className="text-[10px] text-gray-450 italic ml-auto max-w-[320px] truncate hidden lg:inline-block">
            "{activeTempInfo.desc}"
          </span>
        </div>

        {/* Modal Main Content (Split Screen) */}
        <div className="flex-1 flex overflow-hidden min-h-0">
          
          {/* LEFT: Manual Editor Input Forms */}
          <div className="w-[45%] border-r border-gray-150 flex flex-col bg-slate-50/20">
            {/* Sections Tab Row */}
            <div className="p-3 bg-white border-b border-gray-100 flex items-center gap-1.5 overflow-x-auto shrink-0 scrollbar-none">
              {[
                { id: 'personal', name: 'Profile' },
                { id: 'experience', name: 'Experience' },
                { id: 'education', name: 'Education' },
                { id: 'skills', name: 'Skills & Languages' },
                { id: 'projects', name: 'Projects' }
              ].map(sec => (
                <button
                  key={sec.id}
                  onClick={() => setActiveSection(sec.id)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                    activeSection === sec.id
                      ? 'bg-gray-900 text-white'
                      : 'text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  {sec.name}
                </button>
              ))}
            </div>

            {/* Scrollable Form Content */}
            <div className="flex-1 overflow-y-auto p-5 space-y-4">
              
              {/* Profile Sec */}
              {activeSection === 'personal' && (
                <div className="space-y-4 animate-fadeIn">
                  <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest border-b pb-1">Personal Details</h3>
                  <div className="grid grid-cols-2 gap-3.5">
                    <div>
                      <label className="block text-[10px] font-bold text-gray-500 mb-1">Full Name</label>
                      <input 
                        type="text" 
                        value={data.fullName}
                        onChange={(e) => handleFieldChange('fullName', e.target.value)}
                        className="w-full text-xs p-2.5 bg-white border border-gray-200 rounded-lg outline-none focus:border-indigo-500 font-medium"
                        placeholder="John Doe"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-gray-500 mb-1">Professional Title</label>
                      <input 
                        type="text" 
                        value={data.title}
                        onChange={(e) => handleFieldChange('title', e.target.value)}
                        className="w-full text-xs p-2.5 bg-white border border-gray-200 rounded-lg outline-none focus:border-indigo-500 font-medium"
                        placeholder="Senior Architect"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-gray-500 mb-1">Email ID</label>
                      <input 
                        type="email" 
                        value={data.email}
                        onChange={(e) => handleFieldChange('email', e.target.value)}
                        className="w-full text-xs p-2.5 bg-white border border-gray-200 rounded-lg outline-none focus:border-indigo-500 font-medium font-mono"
                        placeholder="john.doe@email.com"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-gray-500 mb-1">Phone Number</label>
                      <input 
                        type="text" 
                        value={data.phone}
                        onChange={(e) => handleFieldChange('phone', e.target.value)}
                        className="w-full text-xs p-2.5 bg-white border border-gray-200 rounded-lg outline-none focus:border-indigo-500 font-medium"
                        placeholder="+1 (555) 012-3456"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-gray-500 mb-1">Location / Address</label>
                      <input 
                        type="text" 
                        value={data.location}
                        onChange={(e) => handleFieldChange('location', e.target.value)}
                        className="w-full text-xs p-2.5 bg-white border border-gray-200 rounded-lg outline-none focus:border-indigo-500 font-medium"
                        placeholder="New York, NY"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-gray-500 mb-1">Personal Portfolio / Link</label>
                      <input 
                        type="text" 
                        value={data.website}
                        onChange={(e) => handleFieldChange('website', e.target.value)}
                        className="w-full text-xs p-2.5 bg-white border border-gray-200 rounded-lg outline-none focus:border-indigo-500 font-medium font-mono"
                        placeholder="https://mywebsite.dev"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-gray-500 mb-1">Professional Summary / Bio</label>
                    <textarea 
                      rows={5}
                      value={data.summary}
                      onChange={(e) => handleFieldChange('summary', e.target.value)}
                      className="w-full text-xs p-2.5 bg-white border border-gray-200 rounded-lg outline-none focus:border-indigo-500 font-medium leading-relaxed resize-none"
                      placeholder="Write brief 3-4 lines summarising professional highlight milestones..."
                    />
                  </div>
                </div>
              )}

              {/* Experience Sec */}
              {activeSection === 'experience' && (
                <div className="space-y-4 animate-fadeIn">
                  <div className="flex justify-between items-center border-b pb-1">
                    <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest">Work History</h3>
                    <button 
                      onClick={addExperience}
                      className="text-[10px] bg-indigo-50 text-indigo-700 px-2 py-1 rounded-md font-bold flex items-center gap-1 border border-indigo-150 hover:bg-indigo-100 cursor-pointer"
                    >
                      <Plus size={12} /> Add Job
                    </button>
                  </div>

                  {data.experience.length === 0 ? (
                    <p className="text-xs text-gray-400 py-6 text-center italic">No work history listed. Click 'Add Job' to begin listing experience.</p>
                  ) : (
                    data.experience.map((item, index) => (
                      <div key={item.id} className="p-4 bg-white border border-gray-200 rounded-xl space-y-3 relative group">
                        <button 
                          onClick={() => removeExperience(item.id)}
                          className="absolute top-3 right-3 text-gray-450 hover:text-rose-600 hover:bg-rose-50 p-1.5 rounded transition-colors cursor-pointer"
                        >
                          <Trash2 size={13} />
                        </button>

                        <div className="text-[10.5px] font-extrabold text-indigo-700 uppercase tracking-wider mb-2">
                          Job Position #{index + 1}
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <label className="block text-[9px] font-bold text-gray-500 mb-0.5">Company / Employer</label>
                            <input 
                              type="text"
                              value={item.company}
                              onChange={(e) => handleExperienceChange(item.id, 'company', e.target.value)}
                              className="w-full text-xs p-2 bg-slate-50 border border-gray-150 rounded outline-none focus:bg-white font-medium"
                            />
                          </div>
                          <div>
                            <label className="block text-[9px] font-bold text-gray-500 mb-0.5">Role / Position</label>
                            <input 
                              type="text"
                              value={item.role}
                              onChange={(e) => handleExperienceChange(item.id, 'role', e.target.value)}
                              className="w-full text-xs p-2 bg-slate-50 border border-gray-150 rounded outline-none focus:bg-white font-medium"
                            />
                          </div>
                          <div>
                            <label className="block text-[9px] font-bold text-gray-500 mb-0.5">Start Date</label>
                            <input 
                              type="text"
                              placeholder="e.g. 2021-03"
                              value={item.startDate}
                              onChange={(e) => handleExperienceChange(item.id, 'startDate', e.target.value)}
                              className="w-full text-xs p-2 bg-slate-50 border border-gray-150 rounded outline-none focus:bg-white font-medium"
                            />
                          </div>
                          <div>
                            <label className="block text-[9px] font-bold text-gray-500 mb-0.5">End Date</label>
                            <input 
                              type="text"
                              placeholder="e.g. Present"
                              value={item.endDate}
                              onChange={(e) => handleExperienceChange(item.id, 'endDate', e.target.value)}
                              className="w-full text-xs p-2 bg-slate-50 border border-gray-150 rounded outline-none focus:bg-white font-medium"
                            />
                          </div>
                        </div>

                        <div>
                          <label className="block text-[9px] font-bold text-gray-500 mb-0.5">Job Description</label>
                          <textarea 
                            rows={3}
                            value={item.description}
                            onChange={(e) => handleExperienceChange(item.id, 'description', e.target.value)}
                            className="w-full text-xs p-2 bg-slate-50 border border-gray-150 rounded outline-none focus:bg-white font-medium resize-none leading-relaxed"
                          />
                        </div>
                      </div>
                    ))
                  )}
                </div>
              )}

              {/* Education Sec */}
              {activeSection === 'education' && (
                <div className="space-y-4 animate-fadeIn">
                  <div className="flex justify-between items-center border-b pb-1">
                    <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest">Education</h3>
                    <button 
                      onClick={addEducation}
                      className="text-[10px] bg-indigo-50 text-indigo-700 px-2 py-1 rounded-md font-bold flex items-center gap-1 border border-indigo-150 hover:bg-indigo-100 cursor-pointer"
                    >
                      <Plus size={12} /> Add Education
                    </button>
                  </div>

                  {data.education.length === 0 ? (
                    <p className="text-xs text-gray-400 py-6 text-center italic">No education listed. Click 'Add Education' to begin listing institution details.</p>
                  ) : (
                    data.education.map((item, index) => (
                      <div key={item.id} className="p-4 bg-white border border-gray-200 rounded-xl space-y-3 relative group">
                        <button 
                          onClick={() => removeEducation(item.id)}
                          className="absolute top-3 right-3 text-gray-450 hover:text-rose-600 hover:bg-rose-50 p-1.5 rounded transition-colors cursor-pointer"
                        >
                          <Trash2 size={13} />
                        </button>

                        <div className="text-[10.5px] font-extrabold text-indigo-700 uppercase tracking-wider mb-2">
                          Education #{index + 1}
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <div className="col-span-2">
                            <label className="block text-[9px] font-bold text-gray-500 mb-0.5">Institution / University</label>
                            <input 
                              type="text"
                              value={item.institution}
                              onChange={(e) => handleEducationChange(item.id, 'institution', e.target.value)}
                              className="w-full text-xs p-2 bg-slate-50 border border-gray-150 rounded outline-none focus:bg-white font-medium"
                            />
                          </div>
                          <div>
                            <label className="block text-[9px] font-bold text-gray-500 mb-0.5">Degree / Course</label>
                            <input 
                              type="text"
                              value={item.degree}
                              onChange={(e) => handleEducationChange(item.id, 'degree', e.target.value)}
                              className="w-full text-xs p-2 bg-slate-50 border border-gray-150 rounded outline-none focus:bg-white font-medium"
                            />
                          </div>
                          <div>
                            <label className="block text-[9px] font-bold text-gray-500 mb-0.5">GPA or Grade</label>
                            <input 
                              type="text"
                              placeholder="e.g. 3.8/4.0"
                              value={item.gpa}
                              onChange={(e) => handleEducationChange(item.id, 'gpa', e.target.value)}
                              className="w-full text-xs p-2 bg-slate-50 border border-gray-150 rounded outline-none focus:bg-white font-medium"
                            />
                          </div>
                          <div>
                            <label className="block text-[9px] font-bold text-gray-500 mb-0.5">Start Date / Year</label>
                            <input 
                              type="text"
                              placeholder="e.g. 2017"
                              value={item.startDate}
                              onChange={(e) => handleEducationChange(item.id, 'startDate', e.target.value)}
                              className="w-full text-xs p-2 bg-slate-50 border border-gray-150 rounded outline-none focus:bg-white font-medium"
                            />
                          </div>
                          <div>
                            <label className="block text-[9px] font-bold text-gray-500 mb-0.5">End Date / Year</label>
                            <input 
                              type="text"
                              placeholder="e.g. 2021"
                              value={item.endDate}
                              onChange={(e) => handleEducationChange(item.id, 'endDate', e.target.value)}
                              className="w-full text-xs p-2 bg-slate-50 border border-gray-150 rounded outline-none focus:bg-white font-medium"
                            />
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              )}

              {/* Skills & Lang Sec */}
              {activeSection === 'skills' && (
                <div className="space-y-5 animate-fadeIn">
                  
                  {/* Skills Section */}
                  <div className="space-y-3">
                    <div className="flex justify-between items-center border-b pb-1">
                      <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest">Technical Skills</h3>
                      <button 
                        onClick={() => addArrayValue('skills')}
                        className="text-[10px] bg-indigo-50 text-indigo-700 px-2.5 py-1 rounded-md font-bold flex items-center gap-1 border border-indigo-150 hover:bg-indigo-100 cursor-pointer"
                      >
                        <Plus size={11} /> Add Skill
                      </button>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      {data.skills.map((skill, index) => (
                        <div key={index} className="flex gap-1 items-center">
                          <input 
                            type="text"
                            value={skill}
                            onChange={(e) => handleArrayChange('skills', index, e.target.value)}
                            placeholder="e.g. React"
                            className="flex-1 text-xs p-2 border border-gray-200 rounded outline-none focus:border-indigo-500 font-medium"
                          />
                          <button 
                            onClick={() => removeArrayValue('skills', index)}
                            className="p-2 text-gray-400 hover:text-rose-600 hover:bg-slate-100 rounded cursor-pointer"
                          >
                            <Trash2 size={13} />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Languages Section */}
                  <div className="space-y-3">
                    <div className="flex justify-between items-center border-b pb-1">
                      <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest">Languages Known</h3>
                      <button 
                        onClick={() => addArrayValue('languages')}
                        className="text-[10px] bg-indigo-50 text-indigo-700 px-2.5 py-1 rounded-md font-bold flex items-center gap-1 border border-indigo-150 hover:bg-indigo-100 cursor-pointer"
                      >
                        <Plus size={11} /> Add Language
                      </button>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      {data.languages.map((lang, index) => (
                        <div key={index} className="flex gap-1 items-center">
                          <input 
                            type="text"
                            value={lang}
                            onChange={(e) => handleArrayChange('languages', index, e.target.value)}
                            placeholder="e.g. English (Fluent)"
                            className="flex-1 text-xs p-2 border border-gray-200 rounded outline-none focus:border-indigo-500 font-medium"
                          />
                          <button 
                            onClick={() => removeArrayValue('languages', index)}
                            className="p-2 text-gray-400 hover:text-rose-600 hover:bg-slate-100 rounded cursor-pointer"
                          >
                            <Trash2 size={13} />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>

                </div>
              )}

              {/* Projects Section */}
              {activeSection === 'projects' && (
                <div className="space-y-4 animate-fadeIn">
                  <div className="flex justify-between items-center border-b pb-1">
                    <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest">Projects</h3>
                    <button 
                      onClick={addProject}
                      className="text-[10px] bg-indigo-50 text-indigo-700 px-2 py-1 rounded-md font-bold flex items-center gap-1 border border-indigo-150 hover:bg-indigo-100 cursor-pointer"
                    >
                      <Plus size={12} /> Add Project
                    </button>
                  </div>

                  {data.projects.length === 0 ? (
                    <p className="text-xs text-gray-400 py-6 text-center italic">No projects listed. Click 'Add Project' to begin listing items.</p>
                  ) : (
                    data.projects.map((item, index) => (
                      <div key={item.id} className="p-4 bg-white border border-gray-200 rounded-xl space-y-3 relative group">
                        <button 
                          onClick={() => removeProject(item.id)}
                          className="absolute top-3 right-3 text-gray-450 hover:text-rose-600 hover:bg-rose-50 p-1.5 rounded transition-colors cursor-pointer"
                        >
                          <Trash2 size={13} />
                        </button>

                        <div className="text-[10.5px] font-extrabold text-indigo-700 uppercase tracking-wider mb-2">
                          Project #{index + 1}
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <label className="block text-[9px] font-bold text-gray-500 mb-0.5">Project Name</label>
                            <input 
                              type="text"
                              value={item.name}
                              onChange={(e) => handleProjectChange(item.id, 'name', e.target.value)}
                              className="w-full text-xs p-2 bg-slate-50 border border-gray-150 rounded outline-none focus:bg-white font-medium"
                            />
                          </div>
                          <div>
                            <label className="block text-[9px] font-bold text-gray-500 mb-0.5">Tech Stack Used</label>
                            <input 
                              type="text"
                              placeholder="e.g. React, WebGL"
                              value={item.techStack}
                              onChange={(e) => handleProjectChange(item.id, 'techStack', e.target.value)}
                              className="w-full text-xs p-2 bg-slate-50 border border-gray-150 rounded outline-none focus:bg-white font-medium"
                            />
                          </div>
                          <div className="col-span-2">
                            <label className="block text-[9px] font-bold text-gray-500 mb-0.5">Project Link / URL</label>
                            <input 
                              type="text"
                              placeholder="e.g. https://github.org/..."
                              value={item.link}
                              onChange={(e) => handleProjectChange(item.id, 'link', e.target.value)}
                              className="w-full text-xs p-2 bg-slate-50 border border-gray-150 rounded outline-none focus:bg-white font-medium font-mono"
                            />
                          </div>
                        </div>

                        <div>
                          <label className="block text-[9px] font-bold text-gray-500 mb-0.5">Project Description</label>
                          <textarea 
                            rows={3}
                            value={item.description}
                            onChange={(e) => handleProjectChange(item.id, 'description', e.target.value)}
                            className="w-full text-xs p-2 bg-slate-50 border border-gray-150 rounded outline-none focus:bg-white font-medium resize-none leading-relaxed"
                          />
                        </div>
                      </div>
                    ))
                  )}
                </div>
              )}

            </div>
          </div>

          {/* RIGHT: Real-Time Interactive Live Preview */}
          <div className="flex-1 flex flex-col bg-slate-100 overflow-hidden relative">
            {/* Context Actions top bar */}
            <div className="bg-slate-200/65 px-6 py-2.5 flex items-center justify-between shrink-0">
              <span className="text-[11px] font-bold text-slate-500 uppercase tracking-widest flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse"></span>
                Interactive Vector Preview
              </span>
              
              <button 
                onClick={triggerPdfPrint}
                className="bg-indigo-600 text-white text-xs font-bold px-4 py-2 rounded-xl flex items-center gap-2 hover:bg-indigo-700 transition-all shadow-sm cursor-pointer"
              >
                <Download size={14} />
                Download PDF / Print
              </button>
            </div>

            {/* Simulated Clean Sheet */}
            <div className="flex-1 overflow-y-auto p-8 flex justify-center">
              <div 
                id="printable-resume-paper" 
                className={`w-[100%] max-w-[800px] min-h-[1050px] bg-white border border-gray-200 rounded-lg shadow-sm p-8 text-left h-fit transition-all duration-300 ${
                  activeTemplate === 'serif' ? 'font-serif' : activeTemplate === 'tech' ? 'font-mono' : 'font-sans'
                }`}
              >
                
                {/* Modern Slate Template */}
                {activeTemplate === 'modern' && (
                  <div className="space-y-5 animate-fadeIn">
                    <div className="border-b-2 border-indigo-600 pb-4">
                      <h1 className="text-3xl font-extrabold text-indigo-700 tracking-tight">{data.fullName || "Untitled Profile"}</h1>
                      <h2 className="text-sm font-bold text-gray-500 uppercase tracking-widest mt-1">{data.title || "Position Title"}</h2>
                      
                      <div className="flex flex-wrap gap-x-4 gap-y-1 text-slate-500 font-medium text-[11px] mt-3 font-sans">
                        {data.email && <span className="flex items-center gap-1"><Mail size={11} className="text-indigo-600" /> {data.email}</span>}
                        {data.phone && <span className="flex items-center gap-1"><Phone size={11} className="text-indigo-600" /> {data.phone}</span>}
                        {data.location && <span className="flex items-center gap-1"><MapPin size={11} className="text-indigo-600" /> {data.location}</span>}
                        {data.website && <span className="flex items-center gap-1"><LinkIcon size={11} className="text-indigo-600" /> <span className="truncate max-w-[150px]">{data.website}</span></span>}
                      </div>
                    </div>

                    {data.summary && (
                      <div className="space-y-1.5">
                        <h4 className="text-[11px] font-bold text-indigo-600 uppercase tracking-wider">Professional Profile</h4>
                        <p className="text-[11.5px] text-gray-650 leading-relaxed text-justify">{data.summary}</p>
                      </div>
                    )}

                    <div className="grid grid-cols-3 gap-6 pt-2 text-[11px]">
                      
                      {/* Column Left (2/3) */}
                      <div className="col-span-2 space-y-5">
                        {/* Experiences */}
                        {data.experience.length > 0 && (
                          <div className="space-y-4">
                            <h4 className="text-[11px] font-bold text-indigo-600 uppercase tracking-wider border-b border-gray-100 pb-1">Work Experience</h4>
                            {data.experience.map(exp => (
                              <div key={exp.id} className="space-y-1">
                                <div className="flex justify-between font-bold text-gray-900 text-[11.5px]">
                                  <span>{exp.role || "Role"}</span>
                                  <span className="text-[10px] text-gray-500">{exp.startDate} - {exp.endDate}</span>
                                </div>
                                <div className="text-[10.5px] text-indigo-600 font-bold">{exp.company || "Company"}</div>
                                <p className="text-[11px] text-gray-600 leading-relaxed text-justify whitespace-pre-line">{exp.description}</p>
                              </div>
                            ))}
                          </div>
                        )}

                        {/* Projects */}
                        {data.projects.length > 0 && (
                          <div className="space-y-4">
                            <h4 className="text-[11px] font-bold text-indigo-600 uppercase tracking-wider border-b border-gray-100 pb-1">Featured Projects</h4>
                            {data.projects.map(proj => (
                              <div key={proj.id} className="space-y-1">
                                <div className="flex justify-between font-bold text-gray-900 text-[11.5px]">
                                  <span>{proj.name || "Project Name"}</span>
                                  {proj.link && <span className="text-[9.5px] text-indigo-600 font-medium font-mono">{proj.link}</span>}
                                </div>
                                <div className="text-[9.5px] font-bold text-gray-400 font-sans tracking-wide uppercase">Stack: {proj.techStack}</div>
                                <p className="text-[11px] text-gray-600 leading-relaxed">{proj.description}</p>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>

                      {/* Column Right (1/3) */}
                      <div className="space-y-5">
                        {/* Skills */}
                        {data.skills.length > 0 && (
                          <div className="space-y-2">
                            <h4 className="text-[11px] font-bold text-indigo-600 uppercase tracking-wider border-b border-gray-100 pb-1">Skills</h4>
                            <div className="flex flex-wrap gap-1.5">
                              {data.skills.map((s, idx) => s && (
                                <span key={idx} className="bg-slate-100 border border-slate-200 font-bold text-gray-800 text-[9.5px] px-2 py-0.5 rounded">
                                  {s}
                                </span>
                              ))}
                            </div>
                          </div>
                        )}

                        {/* Education */}
                        {data.education.length > 0 && (
                          <div className="space-y-3">
                            <h4 className="text-[11px] font-bold text-indigo-600 uppercase tracking-wider border-b border-gray-100 pb-1">Education</h4>
                            {data.education.map(edu => (
                              <div key={edu.id} className="space-y-0.5">
                                <div className="font-bold text-gray-800 leading-tight">{edu.degree || "Degree"}</div>
                                <div className="text-gray-500">{edu.institution}</div>
                                <div className="text-[10px] text-slate-450 font-bold">{edu.startDate} - {edu.endDate} {edu.gpa && `• GPA: ${edu.gpa}`}</div>
                              </div>
                            ))}
                          </div>
                        )}

                        {/* Languages */}
                        {data.languages.length > 0 && (
                          <div className="space-y-2">
                            <h4 className="text-[11px] font-bold text-indigo-600 uppercase tracking-wider border-b border-gray-100 pb-1">Languages</h4>
                            <div className="flex flex-wrap gap-1.5">
                              {data.languages.map((l, idx) => l && (
                                <span key={idx} className="bg-indigo-50 text-indigo-800 font-bold text-[9.5px] px-2 py-0.5 rounded">
                                  {l}
                                </span>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>

                    </div>
                  </div>
                )}

                {/* Elegant Serif Template */}
                {activeTemplate === 'serif' && (
                  <div className="space-y-5 text-center font-serif animate-fadeIn">
                    <div className="border-b border-amber-800 pb-4">
                      <h1 className="text-3xl text-amber-900 tracking-wide font-normal">{data.fullName || "Your Full Name"}</h1>
                      <h2 className="text-xs font-serif italic text-gray-650 mt-1">{data.title || "Position Title"}</h2>
                      <div className="flex flex-wrap justify-center gap-x-4 gap-y-0.5 text-gray-650 font-serif text-[11px] mt-2 pb-1.5">
                        {data.email && <span>{data.email}</span>}
                        {data.phone && <span>• {data.phone}</span>}
                        {data.location && <span>• {data.location}</span>}
                        {data.website && <span>• {data.website}</span>}
                      </div>
                    </div>

                    {data.summary && (
                      <div className="text-center italic text-gray-700 leading-relaxed text-[12.5px] max-w-[90%] mx-auto pb-2 border-b border-amber-100">
                        "{data.summary}"
                      </div>
                    )}

                    <div className="text-left space-y-5">
                      
                      {/* Work Exp */}
                      {data.experience.length > 0 && (
                        <div className="space-y-3">
                          <h3 className="text-xs font-bold text-amber-800 uppercase tracking-widest text-center border-b border-amber-300 pb-1">Professional Experience</h3>
                          {data.experience.map(exp => (
                            <div key={exp.id} className="space-y-0.5">
                              <div className="flex justify-between font-bold text-slate-900 text-[12px]">
                                <span>{exp.role || "Role"} - <span className="font-normal italic text-slate-500">{exp.company}</span></span>
                                <span className="text-[10px] text-slate-450 font-normal">{exp.startDate} - {exp.endDate}</span>
                              </div>
                              <p className="text-[11.5px] text-gray-750 font-serif leading-relaxed text-justify">{exp.description}</p>
                            </div>
                          ))}
                        </div>
                      )}

                      {/* Projects */}
                      {data.projects.length > 0 && (
                        <div className="space-y-3">
                          <h3 className="text-xs font-bold text-amber-800 uppercase tracking-widest text-center border-b border-amber-300 pb-1">Independent Works & Projects</h3>
                          {data.projects.map(proj => (
                            <div key={proj.id} className="space-y-0.5">
                              <div className="flex justify-between font-bold text-slate-900 text-[12px]">
                                <span>{proj.name || "Project Name"} <span className="font-normal text-[10px] font-sans border px-1 ml-1 text-slate-450">Tags: {proj.techStack}</span></span>
                                {proj.link && <span className="text-[10px] font-normal text-amber-800 italic underline">{proj.link}</span>}
                              </div>
                              <p className="text-[11.5px] text-gray-750 font-serif leading-relaxed text-justify">{proj.description}</p>
                            </div>
                          ))}
                        </div>
                      )}

                      {/* Skills & School */}
                      <div className="grid grid-cols-2 gap-6 pt-2">
                        {/* Education */}
                        {data.education.length > 0 && (
                          <div className="space-y-2">
                            <h3 className="text-xs font-bold text-amber-800 uppercase tracking-widest border-b border-amber-300 pb-1">Education</h3>
                            {data.education.map(edu => (
                              <div key={edu.id} className="space-y-0.5">
                                <div className="font-bold text-[11.5px] text-slate-800">{edu.degree}</div>
                                <div className="text-[11px] text-gray-650 italic">{edu.institution} {edu.gpa && `• GPA: ${edu.gpa}`}</div>
                                <div className="text-[9.5px] text-gray-450 font-sans uppercase font-bold">{edu.startDate} - {edu.endDate}</div>
                              </div>
                            ))}
                          </div>
                        )}

                        {/* Skills */}
                        <div className="space-y-3">
                          <h3 className="text-xs font-bold text-amber-800 uppercase tracking-widest border-b border-amber-300 pb-1">Aptitudes & Skills</h3>
                          <div className="flex flex-wrap gap-1">
                            {data.skills.map((s, idx) => s && (
                              <span key={idx} className="border border-amber-200 text-amber-800 text-[9.5px] font-sans font-bold px-2 py-0.5 rounded-sm">
                                {s}
                              </span>
                            ))}
                          </div>
                        </div>
                      </div>

                    </div>
                  </div>
                )}

                {/* Minimal Tech Template */}
                {activeTemplate === 'tech' && (
                  <div className="space-y-5 font-mono text-[11px] text-black animate-fadeIn">
                    <div className="border border-black p-4 bg-slate-50">
                      <h1 className="text-2xl font-bold tracking-tight uppercase">&gt; {data.fullName || "Alexander"}</h1>
                      <h2 className="text-xs font-extrabold text-slate-700 uppercase">[CMD] {data.title || "SysAdmin"}</h2>
                      <div className="grid grid-cols-2 gap-1 text-[10px] mt-3">
                        {data.email && <span>EMAIL: {data.email}</span>}
                        {data.phone && <span>PHONE: {data.phone}</span>}
                        {data.location && <span>LOC: {data.location}</span>}
                        {data.website && <span>LINK: {data.website}</span>}
                      </div>
                    </div>

                    {data.summary && (
                      <p className="text-[11px] leading-relaxed border-b border-dashed border-black pb-3 text-justify">
                        {data.summary}
                      </p>
                    )}

                    {/* Left & Right Grid splits */}
                    <div className="grid grid-cols-3 gap-6 pt-1">
                      <div className="col-span-2 space-y-4">
                        {data.experience.length > 0 && (
                          <div className="space-y-3">
                            <span className="bg-black text-white px-2 py-0.5 font-bold uppercase text-[10px]">#01 WORK_LOGS</span>
                            {data.experience.map(exp => (
                              <div key={exp.id} className="space-y-1">
                                <div className="flex justify-between font-bold uppercase text-black text-[11.5px]">
                                  <span>{exp.role} @ {exp.company}</span>
                                  <span>[{exp.startDate} :: {exp.endDate}]</span>
                                </div>
                                <p className="text-[10.5px] text-gray-800 leading-normal">{exp.description}</p>
                              </div>
                            ))}
                          </div>
                        )}

                        {data.projects.length > 0 && (
                          <div className="space-y-3 font-mono">
                            <span className="bg-black text-white px-2 py-0.5 font-bold uppercase text-[10px]">#02 GITHUB_REPOS</span>
                            {data.projects.map(proj => (
                              <div key={proj.id} className="space-y-1">
                                <div className="flex justify-between font-bold text-black text-[11.5px]">
                                  <span>{proj.name}</span>
                                  <span>Url: {proj.link ? 'Active' : 'N/A'}</span>
                                </div>
                                <p className="text-[10px] text-gray-500 font-extrabold uppercase">MOD_TAGS: {proj.techStack}</p>
                                <p className="text-[10.5px] text-gray-800 leading-normal">{proj.description}</p>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>

                      <div className="space-y-4">
                        {data.skills.length > 0 && (
                          <div className="space-y-2">
                            <span className="bg-black text-white px-2 py-0.5 font-bold uppercase text-[10px]">#03 TECH_STACK</span>
                            <div className="flex flex-wrap gap-1 pt-1">
                              {data.skills.map((s, idx) => s && (
                                <span key={idx} className="border border-black bg-white px-1.5 py-0.5 text-[9.5px]">
                                  [{s}]
                                </span>
                              ))}
                            </div>
                          </div>
                        )}

                        {data.education.length > 0 && (
                          <div className="space-y-2">
                            <span className="bg-black text-white px-2 py-0.5 font-bold uppercase text-[10px]">#04 DEGREES</span>
                            {data.education.map(edu => (
                              <div key={edu.id} className="space-y-0.5">
                                <div className="font-bold">{edu.degree}</div>
                                <div className="text-gray-600">{edu.institution}</div>
                                <div className="text-[9.5px] text-slate-500 font-bold">{edu.startDate} - {edu.endDate} [GPA: {edu.gpa}]</div>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                )}

                {/* Executive Classic Template */}
                {activeTemplate === 'executive' && (
                  <div className="space-y-5 text-left font-sans animate-fadeIn text-[11px]">
                    <div className="bg-slate-900 text-white rounded p-6 -mx-8 -mt-8 mb-4">
                      <h1 className="text-3xl font-extrabold tracking-tight uppercase">{data.fullName || "Your Full Name"}</h1>
                      <h2 className="text-xs font-bold text-slate-300 uppercase tracking-widest mt-1">{data.title || "Professional Profile"}</h2>
                      <div className="flex flex-wrap gap-x-5 gap-y-1.5 text-slate-350 text-[10px] mt-4 font-sans border-t border-slate-700 pt-3">
                        {data.email && <span>EMAIL: {data.email}</span>}
                        {data.phone && <span>PHONE: {data.phone}</span>}
                        {data.location && <span>LOCATION: {data.location}</span>}
                        {data.website && <span>LINK: {data.website}</span>}
                      </div>
                    </div>

                    {data.summary && (
                      <div className="border-l-4 border-slate-900 pl-4 py-1 italic font-sans text-gray-750 text-[12px] leading-relaxed text-justify">
                        {data.summary}
                      </div>
                    )}

                    {/* Standard traditional details rows */}
                    {data.experience.length > 0 && (
                      <div className="space-y-3">
                        <h3 className="text-xs font-bold text-slate-900 border-b-2 border-slate-900 uppercase tracking-wider pb-0.5">Work Experience</h3>
                        {data.experience.map(exp => (
                          <div key={exp.id} className="space-y-1">
                            <div className="flex justify-between font-bold text-gray-950 text-[11.5px]">
                              <span>{exp.role} | {exp.company}</span>
                              <span className="text-[10px] text-slate-500">{exp.startDate} - {exp.endDate}</span>
                            </div>
                            <p className="text-[11px] text-gray-700 text-justify whitespace-pre-line">{exp.description}</p>
                          </div>
                        ))}
                      </div>
                    )}

                    {data.projects.length > 0 && (
                      <div className="space-y-3">
                        <h3 className="text-xs font-bold text-slate-900 border-b-2 border-slate-900 uppercase tracking-wider pb-0.5">Projects</h3>
                        {data.projects.map(proj => (
                          <div key={proj.id} className="space-y-1">
                            <div className="flex justify-between font-bold text-gray-950 text-[11.5px]">
                              <span>{proj.name} | <span className="font-normal font-mono text-[10px] text-slate-500">{proj.techStack}</span></span>
                              {proj.link && <span className="text-[10px] font-normal text-slate-500 underline">{proj.link}</span>}
                            </div>
                            <p className="text-[11px] text-gray-700 text-justify">{proj.description}</p>
                          </div>
                        ))}
                      </div>
                    )}

                    <div className="grid grid-cols-2 gap-6 pt-1">
                      {/* Left: Skills */}
                      <div className="space-y-2">
                        <h3 className="text-xs font-bold text-slate-900 border-b-2 border-slate-900 uppercase tracking-wider pb-0.5">Core Competenices</h3>
                        <div className="flex flex-wrap gap-1 pt-1">
                          {data.skills.map((s, idx) => s && (
                            <span key={idx} className="bg-slate-100 border text-slate-900 font-bold font-sans text-[9.5px] px-2 py-0.5 rounded-sm">
                              {s}
                            </span>
                          ))}
                        </div>
                      </div>

                      {/* Right: Education */}
                      {data.education.length > 0 && (
                        <div className="space-y-2">
                          <h3 className="text-xs font-bold text-slate-900 border-b-2 border-slate-900 uppercase tracking-wider pb-0.5">Academics</h3>
                          {data.education.map(edu => (
                            <div key={edu.id} className="space-y-0.5">
                              <div className="font-bold text-[11px] text-gray-900">{edu.degree}</div>
                              <div className="text-gray-600 leading-tight">{edu.institution} {edu.gpa && `• GPA: ${edu.gpa}`}</div>
                              <div className="text-[9.5px] text-slate-400 font-bold uppercase">{edu.startDate} - {edu.endDate}</div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* Creative Pastel Template */}
                {activeTemplate === 'creative' && (
                  <div className="space-y-5 text-left font-sans animate-fadeIn text-[11px]">
                    <div className="flex justify-between items-center border-b-4 border-rose-500 pb-3">
                      <div>
                        <h1 className="text-2xl font-black text-rose-600 tracking-tight">{data.fullName || "Creative Maker"}</h1>
                        <h2 className="text-xs font-bold text-gray-400 uppercase tracking-widest mt-0.5">{data.title || "Graphic Crafts"}</h2>
                      </div>
                      <div className="text-right text-[10px] text-slate-500 space-y-0.5 font-medium">
                        {data.email && <div>✉ {data.email}</div>}
                        {data.phone && <div>☎ {data.phone}</div>}
                        {data.location && <div>📍 {data.location}</div>}
                        {data.website && <div>🔗 {data.website}</div>}
                      </div>
                    </div>

                    {data.summary && (
                      <div className="bg-rose-50/50 border border-rose-200/50 p-4 rounded-xl text-[11.5px] text-gray-700 leading-relaxed text-justify">
                        {data.summary}
                      </div>
                    )}

                    <div className="grid grid-cols-3 gap-6 pt-1">
                      
                      {/* Left: main */}
                      <div className="col-span-2 space-y-5">
                        {data.experience.length > 0 && (
                          <div className="space-y-3">
                            <span className="bg-rose-100 text-rose-700 font-extrabold text-[10px] px-3 py-1 rounded-full uppercase tracking-wider">
                              Experiences
                            </span>
                            {data.experience.map(exp => (
                              <div key={exp.id} className="space-y-1 pt-1.5 border-l border-rose-100 pl-3">
                                <div className="flex justify-between font-bold text-gray-900 text-[11.5px]">
                                  <span>{exp.role} <span className="font-normal text-rose-500">• {exp.company}</span></span>
                                  <span className="text-[10px] text-gray-400 font-normal">{exp.startDate} - {exp.endDate}</span>
                                </div>
                                <p className="text-[11px] text-gray-650 text-justify">{exp.description}</p>
                              </div>
                            ))}
                          </div>
                        )}

                        {data.projects.length > 0 && (
                          <div className="space-y-3">
                            <span className="bg-rose-100 text-rose-700 font-extrabold text-[10px] px-3 py-1 rounded-full uppercase tracking-wider">
                              Creations
                            </span>
                            {data.projects.map(proj => (
                              <div key={proj.id} className="space-y-1 pt-1.5 border-l border-rose-100 pl-3">
                                <div className="flex justify-between font-bold text-gray-900 text-[11.5px]">
                                  <span>{proj.name}</span>
                                  {proj.link && <span className="text-[10px] font-normal text-rose-500 font-mono select-all truncate max-w-[130px]">{proj.link}</span>}
                                </div>
                                <div className="text-[9.5px] font-bold text-gray-450 uppercase">TECH: {proj.techStack}</div>
                                <p className="text-[11px] text-gray-650">{proj.description}</p>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>

                      {/* Right side options */}
                      <div className="space-y-5">
                        {data.skills.length > 0 && (
                          <div className="space-y-2">
                            <h3 className="text-xs font-bold text-rose-600 border-b border-rose-100 pb-0.5">Craft Skills</h3>
                            <div className="flex flex-wrap gap-1.5 pt-1">
                              {data.skills.map((s, idx) => s && (
                                <span key={idx} className="bg-rose-50 text-rose-700 font-bold text-[9.5px] px-2.5 py-0.5 rounded-full">
                                  {s}
                                </span>
                              ))}
                            </div>
                          </div>
                        )}

                        {data.education.length > 0 && (
                          <div className="space-y-2">
                            <h3 className="text-xs font-bold text-rose-600 border-b border-rose-100 pb-0.5 font-sans">Scholastic</h3>
                            {data.education.map(edu => (
                              <div key={edu.id} className="space-y-0.5 text-[10.5px]">
                                <div className="font-extrabold text-gray-800 tracking-tight leading-tight">{edu.degree}</div>
                                <div className="text-gray-500 leading-tight">{edu.institution} [GPA: {edu.gpa}]</div>
                                <div className="text-[9px] text-rose-500 uppercase font-bold">{edu.startDate} - {edu.endDate}</div>
                              </div>
                            ))}
                          </div>
                        )}

                        {data.languages.length > 0 && (
                          <div className="space-y-2">
                            <h3 className="text-xs font-bold text-rose-600 border-b border-rose-100 pb-0.5">Tongues</h3>
                            <div className="flex flex-wrap gap-1 pt-1">
                              {data.languages.map((l, idx) => l && (
                                <span key={idx} className="bg-slate-100 font-bold text-slate-800 text-[9.5px] px-2.5 py-0.5 rounded-full">
                                  {l}
                                </span>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>

                    </div>
                  </div>
                )}

              </div>
            </div>

            {/* Bottom help bar */}
            <div className="p-3 bg-slate-200/50 text-[10.5px] text-gray-550 border-t shrink-0">
              💡 <span className="font-bold">Pro-Tip:</span> Under the "Save Backup" button, save your draft JSON locally anytime, then "Load Backup" to import your details instantaneously next session!
            </div>
          </div>

        </div>

      </div>
    </div>
  );
}
