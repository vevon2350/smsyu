import React from 'react';

interface FooterProps {
  onPrivacyClick?: () => void;
  onTermsClick?: () => void;
  onHelpClick?: () => void;
  onContactClick?: () => void;
}

export default function Footer({ onPrivacyClick, onTermsClick, onHelpClick, onContactClick }: FooterProps) {
  return (
    <footer className="bg-gray-100 border-t border-gray-200">
      <div className="flex flex-col md:flex-row justify-between items-center w-full py-8 px-12 max-w-7xl mx-auto gap-4">
        <div className="flex items-center gap-4">
          <span className="text-sm font-bold text-gray-900">PDFPro</span>
          <span className="text-sm text-gray-600">© 2024 PDFPro. Secure PDF Tools.</span>
        </div>
        <div className="flex flex-wrap gap-x-6 gap-y-2 justify-center">
          <button 
            onClick={(e) => {
              e.preventDefault();
              onPrivacyClick?.();
            }}
            className="text-sm text-gray-600 hover:text-indigo-700 cursor-pointer font-medium bg-transparent border-none outline-none"
          >
            Privacy Policy
          </button>
          <button 
            onClick={(e) => {
              e.preventDefault();
              onTermsClick?.();
            }}
            className="text-sm text-gray-600 hover:text-indigo-700 cursor-pointer font-medium bg-transparent border-none outline-none"
          >
            Terms of Service
          </button>
          <button 
            onClick={(e) => {
              e.preventDefault();
              onHelpClick?.();
            }}
            className="text-sm text-gray-600 hover:text-indigo-700 cursor-pointer font-medium bg-transparent border-none outline-none"
          >
            Help Center
          </button>
          <button 
            onClick={(e) => {
              e.preventDefault();
              onContactClick?.();
            }}
            className="text-sm text-gray-600 hover:text-indigo-700 cursor-pointer font-medium bg-transparent border-none outline-none"
          >
            Contact Support
          </button>
        </div>
      </div>
    </footer>
  );
}
