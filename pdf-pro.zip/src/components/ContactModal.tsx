import React, { useState } from 'react';
import { X, Mail, User, Send, Check, RefreshCcw } from 'lucide-react';

interface ContactModalProps {
  onClose: () => void;
}

export default function ContactModal({ onClose }: ContactModalProps) {
  const [formName, setFormName] = useState('');
  const [formEmail, setFormEmail] = useState('');
  const [formMessage, setFormMessage] = useState('');
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formEmail || !formMessage) return;
    
    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      setFormSubmitted(true);
    }, 1200);
  };

  const resetForm = () => {
    setFormName('');
    setFormEmail('');
    setFormMessage('');
    setFormSubmitted(false);
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[110] flex items-center justify-center p-4 overflow-y-auto text-left">
      <div className="bg-white rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden relative flex flex-col my-8">
        
        {/* Header Ribbon */}
        <div className="bg-gradient-to-r from-indigo-700 via-indigo-600 to-indigo-800 text-white px-6 py-5 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="bg-white/10 p-2 rounded-lg">
              <Mail size={20} className="text-white" />
            </div>
            <div>
              <h2 className="text-base font-bold">Contact Support</h2>
              <p className="text-[11px] text-indigo-100 flex items-center gap-1 mt-0.5">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 inline-block animate-pulse"></span>
                We typically reply within 2 hours
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 hover:bg-white/10 text-white/80 hover:text-white rounded-lg transition-colors cursor-pointer"
            title="Close"
          >
            <X size={18} />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto max-h-[75vh]">
          {!formSubmitted ? (
            <form onSubmit={handleFormSubmit} className="space-y-4">
              
              {/* Row 1: Name and Email */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1.5 flex items-center gap-1">
                    <User size={12} className="text-gray-400" />
                    Full Name <span className="text-gray-400 font-normal">(Optional)</span>
                  </label>
                  <input 
                    type="text" 
                    value={formName}
                    onChange={(e) => setFormName(e.target.value)}
                    placeholder="e.g. Rahul Sharma"
                    className="w-full text-xs px-3 py-2.5 bg-slate-50 border border-gray-200 rounded-lg outline-none focus:border-indigo-500 focus:bg-white transition-all font-medium text-gray-800"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1.5 flex items-center gap-1">
                    <Mail size={12} className="text-gray-400" />
                    Email Address <span className="text-red-500 font-bold">*</span>
                  </label>
                  <input 
                    type="email" 
                    value={formEmail}
                    onChange={(e) => setFormEmail(e.target.value)}
                    placeholder="e.g. rahul@example.com"
                    required
                    className="w-full text-xs px-3 py-2.5 bg-slate-50 border border-gray-200 rounded-lg outline-none focus:border-indigo-500 focus:bg-white transition-all font-medium text-gray-800 font-mono"
                  />
                </div>
              </div>

              {/* Message */}
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1.5">
                  Message Details <span className="text-red-500 font-bold">*</span>
                </label>
                <textarea 
                  rows={5}
                  value={formMessage}
                  onChange={(e) => setFormMessage(e.target.value)}
                  placeholder="How can we help you? Describe your issue or request..."
                  required
                  className="w-full text-xs p-3 bg-slate-50 border border-gray-200 rounded-lg outline-none focus:border-indigo-500 focus:bg-white transition-all font-medium text-gray-800 resize-none leading-relaxed"
                />
              </div>

              {/* Action Buttons */}
              <div className="flex gap-3 pt-2 justify-end">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2.5 text-xs font-bold text-gray-600 hover:text-gray-800 hover:bg-gray-100 rounded-lg transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg flex items-center gap-1.5 shadow-sm transition-all hover:-translate-y-0.5 active:translate-y-0 cursor-pointer disabled:opacity-50 disabled:pointer-events-none"
                >
                  {isSubmitting ? (
                    <>
                      <RefreshCcw size={13} className="animate-spin" />
                      Sending Message...
                    </>
                  ) : (
                    <>
                      <Send size={13} />
                      Send Message
                    </>
                  )}
                </button>
              </div>

            </form>
          ) : (
            /* Success Response State */
            <div className="text-center py-8 px-4 space-y-4">
              <div className="w-14 h-14 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center mx-auto border-2 border-emerald-100 shadow-md">
                <Check size={28} strokeWidth={3} className="animate-pulse" />
              </div>
              <div className="space-y-1">
                <h3 className="text-lg font-bold text-gray-900">Message Received Securely!</h3>
                <p className="text-xs text-gray-500 max-w-sm mx-auto leading-relaxed">
                  Thank you for reaching out, <span className="font-bold text-gray-700">{formName || 'User'}</span>! 
                  Our support desk has successfully logged your ticket into our secure support queue.
                </p>
              </div>
              
              <div className="bg-slate-50 rounded-xl p-4 border border-slate-100 text-left max-w-sm mx-auto divide-y divide-slate-150/50 space-y-2.5 pt-3">
                <div className="text-[11px] grid grid-cols-3 text-gray-500 font-mono">
                  <span>Ticket Status</span>
                  <span className="col-span-2 text-right text-emerald-700 font-bold uppercase tracking-wider">● Open & Assigned</span>
                </div>
                <div className="text-[11px] grid grid-cols-3 text-gray-500 font-mono pt-2">
                  <span>Account Email</span>
                  <span className="col-span-2 text-right font-bold text-gray-700 break-all">{formEmail}</span>
                </div>
              </div>

              <div className="pt-2 flex gap-3 justify-center">
                <button
                  type="button"
                  onClick={resetForm}
                  className="px-4 py-2 text-xs font-bold text-indigo-600 hover:text-indigo-800 hover:bg-indigo-50 rounded-lg transition-colors cursor-pointer"
                >
                  Submit Another Ticket
                </button>
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 text-xs font-bold text-white bg-slate-800 hover:bg-slate-950 rounded-lg transition-all cursor-pointer"
                >
                  Done
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Form Bottom Safety Banner */}
        <div className="bg-slate-50 border-t border-slate-150 px-6 py-3 flex justify-between items-center text-[10px] text-gray-400 shrink-0 font-mono">
          <span className="flex items-center gap-1">🔒 TLS 1.3 Certified Session</span>
          <span>© 2026 PDFPro Desk</span>
        </div>

      </div>
    </div>
  );
}
