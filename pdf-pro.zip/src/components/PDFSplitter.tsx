import React, { useState } from 'react';
import { FileUp, Scissors, Loader2 } from 'lucide-react';

export default function PDFSplitter() {
  const [file, setFile] = useState<File | null>(null);
  const [pageRanges, setPageRanges] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  const handleSplit = async () => {
    if (!file) {
      alert('Please upload a PDF file first!');
      return;
    }
    setIsProcessing(true);

    const formData = new FormData();
    formData.append('files', file);
    formData.append('tool', 'split');
    formData.append('pageRanges', pageRanges);

    try {
      const response = await fetch('/api/process-pdf', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        const errJson = await response.json().catch(() => ({}));
        throw new Error(errJson.error || 'Failed to split PDF');
      }

      const contentType = response.headers.get('content-type') || '';
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      let downloadFilename = `split_${file.name}`;
      if (contentType.includes('application/zip') && downloadFilename.toLowerCase().endsWith('.pdf')) {
        downloadFilename = downloadFilename.substring(0, downloadFilename.length - 4) + '.zip';
      }
      const a = document.createElement('a');
      a.href = url;
      a.download = downloadFilename;
      a.click();
    } catch (error: any) {
      console.error(error);
      alert(`Error: ${error.message || 'Failed to split PDF'}`);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="bg-white p-8 rounded-xl flex flex-col gap-4">
      <h3 className="text-2xl font-bold text-gray-900">PDF Splitter</h3>
      <label className="border-2 border-dashed border-gray-300 rounded-lg p-6 flex flex-col items-center justify-center cursor-pointer hover:border-indigo-600 transition-colors">
        <FileUp size={32} className="text-gray-400 mb-2" />
        <span className="text-sm text-gray-600 truncate max-w-xs">{file ? file.name : 'Upload PDF'}</span>
        <input type="file" accept=".pdf" className="hidden" onChange={handleFileChange} />
      </label>
      <input
        type="text"
        placeholder="Enter page ranges (e.g. 1-2, 4)"
        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 font-mono text-sm"
        value={pageRanges}
        onChange={(e) => setPageRanges(e.target.value)}
      />
      <button 
        onClick={handleSplit}
        disabled={isProcessing}
        className="w-full bg-indigo-700 text-white py-3 rounded-lg font-bold hover:opacity-90 flex items-center justify-center gap-2 disabled:opacity-50"
      >
        {isProcessing ? (
          <>
            <Loader2 size={20} className="animate-spin" />
            Processing...
          </>
        ) : (
          <>
            <Scissors size={20} />
            Split PDF
          </>
        )}
      </button>
    </div>
  );
}

