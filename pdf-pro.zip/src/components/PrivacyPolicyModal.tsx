import React, { useState, useRef, useEffect } from 'react';
import { 
  X, Search, FileText, Check, Copy, Download, Share2, Shield, Lock, 
  HelpCircle, ChevronRight, Eye, Calendar, RefreshCcw, FileCheck, ExternalLink,
  BookOpen, Heart, Activity, Globe, Scale
} from 'lucide-react';

interface PrivacyPolicyModalProps {
  onClose: () => void;
}

interface OutlineSection {
  id: string;
  title: string;
  sub: string;
}

const POLICY_OUTLINE: OutlineSection[] = [
  { id: 'sec-intro', title: '1. Introduction', sub: 'Foundations & global trust compliance' },
  { id: 'sec-cloud', title: '2. Ephemeral Sandbox Processing', sub: 'Zero-log operations & file destruction' },
  { id: 'sec-ai', title: '3. Gemini AI Secure Integrations', sub: 'Data mapping, non-training guarantees' },
  { id: 'sec-crypt', title: '4. AES-256 Vault Architecture', sub: 'Real-time hashing and file isolation' },
  { id: 'sec-user', title: '5. User Empowerment & GDPR Rights', sub: 'Opt-out, dynamic state control & updates' },
  { id: 'sec-cookie', title: '6. Cookies & Local Metadata', sub: 'Persistent states & system telemetry limits' }
];

export default function PrivacyPolicyModal({ onClose }: PrivacyPolicyModalProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeSection, setActiveSection] = useState('sec-intro');
  const [copied, setCopied] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  // Auto detect active section on scroll
  useEffect(() => {
    const handleScroll = () => {
      if (!scrollContainerRef.current) return;
      
      const container = scrollContainerRef.current;
      const scrollPos = container.scrollTop + 120; // offset

      for (const sect of POLICY_OUTLINE) {
        const el = container.querySelector(`#${sect.id}`);
        if (el) {
          const top = (el as HTMLElement).offsetTop;
          const height = el.getBoundingClientRect().height;
          if (scrollPos >= top && scrollPos < top + height) {
            setActiveSection(sect.id);
            break;
          }
        }
      }
    };

    const container = scrollContainerRef.current;
    if (container) {
      container.addEventListener('scroll', handleScroll);
    }
    return () => {
      if (container) {
        container.removeEventListener('scroll', handleScroll);
      }
    };
  }, []);

  const scrollToSect = (id: string) => {
    setActiveSection(id);
    const el = scrollContainerRef.current?.querySelector(`#${id}`);
    if (el && scrollContainerRef.current) {
      scrollContainerRef.current.scrollTo({
        top: (el as HTMLElement).offsetTop - 15,
        behavior: 'smooth'
      });
    }
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(window.location.href + '#privacy-policy');
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    setDownloadSuccess(true);
    setTimeout(() => {
      setDownloadSuccess(false);
      // Trigger native browser print which formats automatically as page-perfect PDF
      window.print();
    }, 1000);
  };

  // Helper function to dynamically highlight query text inside raw texts
  const highlightText = (text: string) => {
    if (!searchQuery.trim()) return text;
    const regex = new RegExp(`(${searchQuery.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&')})`, 'gi');
    const parts = text.split(regex);
    return (
      <>
        {parts.map((part, i) => 
          regex.test(part) ? (
            <mark key={i} className="bg-yellow-250 py-0.5 px-1 rounded-sm text-gray-900 border border-yellow-300 select-all font-semibold">
              {part}
            </mark>
          ) : part
        )}
      </>
    );
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[110] flex items-center justify-center p-4 overflow-hidden animate-fadeIn">
      <div className="bg-white rounded-2xl w-full max-w-[1250px] h-[92vh] flex flex-col shadow-2xl relative animate-slideUp">
        
        {/* Dropbox Paper Style Control Header */}
        <div className="border-b border-gray-150 px-6 py-4 flex items-center justify-between bg-white shrink-0">
          <div className="flex items-center gap-3">
            {/* Dropbox-styled file icon */}
            <div className="bg-blue-600 text-white p-2.5 rounded-lg shadow-md hover:bg-blue-700 transition-colors">
              <Shield size={20} className="animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[11px] font-extrabold bg-blue-100 text-blue-800 uppercase px-2 py-0.5 rounded-md tracking-wider">
                  Paper Doc File (Read-Only)
                </span>
                <span className="text-xs text-gray-400 font-mono flex items-center gap-1">
                  <Activity size={12} className="text-emerald-500" /> Auto-Synced to Vault
                </span>
              </div>
              <h2 className="text-base font-extrabold text-gray-900 flex items-center gap-2 mt-0.5 font-sans">
                PDFPro_Privacy_Policy_GDPR_V4.pdf
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            {/* Interactive Keyword Search Filter */}
            <div className="relative hidden md:block">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={14} />
              <input 
                type="text" 
                placeholder="Search keywords (e.g. AI, logs, cookies, security)..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9 pr-4 py-1.5 w-64 bg-slate-100 rounded-lg text-xs outline-none focus:bg-white border border-transparent focus:border-blue-400 transition-all font-medium text-gray-800"
              />
              {searchQuery && (
                <button 
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[10px] font-bold text-gray-400 hover:text-gray-600"
                >
                  Clear
                </button>
              )}
            </div>

            <div className="h-6 w-[1px] bg-gray-200 mx-1 hidden md:block"></div>

            <button 
              onClick={handleCopyLink}
              className={`px-3 py-1.5 rounded-lg border text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                copied 
                  ? 'bg-emerald-50 border-emerald-300 text-emerald-700' 
                  : 'border-gray-200 bg-white hover:bg-slate-50 text-gray-700'
              }`}
            >
              {copied ? <Check size={14} /> : <Copy size={13} />}
              {copied ? 'Link Copied!' : 'Copy Policy Link'}
            </button>

            <button 
              onClick={handleDownload}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold text-white flex items-center gap-1.5 transition-all cursor-pointer shadow-sm ${
                downloadSuccess
                  ? 'bg-emerald-600'
                  : 'bg-blue-600 hover:bg-blue-700'
              }`}
            >
              {downloadSuccess ? (
                <>
                  <Check size={14} /> Generating Perfect Page Print...
                </>
              ) : (
                <>
                  <Download size={13} /> Secure Draft PDF / Print
                </>
              )}
            </button>

            <button 
              onClick={onClose}
              className="p-1.5 bg-slate-100 hover:bg-rose-50 text-gray-500 hover:text-rose-600 rounded-lg transition-transform cursor-pointer ml-1"
              title="Close Sandbox Preview"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Modal Secondary Context Banner */}
        <div className="bg-slate-50 border-b border-gray-150 px-6 py-2.5 flex justify-between items-center text-xs shrink-0 font-sans">
          <p className="text-gray-600 flex items-center gap-1.5 font-medium">
            <Lock size={12} className="text-indigo-600" />
            <span className="font-bold text-gray-800">AES-256 Legal Trust System:</span> Uploaded files are isolates of single users and absolutely never scraped or stored.
          </p>
          <div className="flex gap-4 text-[11px] text-gray-500 font-mono font-medium">
            <span>LAST AMENDED: JUNE 06, 2026</span>
            <span>GDPR CERTIFIED: CO-093284</span>
          </div>
        </div>

        {/* Dynamic Multi-Pane Layout */}
        <div className="flex-1 flex overflow-hidden min-h-0">
          
          {/* LOBBYISTS SIDEBAR: Document Outline navigation */}
          <div className="w-[28%] bg-slate-50 border-r border-gray-150 flex flex-col justify-between shrink-0">
            {/* Outline list */}
            <div className="p-4 overflow-y-auto space-y-1">
              <h4 className="text-[10px] font-extrabold text-slate-400 tracking-wider uppercase mb-3.5 px-2">
                Document Outline Tree
              </h4>
              <nav className="space-y-1">
                {POLICY_OUTLINE.map((sect) => (
                  <button
                    key={sect.id}
                    onClick={() => scrollToSect(sect.id)}
                    className={`w-full text-left p-3 rounded-xl transition-all flex flex-col cursor-pointer ${
                      activeSection === sect.id 
                        ? 'bg-white border border-gray-200/80 shadow-sm'
                        : 'hover:bg-slate-200/60'
                    }`}
                  >
                    <span className={`text-[11.5px] font-extrabold tracking-tight ${
                      activeSection === sect.id ? 'text-blue-700' : 'text-gray-700'
                    }`}>
                      {sect.title}
                    </span>
                    <span className="text-[10px] text-gray-450 mt-0.5 font-medium truncate w-[210px]">
                      {sect.sub}
                    </span>
                  </button>
                ))}
              </nav>

              {/* Extra Document Stats */}
              <div className="mt-8 border-t border-gray-200 pt-5 space-y-3 px-2">
                <h4 className="text-[10px] font-extrabold text-slate-400 tracking-wider uppercase">
                  Policy Metadata
                </h4>
                <div className="space-y-2 text-[11px] font-medium text-gray-650">
                  <div className="flex justify-between items-center">
                    <span className="flex items-center gap-1"><Calendar size={12} /> Version</span>
                    <span className="font-mono text-gray-900 font-bold">4.12.0</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="flex items-center gap-1"><RefreshCcw size={12} /> Frequency</span>
                    <span>Quarterly Review</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="flex items-center gap-1"><BookOpen size={12} /> Reading Time</span>
                    <span>4 Minutes</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick trust seal at baseline */}
            <div className="p-4 border-t border-gray-200 bg-slate-100/60 space-y-2 text-center text-[10px] text-gray-500 font-medium">
              <div className="flex justify-center gap-1 text-emerald-600 font-bold uppercase tracking-wider">
                <FileCheck size={13} /> Secured Sandbox Approved
              </div>
              <p className="leading-relaxed px-2 text-gray-400">
                This document is digitally locked & compliant with standard CCPA / GDPR regulations.
              </p>
            </div>
          </div>

          {/* MAIN ARTICLE PREVIEWER: Beautiful high-fidelity Paper styled Canvas */}
          <div 
            ref={scrollContainerRef}
            className="flex-1 overflow-y-auto p-12 bg-white flex justify-center scroll-smooth outline-none select-text"
          >
            {/* Mimics a physical A4 document centered inside Dropbox viewer */}
            <article className="w-full max-w-[760px] pb-32 space-y-8 font-sans leading-relaxed text-gray-700 text-[13px]">
              
              {/* Document Banner */}
              <header className="border-b-4 border-double border-slate-900 pb-6 text-center">
                <div className="flex justify-center text-slate-900 mb-2">
                  <Shield size={36} className="text-blue-600 stroke-[1.5]" />
                </div>
                <h1 className="text-xl font-extrabold text-slate-900 uppercase tracking-widest font-sans">
                  Global Privacy Architecture & Agreement
                </h1>
                <p className="text-[11px] font-bold text-gray-400 uppercase mt-1 tracking-wider">
                  PDFPro Secure Network Framework • Standard Compliance Standard
                </p>
                <div className="flex justify-center items-center gap-4 text-[10px] font-mono mt-4 text-slate-500 py-1 bg-slate-50 rounded-lg">
                  <span>SHA-256 Vault-ID: b9a47...9a21</span>
                  <span>|</span>
                  <span>Encryption Key Type: RSA 4096-bit</span>
                </div>
              </header>

              {/* Section Intro */}
              <div id="sec-intro" className="scroll-mt-12 space-y-3">
                <h2 className="text-sm font-extrabold text-slate-900 uppercase tracking-wider flex items-center gap-2 border-b pb-1">
                  <Scale size={14} className="text-blue-600" />
                  1. Scope & Global Trust Foundations
                </h2>
                <p className="text-justify font-normal text-slate-700 leading-6">
                  {highlightText("Welcome to PDFPro. We are fundamentally committed to prioritizing your architectural digital safety. This Privacy Policy details the exact mechanics of our user-consent security workflows, secure files, and metadata policies. By utilizing our premium PDF tools (including PDF Splitter, PDF Merger, PDF Compressor, and PDF Resume Builder), you enter a digitally validated circle of zero-log privacy. We adhere strictly to absolute user-first safety regulations, including GDPR, California Consumer Privacy Act (CCPA), and global HIPAA-standard handling vectors.")}
                </p>
                <p className="text-justify font-normal text-slate-700 leading-6">
                  {highlightText("Our business model does not monetize user data. We do not aggregate your uploaded file vectors, we do not trade processing files to marketing entities, and we never share customized information templates with malicious tracking systems.")}
                </p>
              </div>

              {/* Section Cloud Sandbox */}
              <div id="sec-cloud" className="scroll-mt-12 space-y-3">
                <h2 className="text-sm font-extrabold text-slate-900 uppercase tracking-wider flex items-center gap-2 border-b pb-1">
                  <Shield size={14} className="text-indigo-600" />
                  2. Ephemeral Sandbox Processing & File Destruction
                </h2>
                <p className="text-justify font-normal text-slate-700 leading-6">
                  {highlightText("When you trigger file uploads to split, merge, or compress document entities, your source material is transferred securely via state-of-the-art HTTPS encryption layers to an isolated sandbox volume managed inside our container node. Here are the exact guarantees we implement:")}
                </p>
                <ul className="list-disc list-inside pl-2 space-y-2 text-slate-600 font-medium">
                  <li>
                    <strong className="text-slate-800 font-bold">{highlightText("Immediate Ephemeral Isolation:")}</strong> {highlightText("The processor parses content purely in transient virtual storage. The file is never permanently mounted to cloud disk arrays.")}
                  </li>
                  <li>
                    <strong className="text-slate-800 font-bold">{highlightText("The 60-Minute Destruction Rule:")}</strong> {highlightText("Upon execution of the tool, a localized timer flags the session container. Every user-uploaded document is programmatically purged, unlinked, and shredded from all buffers within exactly 60 minutes.")}
                  </li>
                  <li>
                    <strong className="text-slate-800 font-bold">{highlightText("Zero Persistent Data Logs:")}</strong> {highlightText("We record telemetry counts but do not preserve backup archives or file history lists. Once deleted, files are unrecoverable by our engineering team.")}
                  </li>
                </ul>
                <div className="bg-slate-50 border border-slate-200 p-3.5 rounded-xl text-[11px] font-mono leading-relaxed space-y-1">
                  <span className="text-slate-800 font-extrabold uppercase tracking-wider block">🔒 Standard Ephemeral Purge Function:</span>
                  <span className="text-gray-500 block">rm -rf /var/sandbox/uploads/sess_user_id (Triggered automatically 3600s after session termination)</span>
                </div>
              </div>

              {/* Section Gemini AI Secure */}
              <div id="sec-ai" className="scroll-mt-12 space-y-3">
                <h2 className="text-sm font-extrabold text-slate-900 uppercase tracking-wider flex items-center gap-2 border-b pb-1">
                  <Globe size={14} className="text-emerald-600" />
                  3. Gemini AI Smart Engine Protocols
                </h2>
                <p className="text-justify font-normal text-slate-700 leading-6">
                  {highlightText("Our advanced intelligent assistant services (including automatic document Summarization and live translation tools) utilize high-tier neural networks, specifically the official Google Gemini Pro API. In strict accordance with our security guidelines, we map data requests uniquely with severe security constraints:")}
                </p>
                <ul className="list-disc list-inside pl-2 space-y-2 text-slate-600 leading-6">
                  <li>
                    <strong className="text-slate-800 font-bold">{highlightText("No Training Scrapes:")}</strong> {highlightText("Data payloads supplied to the Google Gemini API are fully isolated and explicitly exempt from system modeling training cycles. Your confidential drafts are never ingested to build or refine public algorithms.")}
                  </li>
                  <li>
                    <strong className="text-slate-800 font-bold">{highlightText("Encrypted API Handshakes:")}</strong> {highlightText("Communication channels operate strictly using 2048-bit TLS keys. No raw API tokens or API key registries are ever transmitted or exposed client-side to user browsers.")}
                  </li>
                  <li>
                    <strong className="text-slate-800 font-bold">{highlightText("Granular Metadata Stripping:")}</strong> {highlightText("Before sending PDF texts or summaries to neural modules, our server-side proxy strips localized system tags, operating system values, and user geolocation metrics.")}
                  </li>
                </ul>
              </div>

              {/* Section Crypto Vault */}
              <div id="sec-crypt" className="scroll-mt-12 space-y-3">
                <h2 className="text-sm font-extrabold text-slate-900 uppercase tracking-wider flex items-center gap-2 border-b pb-1">
                  <Lock size={14} className="text-blue-700" />
                  4. AES-256 Vault & Cryptographic Architecture
                </h2>
                <p className="text-justify font-normal text-slate-700 leading-6">
                  {highlightText("To guarantee persistent integrity against man-in-the-middle exploits or regional container vulnerabilities, PDFPro implements standard Cryptographic Hash verification protocols. Whenever documents undergo division or scaling vectors:")}
                </p>
                <div className="grid grid-cols-2 gap-4 mt-3">
                  <div className="p-3 bg-blue-50/50 border border-blue-100 rounded-xl space-y-1">
                    <span className="font-extrabold text-blue-800 text-xs block">End-To-End TLS Tunneling:</span>
                    <span className="text-[11px] text-gray-600 block">Ensures data remains unreadable by third parties while traveling from your home device to our sandboxed API node.</span>
                  </div>
                  <div className="p-3 bg-indigo-50/50 border border-indigo-100 rounded-xl space-y-1">
                    <span className="font-extrabold text-indigo-800 text-xs block">RSA Static Encryption:</span>
                    <span className="text-[11px] text-gray-600 block">All state maps are isolated behind localized firewall perimeters with limited, certified admin tokens.</span>
                  </div>
                </div>
              </div>

              {/* Section User Empowerment */}
              <div id="sec-user" className="scroll-mt-12 space-y-3">
                <h2 className="text-sm font-extrabold text-slate-900 uppercase tracking-wider flex items-center gap-2 border-b pb-1">
                  <Check size={14} className="text-amber-600" />
                  5. User Empowerment & GDPR Rights
                </h2>
                <p className="text-justify font-normal text-slate-700 leading-6">
                  {highlightText("Under current European Union general regulations (GDPR) and related data frameworks, users are afforded full autonomy regarding their personal data, including the Rights of Eradication (Right to be Forgotten). You possess absolute tools to:")}
                </p>
                <ul className="list-decimal list-inside pl-2 space-y-2 text-slate-600 leading-6">
                  <li>
                    <strong className="text-slate-800 font-bold">{highlightText("Instant Personal Wipe:")}</strong> {highlightText("Click 'Sign Out' or clear your local cache to instantly remove user emails and resume draft files from your browser memory.")}
                  </li>
                  <li>
                    <strong className="text-slate-800 font-bold">{highlightText("Absolute Right of Access:")}</strong> {highlightText("You may download a structured JSON backup of your CV Resume structure at any time by pressing 'Save Backup'.")}
                  </li>
                  <li>
                    <strong className="text-slate-800 font-bold">{highlightText("Zero Dark Patterns:")}</strong> {highlightText("We do not prompt or force signup vectors. You are fully empowered to compress or modify files as an anonymous consumer.")}
                  </li>
                </ul>
              </div>

              {/* Section Cookie and state */}
              <div id="sec-cookie" className="scroll-mt-12 space-y-3">
                <h2 className="text-sm font-extrabold text-slate-900 uppercase tracking-wider flex items-center gap-2 border-b pb-1">
                  <Globe size={14} className="text-slate-900" />
                  6. Cookies & Client-Side Local Storage
                </h2>
                <p className="text-justify font-normal text-slate-700 leading-6">
                  {highlightText("We use essential cookies and HTML5 client-side localStorage exclusively to improve application performance. Crucial details include:")}
                </p>
                <div className="border border-slate-150 rounded-xl overflow-hidden text-xs">
                  <div className="bg-slate-50 p-2.5 font-bold border-b text-slate-800 grid grid-cols-3">
                    <span>Key / Identifier</span>
                    <span>Function / Purpose</span>
                    <span>Lifespan / Retention</span>
                  </div>
                  <div className="p-2.5 grid grid-cols-3 border-b text-gray-600 font-mono text-[11px]">
                    <span className="font-bold text-slate-800">pdfpro_resume_draft</span>
                    <span>Saves currently actively typed CV parameters</span>
                    <span>Persistent until manual reset</span>
                  </div>
                  <div className="p-2.5 grid grid-cols-3 text-gray-600 font-mono text-[11px]">
                    <span className="font-bold text-slate-800">pdfpro_user</span>
                    <span>Identifies logged key email credentials</span>
                    <span>Removed on Logout</span>
                  </div>
                </div>
                <p className="text-[11.5px] italic text-slate-500 mt-2 text-center">
                  Third-party cookies, tracking tracking maps, or marketing advertisement beacons are strictly barred from loading inside this application's container environment.
                </p>
              </div>

              {/* Secure Footer Acknowledgement */}
              <footer className="border-t pt-8 text-center space-y-2 mt-8 text-slate-450 text-[10px]">
                <p className="font-bold uppercase tracking-widest text-slate-700">Digital Seal of Integrity</p>
                <div className="flex justify-center gap-3">
                  <span className="border px-2 py-0.5 rounded bg-slate-50 font-mono">CCPA Compliant</span>
                  <span className="border px-2 py-0.5 rounded bg-slate-50 font-mono">GDPR Certified</span>
                  <span className="border px-2 py-0.5 rounded bg-slate-50 font-mono">SSL Secure 2048</span>
                </div>
                <p className="max-w-[480px] mx-auto leading-relaxed mt-2 text-gray-400">
                  © 2026 PDFPro Document Vault Services LLC. All cryptographic protocols are locked in standalone Node isolation levels. No external data sales are permitted.
                </p>
              </footer>

            </article>
          </div>

          {/* INSPECTOR SIDEBAR: Right side beautiful metadata checklist */}
          <div className="w-[20%] bg-slate-50/50 border-l border-gray-150 p-5 hidden xl:flex flex-col justify-between shrink-0">
            <div className="space-y-6">
              <div>
                <h4 className="text-[10px] font-extrabold text-slate-400 tracking-wider uppercase mb-3">
                  Document Verifications
                </h4>
                <div className="p-3 bg-white border border-gray-150 rounded-xl space-y-2.5">
                  <div className="flex items-center gap-2 text-xs font-bold text-gray-800">
                    <Check size={14} className="text-emerald-600 bg-emerald-100 p-0.5 rounded-full" />
                    <span>GDPR Compliant</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs font-bold text-gray-800">
                    <Check size={14} className="text-emerald-600 bg-emerald-100 p-0.5 rounded-full" />
                    <span>AES-256 Vault</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs font-bold text-gray-800">
                    <Check size={14} className="text-emerald-600 bg-emerald-100 p-0.5 rounded-full" />
                    <span>No-Log Transient</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs font-bold text-gray-800">
                    <Check size={14} className="text-emerald-600 bg-emerald-100 p-0.5 rounded-full" />
                    <span>API-Model Safe</span>
                  </div>
                </div>
              </div>

              <div>
                <h4 className="text-[10px] font-extrabold text-slate-400 tracking-wider uppercase mb-2.5">
                  Secure Sharing Link
                </h4>
                <p className="text-[10px] text-gray-500 leading-relaxed mb-3">
                  Share this public compliant policy document directly with your legal advisors or auditing inspectors.
                </p>
                <button 
                  onClick={handleCopyLink}
                  className="w-full py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-lg text-xs font-bold transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-sm"
                >
                  <Share2 size={12} /> Share Policy Doc
                </button>
              </div>

              <div className="border-t border-gray-100 pt-4 text-center">
                <p className="text-[10px] text-gray-400 font-mono">
                  File Size: 1.05 MB
                </p>
                <p className="text-[10px] text-gray-400 font-mono mt-0.5">
                  Type: Rich Document
                </p>
              </div>
            </div>

            <div className="text-center">
              <span className="text-[11px] font-bold text-slate-700 bg-slate-200/50 px-2.5 py-1 rounded-full uppercase">
                🔒 Protected Web
              </span>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
}
