import { useState, FormEvent } from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, Mail, Lock, ShieldCheck, CheckCircle, ArrowRight, Eye, EyeOff, AlertCircle } from "lucide-react";

interface AuthModalProps {
  initialMode: "signin" | "signup";
  onClose: () => void;
  onAuthSuccess: (email: string) => void;
}

export default function AuthModal({ initialMode, onClose, onAuthSuccess }: AuthModalProps) {
  const [mode, setMode] = useState<"signin" | "signup">(initialMode);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [loadingThirdParty, setLoadingThirdParty] = useState<"google" | "facebook" | "apple" | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  // Simple Email Validation
  const validateEmail = (emailStr: string) => {
    return /\S+@\S+\.\S+/.test(emailStr);
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    if (!email || !password) {
      setError("Please fill in all standard credential fields.");
      return;
    }

    if (!validateEmail(email)) {
      setError("Please provide a valid email structure (e.g. user@example.com).");
      return;
    }

    if (password.length < 6) {
      setError("Password must meet security standards (minimum 6 characters).");
      return;
    }

    if (mode === "signup" && password !== confirmPassword) {
      setError("Passphrase mismatch. Confirm password must match original.");
      return;
    }

    setLoading(true);

    // Simulate standard authentications with nice timers
    setTimeout(() => {
      setLoading(false);
      setSuccess(mode === "signin" ? "Successfully verified credentials!" : "Account created successfully!");
      setTimeout(() => {
        onAuthSuccess(email);
        onClose();
      }, 1000);
    }, 1500);
  };

  const handleThirdPartyAuth = (provider: "google" | "facebook" | "apple") => {
    setError(null);
    setSuccess(null);
    setLoadingThirdParty(provider);

    // Simulated Handshake
    setTimeout(() => {
      setLoadingThirdParty(null);
      const fakeEmail = `user.${provider}@gmail.com`;
      setSuccess(`Authenticated securely via ${provider.charAt(0).toUpperCase() + provider.slice(1)} identity!`);
      setTimeout(() => {
        onAuthSuccess(fakeEmail);
        onClose();
      }, 1000);
    }, 1800);
  };

  return (
    <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 overflow-y-auto">
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="fixed inset-0 bg-slate-900/65 backdrop-blur-md"
        id="auth-modal-backdrop"
      />

      {/* Modal Card */}
      <motion.div
        initial={{ scale: 0.95, y: 15, opacity: 0 }}
        animate={{ scale: 1, y: 0, opacity: 1 }}
        exit={{ scale: 0.95, y: 15, opacity: 0 }}
        transition={{ type: "spring", duration: 0.4 }}
        className="relative w-full max-w-sm bg-white rounded-2xl shadow-2xl border border-slate-100 overflow-hidden z-10"
        id="auth-modal-card"
      >
        {/* Banner with Brand - Much more compact */}
        <div className="bg-indigo-700 py-4 px-5 text-white text-center relative selection:bg-indigo-300">
          <button
            onClick={onClose}
            className="absolute right-3 top-3 text-white/80 hover:text-white p-1 hover:bg-white/10 rounded-full transition-colors cursor-pointer"
            id="close-auth-modal"
          >
            <X size={16} />
          </button>
          
          <div className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-white/10 text-[10px] font-semibold text-indigo-150 border border-white/10">
            <ShieldCheck size={11} className="text-emerald-400" />
            <span>Secure Enterprise Auth</span>
          </div>
          <h2 className="text-lg font-black tracking-tight mt-1">
            {mode === "signin" ? "Welcome back" : "Create Account"}
          </h2>
        </div>

        {/* Form Body - Reduced padding from p-8 to py-4 px-5 */}
        <div className="py-4 px-5">
          {/* Notification Messages */}
          <AnimatePresence mode="wait">
            {error && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="bg-rose-50 border border-rose-150 text-rose-700 p-2.5 rounded-xl text-xs font-medium flex gap-2 items-start mb-3"
                id="auth-error-banner"
              >
                <AlertCircle size={14} className="shrink-0 mt-0.5" />
                <span>{error}</span>
              </motion.div>
            )}

            {success && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="bg-emerald-50 border border-emerald-150 text-emerald-700 p-2.5 rounded-xl text-xs font-semibold flex gap-2 items-start mb-3"
                id="auth-success-banner"
              >
                <CheckCircle size={14} className="shrink-0 mt-0.5 text-emerald-500" />
                <span>{success}</span>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Tab Selector - Smaller padding and margin */}
          <div className="flex bg-slate-100 p-0.5 rounded-lg mb-3.5">
            <button
              type="button"
              onClick={() => { setMode("signin"); setError(null); }}
              className={`flex-1 py-1.5 text-xs font-bold rounded-md transition-all text-center cursor-pointer ${
                mode === "signin" ? "bg-white text-slate-900 shadow-sm" : "text-slate-500 hover:text-slate-950"
              }`}
              id="auth-tab-signin"
            >
              Sign In
            </button>
            <button
              type="button"
              onClick={() => { setMode("signup"); setError(null); }}
              className={`flex-1 py-1.5 text-xs font-bold rounded-md transition-all text-center cursor-pointer ${
                mode === "signup" ? "bg-white text-slate-900 shadow-sm" : "text-slate-500 hover:text-slate-950"
              }`}
              id="auth-tab-signup"
            >
              Sign Up
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-3">
            {/* Email Field */}
            <div>
              <label className="block text-[10px] font-bold text-slate-700 uppercase tracking-wider mb-1">
                Email Address
              </label>
              <div className="relative">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@example.com"
                  disabled={loading || !!loadingThirdParty}
                  className="w-full pl-9 pr-3 py-2 bg-slate-50 hover:bg-slate-100/50 focus:bg-white border border-slate-200 focus:border-indigo-500 rounded-lg text-sm text-slate-900 outline-none transition-all placeholder:text-slate-400 font-medium"
                  required
                />
                <Mail size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              </div>
            </div>

            {/* Password Field */}
            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="block text-[10px] font-bold text-slate-700 uppercase tracking-wider">
                  Password
                </label>
                {mode === "signin" && (
                  <button
                    type="button"
                    onClick={() => alert("Simulated: password resetting packet dispatched!")}
                    className="text-[10px] font-bold text-indigo-600 hover:text-indigo-800 hover:underline transition-colors cursor-pointer"
                  >
                    Forgot?
                  </button>
                )}
              </div>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Min. 6 chars"
                  disabled={loading || !!loadingThirdParty}
                  className="w-full pl-9 pr-9 py-2 bg-slate-50 hover:bg-slate-100/50 focus:bg-white border border-slate-200 focus:border-indigo-500 rounded-lg text-sm text-slate-900 outline-none transition-all placeholder:text-slate-400 font-medium font-sans"
                  required
                />
                <Lock size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-0.5 rounded cursor-pointer"
                >
                  {showPassword ? <EyeOff size={14} /> : <Eye size={14} />}
                </button>
              </div>
            </div>

            {/* Confirm Password (Sign up exclusive) */}
            {mode === "signup" && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                className="overflow-hidden"
              >
                <div>
                  <label className="block text-[10px] font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Confirm Password
                  </label>
                  <div className="relative">
                    <input
                      type={showPassword ? "text" : "password"}
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      placeholder="Repeat password"
                      disabled={loading || !!loadingThirdParty}
                      className="w-full pl-9 pr-3 py-2 bg-slate-50 hover:bg-slate-100/50 focus:bg-white border border-slate-200 focus:border-indigo-500 rounded-lg text-sm text-slate-900 outline-none transition-all placeholder:text-slate-400 font-medium font-sans"
                      required
                    />
                    <Lock size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  </div>
                </div>
              </motion.div>
            )}

            {/* Submit Button */}
            <button
              type="submit"
              disabled={loading || !!loadingThirdParty}
              className="w-full py-2 px-4 bg-indigo-700 hover:bg-indigo-800 text-white rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-all shadow active:scale-[0.98] disabled:opacity-60 cursor-pointer pt-2"
              id="auth-submit-btn"
            >
              {loading ? (
                <>
                  <svg className="animate-spin h-3.5 w-3.5 text-white" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                  </svg>
                  <span>Processing...</span>
                </>
              ) : (
                <>
                  <span>{mode === "signin" ? "CONTINUE WITH EMAIL" : "CREATE SECURE ACCOUNT"}</span>
                  <ArrowRight size={12} />
                </>
              )}
            </button>
          </form>

          {/* Social login partition */}
          <div className="relative my-4 text-center">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-slate-250"></div>
            </div>
            <span className="relative bg-white px-3 text-[9px] font-bold text-slate-400 uppercase tracking-wider">
              or connect via
            </span>
          </div>

          {/* Social OAuth flows (Google, Facebook, Apple) - Rendered in a grid column layout to save huge amount of spacing! */}
          <div className="grid grid-cols-3 gap-2">
            {/* Google */}
            <button
              type="button"
              onClick={() => handleThirdPartyAuth("google")}
              disabled={loading || !!loadingThirdParty}
              className="flex flex-col items-center justify-center p-2 border border-slate-200 hover:border-slate-300 hover:bg-slate-50 rounded-lg transition-all font-semibold text-slate-705 text-[10px] active:scale-[0.99] disabled:opacity-50 cursor-pointer"
              id="google-auth-btn"
            >
              {loadingThirdParty === "google" ? (
                <svg className="animate-spin h-4 w-4 text-slate-500 my-0.5" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                </svg>
              ) : (
                <>
                  <svg className="w-4 h-4 text-center shrink-0 mb-1" viewBox="0 0 24 24">
                    <path
                      fill="#EA4335"
                      d="M12 5.04c1.64 0 3.12.56 4.28 1.67l3.2-3.2C17.52 1.58 14.96 1 12 1 7.35 1 3.4 3.65 1.51 7.5l3.86 3C6.31 7.52 8.94 5.04 12 5.04z"
                    />
                    <path
                      fill="#4285F4"
                      d="M23.49 12.27c0-.81-.07-1.59-.2-2.34H12v4.44h6.44c-.28 1.48-1.12 2.74-2.38 3.58l3.69 2.87c2.16-1.99 3.74-4.92 3.74-8.55z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.37 10.5C5.12 11.23 5 12 5 12s.12.77.37 1.5l-3.86 3C.56 14.93 0 13.53 0 12s.56-2.93 1.51-4.5l3.86 3z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 18.96c-3.06 0-5.69-2.48-6.63-5.46l-3.86 3C3.4 20.35 7.35 23 12 23c4.71 0 8.7-1.57 11.6-4.26l-3.91-3.04c-1.44.97-3.29 1.56-5.69 1.56z"
                    />
                  </svg>
                  <span className="truncate">Google</span>
                </>
              )}
            </button>

            {/* Facebook */}
            <button
              type="button"
              onClick={() => handleThirdPartyAuth("facebook")}
              disabled={loading || !!loadingThirdParty}
              className="flex flex-col items-center justify-center p-2 border border-slate-200 hover:border-slate-300 hover:bg-slate-50 rounded-lg transition-all font-semibold text-slate-705 text-[10px] active:scale-[0.99] disabled:opacity-50 cursor-pointer"
              id="facebook-auth-btn"
            >
              {loadingThirdParty === "facebook" ? (
                <svg className="animate-spin h-4 w-4 text-slate-500 my-0.5" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                </svg>
              ) : (
                <>
                  <svg className="w-4 h-4 shrink-0 text-[#1877F2] mb-1" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                  </svg>
                  <span className="truncate">Facebook</span>
                </>
              )}
            </button>

            {/* Apple */}
            <button
              type="button"
              onClick={() => handleThirdPartyAuth("apple")}
              disabled={loading || !!loadingThirdParty}
              className="flex flex-col items-center justify-center p-2 border border-slate-200 hover:border-slate-300 hover:bg-slate-50 rounded-lg transition-all font-semibold text-slate-705 text-[10px] active:scale-[0.99] disabled:opacity-50 cursor-pointer"
              id="apple-auth-btn"
            >
              {loadingThirdParty === "apple" ? (
                <svg className="animate-spin h-4 w-4 text-slate-500 my-0.5" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                </svg>
              ) : (
                <>
                  <svg className="w-4 h-4 shrink-0 text-black mb-1" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M15.97 4.17c.66-.81 1.11-1.93.99-3.06-1 .04-2.2.67-2.92 1.49-.62.71-1.16 1.85-1.01 2.96 1.12.09 2.27-.57 2.94-1.39z" />
                  </svg>
                  <span className="truncate">Apple</span>
                </>
              )}
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
